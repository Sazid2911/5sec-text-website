import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'compliance.dart';
import 'contacts.dart';
import 'data.dart';
import 'deals.dart';
import 'main.dart';
import 'app_theme.dart';
import 'notifier.dart';
import 'videos.dart';

class SettingsScreen extends StatelessWidget {
  final AppUser me;
  const SettingsScreen({super.key, required this.me});

  Future<void> _deleteAccount(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Withdraw consent & delete account?'),
        content: const Text('Withdrawing consent deletes your account: your profile, username, status updates and deals are removed at once. '
            'Only the minimal activity log and complaints are kept for 1 year, as the law requires, then deleted. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: Theme.of(c).colorScheme.error), onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await PhoneIndex.removeMyNumber().catchError((_) {});
      for (var slot = 1; slot <= maxStatusItems; slot++) { await VideoRepo.delete('${me.uid}_$slot').catchError((_) {}); }
      for (final d in await DealRepo.mine().first) { await DealRepo.delete(d.id).catchError((_) {}); }
      await Repo.deleteAccount(me);
      if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } on FirebaseAuthException catch (e) {
      if (!context.mounted) return;
      final msg = e.code == 'requires-recent-login' ? 'For your security, sign out, sign in again, then delete your account.' : (e.message ?? e.code);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(children: [
        ListTile(
          leading: CircleAvatar(radius: 26, backgroundColor: cs.primaryContainer, child: Text(me.name.isEmpty ? '?' : me.name[0].toUpperCase(), style: const TextStyle(fontSize: 20))),
          title: Text(me.name, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('@${me.username}\n${auth.currentUser?.email ?? ''}'),
          isThreeLine: true,
        ),
        const Divider(),
        const ListTile(
          leading: Icon(Icons.timer_outlined),
          title: Text('How it works'),
          subtitle: Text('All messages are end-to-end encrypted - only the people in the chat can read them. '
              'Texts and photos disappear 5 seconds after they are seen (you can choose up to 30 seconds below); hold a message to pause its timer. Voice and video play once. '
              'Photos and videos can be taken with the in-app camera or attached from your gallery; they are checked for nudity and can never be saved or downloaded by the receiver. '
              'Screenshots and screen recording are blocked. The home screen stays blank unless you have unread messages. '
              'An active SIM card is required. For adults (18+) only.'),
        ),
        const Divider(),
        const _VanishTile(),
        const Divider(),
        const _NotifyTile(),
        const Divider(),
        const _ColorTile(),
        const Divider(),
        const _PhoneTile(),
        const Divider(),
        const Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 0), child: Text('Blocked people', style: TextStyle(fontWeight: FontWeight.w700))),
        StreamBuilder<List<String>>(
          stream: Repo.myBlocked(),
          builder: (context, snap) {
            final list = snap.data ?? const [];
            if (list.isEmpty) return const ListTile(dense: true, title: Text('Nobody blocked'));
            return Column(children: [
              for (final uid in list)
                StreamBuilder<AppUser?>(
                  stream: Repo.watchUser(uid),
                  builder: (_, u) => ListTile(
                    dense: true,
                    title: Text(u.data?.name ?? 'User'),
                    subtitle: Text(u.data == null ? '' : '@${u.data!.username}'),
                    trailing: TextButton(onPressed: () => Repo.unblock(uid), child: const Text('Unblock')),
                  ),
                ),
            ]);
          },
        ),
        const Divider(),
        ListTile(leading: const Icon(Icons.support_agent), title: const Text('Help & Grievance Officer'), subtitle: const Text('Complaints, appeals and questions'),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpScreen()))),
        ListTile(leading: const Icon(Icons.gavel_outlined), title: const Text('Terms of Use'), onTap: () => launchUrl(Uri.parse(termsUrl), mode: LaunchMode.externalApplication)),
        ListTile(leading: const Icon(Icons.privacy_tip_outlined), title: const Text('Privacy policy'), onTap: () => launchUrl(Uri.parse(privacyUrl), mode: LaunchMode.externalApplication)),
        ListTile(leading: const Icon(Icons.logout), title: const Text('Sign out'), onTap: () { Navigator.pop(context); VideoServer.stop(); Notifier.stop(); auth.signOut(); }),
        ListTile(leading: const Icon(Icons.fact_check_outlined), title: const Text('Your data & consent'), subtitle: const Text('What we collect, why, and your rights'),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DataNoticeScreen()))),
        ListTile(leading: Icon(Icons.delete_forever, color: cs.error), title: Text('Withdraw consent & delete account', style: TextStyle(color: cs.error)), onTap: () => _deleteAccount(context)),
        const SizedBox(height: 24),
        Center(child: Text('$appName · v1.0', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12))),
        const SizedBox(height: 24),
      ]),
    );
  }
}

/// Optional mobile number, so friends who saved it can find me from their contacts.
class _PhoneTile extends StatefulWidget {
  const _PhoneTile();
  @override
  State<_PhoneTile> createState() => _PhoneTileState();
}

class _PhoneTileState extends State<_PhoneTile> {
  String? _n;
  @override
  void initState() {
    super.initState();
    PhoneIndex.myNumber().then((v) { if (mounted) setState(() => _n = v); });
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.phone_iphone),
      title: const Text('Mobile number (optional)'),
      subtitle: Text(_n == null ? 'Not added. Add it so friends who saved your number can find you.' : '$_n · friends with this number saved can find you'),
      isThreeLine: true,
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        TextButton(
          onPressed: () async { if (await showPhoneDialog(context)) { final v = await PhoneIndex.myNumber(); if (mounted) setState(() => _n = v); } },
          child: Text(_n == null ? 'Add' : 'Change'),
        ),
        if (_n != null)
          IconButton(
            tooltip: 'Remove number',
            icon: const Icon(Icons.delete_outline),
            onPressed: () async { await PhoneIndex.removeMyNumber(); if (mounted) setState(() => _n = null); },
          ),
      ]),
    );
  }
}

/// How long messages stay on screen after I open them: 5 s (default) to 30 s.
class _VanishTile extends StatefulWidget {
  const _VanishTile();
  @override
  State<_VanishTile> createState() => _VanishTileState();
}

class _VanishTileState extends State<_VanishTile> {
  double _v = viewSeconds.toDouble();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final s = _v.round();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.timer_outlined),
          const SizedBox(width: 16),
          const Expanded(child: Text('Messages disappear after', style: TextStyle(fontSize: 16))),
          Text('$s sec', style: TextStyle(fontWeight: FontWeight.w800, color: cs.primary, fontSize: 16)),
        ]),
        Slider(
          value: _v,
          min: ViewTime.min.toDouble(),
          max: ViewTime.max.toDouble(),
          divisions: ViewTime.max - ViewTime.min,
          label: '$s sec',
          onChanged: (v) => setState(() => _v = v),
          onChangeEnd: (v) => ViewTime.set(v.round()),
        ),
        Row(children: [
          Text('5 sec (default)', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
          const Spacer(),
          if (s != ViewTime.fallback)
            TextButton(onPressed: () { setState(() => _v = ViewTime.fallback.toDouble()); ViewTime.set(ViewTime.fallback); }, child: const Text('Reset to 5 sec')),
          const Spacer(),
          Text('30 sec', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        ]),
        Text('Counts from the moment you open a text or photo. Voice and video still play once.', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
      ]),
    );
  }
}


/// Message notifications YES / NO.
class _NotifyTile extends StatefulWidget {
  const _NotifyTile();
  @override
  State<_NotifyTile> createState() => _NotifyTileState();
}

class _NotifyTileState extends State<_NotifyTile> {
  bool _on = Notifier.enabled ?? true;
  @override
  void initState() {
    super.initState();
    Notifier.loadSetting().then((_) { if (mounted) setState(() => _on = Notifier.enabled ?? true); });
  }
  @override
  Widget build(BuildContext context) => SwitchListTile(
        secondary: Icon(_on ? Icons.notifications_active_outlined : Icons.notifications_off_outlined),
        title: const Text('Notifications'),
        subtitle: Text(_on ? 'ON · 5 Sec tone for new messages (no names or text shown)' : 'OFF · no sound or notification for new messages'),
        value: _on,
        onChanged: (v) async {
          setState(() => _on = v);
          final ok = await Notifier.setEnabled(v);
          if (v && !ok && context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notifications are blocked for 5 Sec Text in your phone settings. Allow them there to hear alerts.')));
          }
        },
      );
}

/// App colour: same design, your colour.
class _ColorTile extends StatelessWidget {
  const _ColorTile();
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<Color>(
        valueListenable: AppTheme.color,
        builder: (context, current, _) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [Icon(Icons.palette_outlined), SizedBox(width: 16), Text('App colour & icon', style: TextStyle(fontSize: 16))]),
            const SizedBox(height: 12),
            Wrap(spacing: 12, runSpacing: 12, children: [
              for (final e in AppTheme.options.entries)
                Tooltip(
                  message: e.key,
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () {
                      if (current.toARGB32() == e.value.toARGB32()) return;
                      AppTheme.set(e.value);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${e.key} theme on. The app icon on your home screen changes to ${e.key.toLowerCase()} in a few seconds.')));
                    },
                    child: Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [e.value, HSLColor.fromColor(e.value).withHue((HSLColor.fromColor(e.value).hue + 60) % 360).toColor()]),
                        border: Border.all(color: current.toARGB32() == e.value.toARGB32() ? Theme.of(context).colorScheme.onSurface : Colors.transparent, width: 3),
                      ),
                      child: current.toARGB32() == e.value.toARGB32() ? const Icon(Icons.check, color: Colors.white, size: 20) : null,
                    ),
                  ),
                ),
            ]),
          ]),
        ),
      );
}
