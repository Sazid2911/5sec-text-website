// Minimal activity log, kept for 1 year and then deleted automatically
// (Firestore TTL policy on `logs.expireAt`).
//
// Why: Indian law (IT Rules 2021, DPDP Rules 2025, CERT-In directions) expects a
// service to keep basic records for a period so it can answer a court or police
// order. We keep the minimum:
//   * WHO  - user id and sign-in email
//   * WHAT - sign-in, app opened, account created / deleted, terms accepted,
//            video or deal posted / updated / ended (with its title), complaint filed
//   * WHEN - server time
// NEVER message content, photos, videos, contacts or location. Users cannot read,
// change or delete log entries; only Trust & Safety staff can read them.
import 'package:cloud_firestore/cloud_firestore.dart';

import 'data.dart';

class Audit {
  static const keep = Duration(days: 365);

  static Future<void> log(String kind, {String ref = '', String info = ''}) async {
    final u = auth.currentUser;
    if (u == null) return;
    try {
      await db.collection('logs').add({
        'uid': u.uid,
        'email': u.email ?? '',
        'kind': kind,
        'ref': ref,
        'info': info.length > 120 ? info.substring(0, 120) : info,
        'at': FieldValue.serverTimestamp(),
        'expireAt': Timestamp.fromDate(DateTime.now().add(keep)),
      });
    } catch (_) {
      // Logging must never stop the app from working.
    }
  }

  static bool _opened = false;
  /// Once per app launch.
  static void appOpened() {
    if (_opened) return;
    _opened = true;
    log('app_open');
  }
}
