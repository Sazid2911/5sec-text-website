// "5 Sec Videos" - the YouTube-like tab.
//
// * Every user can post up to 2 videos (slots <uid>_1 and <uid>_2).
// * The video file is stored ONLY on the uploader's phone (app-private storage).
//   The server keeps just a small card (title, owner, length, expiry) plus likes and comments.
// * Anyone with the app can watch: the video is streamed directly from the uploader's
//   phone to the viewer's phone over an encrypted peer-to-peer WebRTC data channel
//   (Firestore is only used to exchange the connection details). So a video can be
//   watched only while the uploader's phone is online with the app open.
// * The uploader picks how many days the video stays visible (1-30). After that the
//   card, likes and comments are deleted and the phone deletes the file.
// * Nothing can be downloaded: the received copy lives in a temp file that is wiped
//   when the player closes; screenshots/screen recording are blocked app-wide.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

import 'audit.dart';
import 'compliance.dart';
import 'data.dart';
import 'nudity.dart';
import 'reactions.dart';

const maxPostVideoBytes = 150 * 1024 * 1024;
const maxPostVideo = Duration(minutes: 3);
const maxStatusItems = 10;
const statusHours = 24;
// STUN finds a direct phone-to-phone route. Many mobile networks block direct routes,
// so a free public TURN relay is the fallback (it only forwards the already-encrypted
// DTLS stream; it cannot read the photo/video).
const _ice = {
  'iceServers': [
    {'urls': ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302']},
    {'urls': ['turn:openrelay.metered.ca:80', 'turn:openrelay.metered.ca:443', 'turn:openrelay.metered.ca:443?transport=tcp'],
     'username': 'openrelayproject', 'credential': 'openrelayproject'},
  ]
};

class VideoPost {
  final String id, owner, ownerName, title, audience; // audience: 'everyone' | 'friends' (= my contacts)
  final String kind; // 'video' | 'photo'
  final int durationMs, size;
  final DateTime createdAt, expiresAt;
  final int flags; // reports; hidden from others at 3+
  VideoPost(this.id, this.owner, this.ownerName, this.title, this.durationMs, this.size, this.createdAt, this.expiresAt, this.audience, [this.flags = 0, this.kind = 'video']);
  bool get isPhoto => kind == 'photo';
  factory VideoPost.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    DateTime ts(Object? v) => v is Timestamp ? v.toDate() : DateTime.now();
    return VideoPost(d.id, (m['owner'] ?? '') as String, (m['ownerName'] ?? '') as String, (m['title'] ?? '') as String,
        (m['durationMs'] ?? 0) as int, (m['size'] ?? 0) as int, ts(m['createdAt']), ts(m['expiresAt']), (m['audience'] ?? 'everyone') as String, (m['flags'] as List? ?? const []).length, (m['kind'] ?? 'video') as String);
  }
  bool get expired => DateTime.now().isAfter(expiresAt);
  String get daysLeft {
    final h = expiresAt.difference(DateTime.now()).inHours;
    if (h <= 0) return 'expired';
    if (h < 24) return '${h}h left';
    return '${(h / 24).ceil()} days left';
  }
}

class VideoRepo {
  static final _videos = db.collection('videos');
  static final _presence = db.collection('presence');

  static Future<File> localFile(String slotId) async {
    final dir = Directory('${(await getApplicationDocumentsDirectory()).path}/myvideos');
    if (!dir.existsSync()) dir.createSync(recursive: true);
    return File('${dir.path}/$slotId.mp4');
  }

  /// Public videos (audience = everyone).
  static Stream<List<VideoPost>> publicFeed() => _videos.where('audience', isEqualTo: 'everyone').limit(200).snapshots()
      .map((s) => s.docs.map(VideoPost.fromDoc).where((v) => !v.expired).toList());

  /// My own videos (both audiences).
  static Stream<List<VideoPost>> mine() => _videos.where('owner', isEqualTo: myUid).snapshots()
      .map((s) => s.docs.map(VideoPost.fromDoc).where((v) => !v.expired).toList());

  /// Status updates from people who have me in their contacts list (they added me as a viewer).
  /// Each owner keeps a tiny index doc (statusIdx/<uid>) listing which slots are in use,
  /// so we read only what exists.
  static Stream<List<VideoPost>> friendsFeed() => db.collectionGroup('friends').where('uid', isEqualTo: myUid).snapshots().asyncMap((s) async {
        final out = <VideoPost>[];
        await Future.wait(s.docs.map((d) async {
          final owner = d.reference.parent.parent!.id;
          try {
            final idx = await db.collection('statusIdx').doc(owner).get();
            final slots = List<int>.from((idx.data()?['slots'] as List?) ?? const []);
            for (final slot in slots) {
              try {
                final v = await _videos.doc('${owner}_$slot').get();
                if (v.exists) { final p = VideoPost.fromDoc(v); if (!p.expired && p.audience == 'friends') out.add(p); }
              } catch (_) {}
            }
          } catch (_) {}
        }));
        return out;
      });

  static Future<void> _reindex() async {
    try {
      final s = await _videos.where('owner', isEqualTo: myUid).get();
      final slots = <int>[];
      for (final d in s.docs) {
        if (VideoPost.fromDoc(d).expired) continue;
        final n = int.tryParse(d.id.split('_').last);
        if (n != null) slots.add(n);
      }
      slots.sort();
      await db.collection('statusIdx').doc(myUid).set({'slots': slots, 'at': FieldValue.serverTimestamp()});
    } catch (_) {}
  }

  /// First free status slot (1..10), or null when full.
  static Future<int?> freeSlot() async {
    final s = await _videos.where('owner', isEqualTo: myUid).get();
    final used = s.docs.where((d) => !VideoPost.fromDoc(d).expired).map((d) => d.id).toSet();
    for (var i = 1; i <= maxStatusItems; i++) { if (!used.contains('${myUid}_$i')) return i; }
    return null;
  }

  /// Adds my chat partners and matched phone contacts as status viewers (like WhatsApp contacts).
  static Future<void> addViewerIfNew(String uid, String name, String username) async {
    if (uid.isEmpty || uid == myUid) return;
    if ((await _excluded()).contains(uid)) return;
    final ref = _myFriends.doc(uid);
    try {
      if ((await ref.get()).exists) return;
      await ref.set({'uid': uid, 'name': name, 'username': username, 'at': FieldValue.serverTimestamp(), 'auto': true});
    } catch (_) {}
  }

  // friends list (people allowed to see my friends-only videos)
  static CollectionReference<Map<String, dynamic>> get _myFriends => db.collection('users').doc(myUid).collection('friends');
  static Stream<QuerySnapshot<Map<String, dynamic>>> friends() => _myFriends.snapshots();
  static Future<void> addFriend(AppUser u) async {
    final ex = await _excluded();
    if (ex.remove(u.uid)) await _saveExcluded(ex);
    await _myFriends.doc(u.uid).set({'uid': u.uid, 'name': u.name, 'username': u.username, 'at': FieldValue.serverTimestamp()});
  }
  static Future<void> removeFriend(String uid) async {
    final ex = await _excluded();
    ex.add(uid);
    await _saveExcluded(ex);
    await _myFriends.doc(uid).delete();
  }

  // People I removed from my status audience are never auto-added again (kept on this phone).
  static Future<File> _exFile() async => File('${(await getApplicationDocumentsDirectory()).path}/status_excluded_$myUid.json');
  static Future<Set<String>> _excluded() async {
    try { final f = await _exFile(); return f.existsSync() ? Set<String>.from(jsonDecode(await f.readAsString()) as List) : <String>{}; } catch (_) { return <String>{}; }
  }
  static Future<void> _saveExcluded(Set<String> s) async { try { await (await _exFile()).writeAsString(jsonEncode(s.toList())); } catch (_) {} }

  static Stream<VideoPost?> watch(String id) => _videos.doc(id).snapshots().map((d) => d.exists ? VideoPost.fromDoc(d) : null);

  static Future<void> post({required int slot, required File source, required String title, required int days, required int durationMs, required AppUser me, required String audience, String kind = 'video', int? hours}) async {
    final id = '${me.uid}_$slot';
    await delete(id); // replace whatever was in this slot
    final dst = await localFile(id);
    await source.copy(dst.path);
    final now = DateTime.now();
    await _videos.doc(id).set({
      'owner': me.uid,
      'ownerName': me.name,
      'title': title.trim(),
      'audience': audience,
      'kind': kind,
      'durationMs': durationMs,
      'size': await dst.length(),
      'createdAt': FieldValue.serverTimestamp(),
      'expiresAt': Timestamp.fromDate(now.add(hours != null ? Duration(hours: hours) : Duration(days: days))),
    });
    await _reindex();
    await Audit.log(kind == 'photo' ? 'status_photo_posted' : 'video_posted', ref: id, info: '${title.trim()} · $audience · ${hours != null ? '${hours}h' : '$days days'}');
  }

  /// Uploaders manage their own videos: change title, audience and how many days it stays up,
  /// or replace the video file (kept on this phone only).
  static Future<void> update(VideoPost v, {required String title, required String audience, required int days, File? newFile, int? durationMs}) async {
    final data = <String, Object>{
      'title': title.trim(),
      'audience': audience,
      'expiresAt': Timestamp.fromDate(DateTime.now().add(Duration(days: days))),
      'updatedAt': FieldValue.serverTimestamp(),
    };
    if (newFile != null) {
      final dst = await localFile(v.id);
      await newFile.copy(dst.path);
      data['size'] = await dst.length();
      if (durationMs != null) data['durationMs'] = durationMs;
    }
    await _videos.doc(v.id).update(data);
    await Audit.log('video_updated', ref: v.id, info: '${title.trim()} · $audience · $days days${newFile != null ? ' · video replaced' : ''}');
  }

  static Future<void> flag(String id) => _videos.doc(id).update({'flags': FieldValue.arrayUnion([myUid])});

  static Future<void> delete(String id) async {
    await _videos.doc(id).delete().catchError((_) {});
    await Reactions.deleteFor(id);
    final f = await localFile(id);
    if (f.existsSync()) f.deleteSync();
    if (id.startsWith(myUid)) await _reindex();
  }

  /// Removes my expired videos (card + local file).
  static Future<void> cleanupMine() async {
    for (var slot = 1; slot <= maxStatusItems; slot++) {
      final id = '${myUid}_$slot';
      final d = await _videos.doc(id).get();
      final f = await localFile(id);
      if (!d.exists || VideoPost.fromDoc(d).expired) {
        if (d.exists) await delete(id);
        if (f.existsSync()) f.deleteSync();
        await Reactions.deleteFor(id);
      }
    }
    await _reindex();
  }

  // presence: is the uploader's phone online with the app open?
  static Future<void> heartbeat() => _presence.doc(myUid).set({'at': FieldValue.serverTimestamp()});
  static Stream<bool> online(String uid) => _presence.doc(uid).snapshots().map((d) {
        final t = d.data()?['at'];
        return t is Timestamp && DateTime.now().difference(t.toDate()).inSeconds < 75;
      });
}

/// Runs on every signed-in phone while the app is open: keeps "online" presence
/// fresh and serves my own videos to viewers over peer-to-peer connections.
class VideoServer {
  static StreamSubscription? _sub;
  static Timer? _hb;
  static final Set<String> _handled = {};

  static void start() {
    if (_sub != null) return;
    VideoRepo.heartbeat();
    VideoRepo.cleanupMine();
    Reactions.listen();
    _hb = Timer.periodic(const Duration(seconds: 30), (_) => VideoRepo.heartbeat());
    _sub = db.collection('sessions').where('owner', isEqualTo: myUid).where('state', isEqualTo: 'offer').snapshots().listen((s) {
      for (final ch in s.docChanges) {
        if (ch.type == DocumentChangeType.added && _handled.add(ch.doc.id)) _serve(ch.doc);
      }
    }, onError: (_) {});
  }

  static void stop() {
    Reactions.stop();
    _sub?.cancel();
    _sub = null;
    _hb?.cancel();
    _hb = null;
  }

  static Future<void> _serve(DocumentSnapshot<Map<String, dynamic>> doc) async {
    final m = doc.data()!;
    final videoId = m['video'] as String;
    final v = await db.collection('videos').doc(videoId).get();
    final file = await VideoRepo.localFile(videoId);
    if (!v.exists || VideoPost.fromDoc(v).expired || !file.existsSync()) {
      await doc.reference.update({'state': 'unavailable'});
      return;
    }
    final pc = await createPeerConnection(_ice);
    final closeTimer = Timer(const Duration(minutes: 10), () => pc.close());
    pc.onIceCandidate = (c) { if (c.candidate != null) doc.reference.collection('ownerCand').add(c.toMap()); };
    pc.onDataChannel = (ch) {
      ch.onDataChannelState = (st) async {
        if (st == RTCDataChannelState.RTCDataChannelOpen) {
          await _sendFile(ch, file);
        }
      };
      ch.onMessage = (msg) {
        if (!msg.isBinary && msg.text == 'DONE') { closeTimer.cancel(); pc.close(); doc.reference.delete().catchError((_) {}); }
      };
    };
    final offer = m['offer'] as Map<String, dynamic>;
    await pc.setRemoteDescription(RTCSessionDescription(offer['sdp'] as String?, offer['type'] as String?));
    final answer = await pc.createAnswer({});
    await pc.setLocalDescription(answer);
    await doc.reference.update({'answer': answer.toMap(), 'state': 'answered'});
    doc.reference.collection('viewerCand').snapshots().listen((s) {
      for (final c in s.docChanges) {
        if (c.type != DocumentChangeType.added) continue;
        final d = c.doc.data()!;
        pc.addCandidate(RTCIceCandidate(d['candidate'] as String?, d['sdpMid'] as String?, d['sdpMLineIndex'] as int?));
      }
    });
  }

  static Future<void> _sendFile(RTCDataChannel ch, File file) async {
    final size = await file.length();
    await ch.send(RTCDataChannelMessage(jsonEncode({'size': size})));
    final raf = await file.open();
    try {
      const chunk = 16 * 1024;
      var sent = 0;
      while (sent < size) {
        while ((ch.bufferedAmount ?? 0) > 4 * 1024 * 1024) {
          await Future.delayed(const Duration(milliseconds: 20));
        }
        final bytes = await raf.read(chunk);
        if (bytes.isEmpty) break;
        await ch.send(RTCDataChannelMessage.fromBinary(bytes));
        sent += bytes.length;
      }
      await ch.send(RTCDataChannelMessage('END'));
    } finally {
      await raf.close();
    }
  }
}

/// Viewer side: asks the uploader's phone for the video and receives it directly.
Future<File?> fetchVideo(VideoPost v, void Function(double p, String status) onProgress) async {
  final pc = await createPeerConnection(_ice);
  final ch = await pc.createDataChannel('video', RTCDataChannelInit()..ordered = true);
  final done = Completer<File?>();
  final buf = BytesBuilder(copy: false);
  int total = 0;
  final queued = <RTCIceCandidate>[];
  var remoteSet = false;
  final subs = <StreamSubscription>[];

  ch.onMessage = (msg) async {
    if (msg.isBinary) {
      buf.add(msg.binary);
      if (total > 0) onProgress(buf.length / total, 'Receiving from the uploader\'s phone…');
    } else if (msg.text == 'END') {
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/watch_${v.id}_${DateTime.now().millisecondsSinceEpoch}.${v.isPhoto ? 'jpg' : 'mp4'}');
      await f.writeAsBytes(buf.takeBytes(), flush: true);
      await ch.send(RTCDataChannelMessage('DONE'));
      if (!done.isCompleted) done.complete(f);
    } else {
      try { total = (jsonDecode(msg.text) as Map)['size'] as int; } catch (_) {}
    }
  };

  final offer = await pc.createOffer({});
  await pc.setLocalDescription(offer);
  final ref = await db.collection('sessions').add({
    'owner': v.owner, 'viewer': myUid, 'video': v.id, 'offer': offer.toMap(), 'state': 'offer',
    'createdAt': FieldValue.serverTimestamp(), 'expireAt': Timestamp.fromDate(DateTime.now().add(const Duration(hours: 1))),
  });
  pc.onIceCandidate = (c) { if (c.candidate != null) ref.collection('viewerCand').add(c.toMap()); };
  onProgress(0, 'Connecting to the uploader\'s phone…');

  subs.add(ref.snapshots().listen((s) async {
    final d = s.data();
    if (d == null) return;
    if (d['state'] == 'unavailable' && !done.isCompleted) done.complete(null);
    final a = d['answer'];
    if (a is Map && !remoteSet) {
      remoteSet = true;
      await pc.setRemoteDescription(RTCSessionDescription(a['sdp'] as String?, a['type'] as String?));
      for (final c in queued) { await pc.addCandidate(c); }
      queued.clear();
    }
  }));
  subs.add(ref.collection('ownerCand').snapshots().listen((s) async {
    for (final c in s.docChanges) {
      if (c.type != DocumentChangeType.added) continue;
      final d = c.doc.data()!;
      final cand = RTCIceCandidate(d['candidate'] as String?, d['sdpMid'] as String?, d['sdpMLineIndex'] as int?);
      if (remoteSet) { await pc.addCandidate(cand); } else { queued.add(cand); }
    }
  }));

  // Give up if nothing arrives within 30 s of starting (phone offline / network blocks P2P).
  Timer(const Duration(seconds: 30), () { if (total == 0 && !done.isCompleted) done.complete(null); });
  final f = await done.future;
  for (final s in subs) { await s.cancel(); }
  Future.delayed(const Duration(seconds: 2), () => pc.close());
  return f;
}

// =============================== UI ===============================

class VideosScreen extends StatelessWidget {
  final AppUser me;
  const VideosScreen({super.key, required this.me});
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('5 Sec Videos', style: TextStyle(fontWeight: FontWeight.w800)), actions: [
        TextButton.icon(icon: const Icon(Icons.group_outlined), label: const Text('Friends'),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FriendsScreen(me: me)))),
      ]),
      body: StreamBuilder<List<String>>(
        stream: Repo.myBlocked(),
        builder: (context, bl) {
          final blocked = (bl.data ?? const <String>[]).toSet();
          return StreamBuilder<List<VideoPost>>(
            stream: VideoRepo.mine(),
            builder: (context, ms) => StreamBuilder<List<VideoPost>>(
              stream: VideoRepo.friendsFeed(),
              builder: (context, fs) => StreamBuilder<List<VideoPost>>(
                stream: VideoRepo.publicFeed(),
                builder: (context, ps) {
                  final mine = ms.data ?? const <VideoPost>[];
                  final seen = <String>{};
                  final others = [...(fs.data ?? const <VideoPost>[]), ...(ps.data ?? const <VideoPost>[])]
                      .where((v) => v.owner != me.uid && !blocked.contains(v.owner) && v.flags < 3 && seen.add(v.id)).toList()
                    ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
                  return ListView(padding: const EdgeInsets.all(12), children: [
                    Card(
                      color: cs.primaryContainer,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('My videos (${mine.length}/2)', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text('Stored only on this phone. People can watch while your phone is online with the app open.', style: TextStyle(color: cs.onPrimaryContainer)),
                          const SizedBox(height: 8),
                          for (final v in mine) ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(v.audience == 'friends' ? Icons.group : Icons.public),
                            title: Text(v.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                            subtitle: Text('${v.audience == 'friends' ? 'Friends only' : 'Everyone'} · ${v.daysLeft}'),
                            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                              IconButton(tooltip: 'Edit / update', icon: const Icon(Icons.edit_outlined),
                                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PostVideoScreen(me: me, slot: v.id.endsWith('_2') ? 2 : 1, existing: v)))),
                              IconButton(tooltip: 'End now', icon: const Icon(Icons.delete_outline), onPressed: () { VideoRepo.delete(v.id); Audit.log('video_ended', ref: v.id, info: v.title); }),
                            ]),
                            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPage(me: me, videoId: v.id))),
                          ),
                          if (mine.length < 2)
                            FilledButton.icon(
                              icon: const Icon(Icons.add),
                              label: const Text('Post a video'),
                              onPressed: () {
                                final used = mine.map((v) => v.id).toSet();
                                final slot = used.contains('${me.uid}_1') ? 2 : 1;
                                Navigator.push(context, MaterialPageRoute(builder: (_) => PostVideoScreen(me: me, slot: slot)));
                              },
                            ),
                        ]),
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (others.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Text('No videos yet.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant))),
                    for (final v in others) _VideoCard(v: v, me: me),
                  ]);
                },
              ),
            ),
          );
        },
      ),
    );
  }
}

class FriendsScreen extends StatefulWidget {
  final AppUser me;
  const FriendsScreen({super.key, required this.me});
  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> {
  final _q = TextEditingController();
  String? _msg;

  Future<void> _add() async {
    final u = await Repo.findByUsername(_q.text);
    if (u == null) { setState(() => _msg = 'No user with that username'); return; }
    if (u.uid == widget.me.uid) { setState(() => _msg = 'That\'s you'); return; }
    await VideoRepo.addFriend(u);
    _q.clear();
    setState(() => _msg = '${u.name} added');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Who can see my status')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Only the people on this list can see your status. People you chat with and phone contacts who use 5 Sec Text are added automatically — remove anyone with ⊖.'),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: TextField(controller: _q, onSubmitted: (_) => _add(), decoration: const InputDecoration(labelText: 'Add by username', prefixText: '@', border: OutlineInputBorder()))),
          const SizedBox(width: 8),
          IconButton.filled(icon: const Icon(Icons.person_add_alt_1), onPressed: _add),
        ]),
        if (_msg != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_msg!)),
        const SizedBox(height: 12),
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: VideoRepo.friends(),
          builder: (_, s) {
            final docs = s.data?.docs ?? const [];
            if (docs.isEmpty) return const Padding(padding: EdgeInsets.all(16), child: Text('No friends added yet.'));
            return Column(children: [
              for (final d in docs) ListTile(
                leading: const Icon(Icons.person_outline),
                title: Text((d.data()['name'] ?? '') as String),
                subtitle: Text(((d.data()['username'] ?? '') as String).isEmpty ? 'From your chats' : '@${d.data()['username']}'),
                trailing: IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => VideoRepo.removeFriend(d.id)),
              ),
            ]);
          },
        ),
      ]),
    );
  }
}

class _VideoCard extends StatelessWidget {
  final VideoPost v;
  final AppUser me;
  const _VideoCard({required this.v, required this.me});
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      child: ListTile(
        leading: StreamBuilder<bool>(
          stream: VideoRepo.online(v.owner),
          builder: (_, on) => Stack(children: [
            CircleAvatar(backgroundColor: cs.secondaryContainer, child: const Icon(Icons.play_arrow)),
            Positioned(right: 0, bottom: 0, child: CircleAvatar(radius: 6, backgroundColor: on.data == true ? Colors.green : Colors.grey)),
          ]),
        ),
        title: Text(v.title.isEmpty ? 'Video' : v.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('${v.ownerName} · ${v.daysLeft}', maxLines: 1, overflow: TextOverflow.ellipsis),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPage(me: me, videoId: v.id))),
      ),
    );
  }
}

class PostVideoScreen extends StatefulWidget {
  final AppUser me;
  final int slot;
  final VideoPost? existing; // set when editing one of my videos
  const PostVideoScreen({super.key, required this.me, required this.slot, this.existing});
  @override
  State<PostVideoScreen> createState() => _PostVideoScreenState();
}

class _PostVideoScreenState extends State<PostVideoScreen> {
  final _title = TextEditingController();
  int _days = 7;
  String _audience = 'everyone';
  File? _file;
  int _ms = 0;
  bool _busy = false;
  String? _err;

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final v = widget.existing;
    if (v != null) {
      _title.text = v.title;
      _audience = v.audience;
      _days = v.expiresAt.difference(DateTime.now()).inDays.clamp(1, 30).toInt();
      _ms = v.durationMs;
    }
  }

  Future<void> _pick(ImageSource src) async {
    final x = await ImagePicker().pickVideo(source: src, maxDuration: maxPostVideo);
    if (x == null) return;
    final f = File(x.path);
    final size = await f.length();
    if (size > maxPostVideoBytes) { setState(() => _err = 'Video is too large (max 150 MB).'); return; }
    int ms = 0;
    try { final vc = VideoPlayerController.file(f); await vc.initialize(); ms = vc.value.duration.inMilliseconds; await vc.dispose(); } catch (_) {}
    if (ms > maxPostVideo.inMilliseconds + 1000) { setState(() => _err = 'Video is too long (max 3 minutes).'); return; }
    setState(() => _err = 'Checking video…');
    if (await videoLooksUnsafe(f.path, ms)) {
      setState(() { _file = null; _err = 'This video is not allowed. Nudity or sexual content can\'t be posted.'; });
      return;
    }
    setState(() { _file = f; _ms = ms; _err = null; });
  }

  Future<void> _post() async {
    if (_title.text.trim().isEmpty || (!_editing && _file == null)) { setState(() => _err = 'Add a title and a video.'); return; }
    if (hasBlockedWords(_title.text)) { setState(() => _err = 'Adult or sexual content is not allowed.'); return; }
    setState(() => _busy = true);
    try {
      if (_editing) {
        await VideoRepo.update(widget.existing!, title: _title.text, audience: _audience, days: _days, newFile: _file, durationMs: _file != null ? _ms : null);
      } else {
        await VideoRepo.post(slot: widget.slot, source: _file!, title: _title.text, days: _days, durationMs: _ms, me: widget.me, audience: _audience);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() { _busy = false; _err = 'Could not post: $e'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Update video' : 'Post a video')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: _title, maxLength: 80, decoration: const InputDecoration(labelText: 'Title', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.videocam_outlined), label: Text(_editing ? 'Re-record' : 'Record'), onPressed: _busy ? null : () => _pick(ImageSource.camera))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.video_library_outlined), label: Text(_editing ? 'Replace from phone' : 'From phone'), onPressed: _busy ? null : () => _pick(ImageSource.gallery))),
        ]),
        if (_file != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text('✔ Video selected (${(_ms / 1000).round()} s)')),
        const SizedBox(height: 20),
        const Text('Who can watch?', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'everyone', label: Text('Everyone'), icon: Icon(Icons.public)),
            ButtonSegment(value: 'friends', label: Text('Friends only'), icon: Icon(Icons.group)),
          ],
          selected: {_audience},
          onSelectionChanged: (v) => setState(() => _audience = v.first),
        ),
        const SizedBox(height: 20),
        Text('Visible for $_days ${_days == 1 ? 'day' : 'days'}', style: const TextStyle(fontWeight: FontWeight.w700)),
        Slider(value: _days.toDouble(), min: 1, max: 30, divisions: 29, label: '$_days', onChanged: (v) => setState(() => _days = v.round())),
        Text('${_audience == 'friends' ? 'Your friends list' : 'Anyone with 5 Sec Text'} can watch, like and comment while your phone is online with the app open. '
            'The video stays only on your phone and is removed automatically when the time runs out.'),
        if (_err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_err!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        const SizedBox(height: 20),
        FilledButton(onPressed: _busy ? null : _post, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)), child: _busy ? const CircularProgressIndicator() : Text(_editing ? 'Save changes' : 'Post')),
      ]),
    );
  }
}

class VideoPage extends StatefulWidget {
  final AppUser me;
  final String videoId;
  const VideoPage({super.key, required this.me, required this.videoId});
  @override
  State<VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  VideoPlayerController? _vc;
  File? _temp;
  double _p = 0;
  String _status = '';
  bool _loading = false;
  final _comment = TextEditingController();
  int _likeTick = 0;

  bool get _isMine => widget.videoId.startsWith('${widget.me.uid}_');

  Future<void> _play(VideoPost v) async {
    if (_loading) return;
    setState(() { _loading = true; _status = 'Connecting…'; });
    File? f;
    if (_isMine) {
      f = await VideoRepo.localFile(v.id);
      if (!f.existsSync()) f = null;
    } else {
      f = await fetchVideo(v, (p, s) { if (mounted) setState(() { _p = p; _status = s; }); });
      _temp = f;
    }
    if (!mounted) return;
    if (f == null) {
      setState(() { _loading = false; _status = 'The uploader\'s phone is offline right now. Try again later.'; });
      return;
    }
    if (!_isMine) {
      setState(() => _status = 'Checking video…');
      if (await videoLooksUnsafe(f.path, v.durationMs, samples: 6)) {
        if (f.existsSync()) f.deleteSync();
        VideoRepo.flag(v.id).catchError((_) {});
        if (mounted) setState(() { _loading = false; _status = 'This video was blocked: it is not allowed on 5 Sec Text.'; });
        return;
      }
    }
    final vc = VideoPlayerController.file(f);
    await vc.initialize();
    await vc.play();
    if (!_isMine) Reactions.sendView(videoId: v.id, owner: v.owner, expiresAt: v.expiresAt, me: widget.me).catchError((_) {});
    if (mounted) setState(() { _vc = vc; _loading = false; _status = ''; });
  }

  @override
  void dispose() {
    _vc?.dispose();
    final t = _temp;
    if (t != null && t.existsSync()) t.deleteSync(); // never kept on the viewer's phone
    _comment.dispose();
    super.dispose();
  }

  Future<void> _report(VideoPost v) async {
    await VideoRepo.flag(v.id).catchError((_) {});
    await Repo.report(chatId: 'video:${v.id}', userUid: v.owner, reason: 'video report');
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reported. Thank you.')));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return StreamBuilder<VideoPost?>(
      stream: VideoRepo.watch(widget.videoId),
      builder: (context, snap) {
        final v = snap.data;
        if (v == null || v.expired) {
          return Scaffold(appBar: AppBar(), body: Center(child: Text(snap.hasData || snap.connectionState == ConnectionState.active ? 'This video is no longer available.' : '')));
        }
        final vc = _vc;
        return Scaffold(
          appBar: AppBar(title: Text(v.title, maxLines: 1, overflow: TextOverflow.ellipsis), actions: [
            if (!_isMine) PopupMenuButton<String>(
              onSelected: (s) {
                if (s == 'report') _report(v);
                if (s == 'block') Repo.block(v.owner).then((_) { if (context.mounted) Navigator.pop(context); });
                if (s == 'complain') Navigator.push(context, MaterialPageRoute(builder: (_) => ComplaintScreen(targetType: 'video', targetId: v.id, targetOwner: v.owner, targetLabel: v.title)));
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'report', child: Text('Report video (nudity, abuse, spam)')),
                PopupMenuItem(value: 'block', child: Text('Block uploader')),
                PopupMenuItem(value: 'complain', child: Text('Complain to Grievance Officer')),
              ],
            ),
          ]),
          body: Column(children: [
            AspectRatio(
              aspectRatio: vc != null && vc.value.isInitialized ? vc.value.aspectRatio : 16 / 9,
              child: Container(
                color: Colors.black,
                child: vc != null
                    ? GestureDetector(
                        onTap: () => setState(() => vc.value.isPlaying ? vc.pause() : vc.play()),
                        child: Stack(alignment: Alignment.bottomCenter, children: [VideoPlayer(vc), VideoProgressIndicator(vc, allowScrubbing: true)]),
                      )
                    : Center(
                        child: _loading
                            ? Column(mainAxisSize: MainAxisSize.min, children: [
                                CircularProgressIndicator(value: _p > 0 ? _p : null, color: Colors.white),
                                const SizedBox(height: 12),
                                Text(_status, style: const TextStyle(color: Colors.white70)),
                              ])
                            : Column(mainAxisSize: MainAxisSize.min, children: [
                                IconButton(iconSize: 64, color: Colors.white, icon: const Icon(Icons.play_circle_fill), onPressed: () => _play(v)),
                                if (_status.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(_status, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))),
                              ]),
                      ),
              ),
            ),
            ListTile(
              title: Text(v.title, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${v.ownerName} · ${v.daysLeft}'),
              trailing: _isMine ? null : FutureBuilder<bool>(
                key: ValueKey(_likeTick),
                future: Reactions.iLiked(v.id),
                builder: (_, l) {
                  final liked = l.data ?? false;
                  return IconButton(
                    icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? Colors.red : null),
                    onPressed: () async {
                      await Reactions.send(videoId: v.id, owner: v.owner, expiresAt: v.expiresAt, me: widget.me, kind: liked ? 'unlike' : 'like');
                      setState(() => _likeTick++);
                    },
                  );
                },
              ),
            ),
            const Divider(height: 1),
            Expanded(child: _isMine ? OwnerThread(videoId: v.id) : Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('Your like and comments go privately to ${v.ownerName}. Only they see them, and they disappear a few seconds after being seen.',
                    textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
              ),
            )),
            if (!_isMine) SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
                child: Row(children: [
                  Expanded(child: TextField(controller: _comment, maxLength: 300, decoration: const InputDecoration(hintText: 'Comment privately to the uploader', counterText: '', border: OutlineInputBorder()))),
                  const SizedBox(width: 6),
                  IconButton.filled(icon: const Icon(Icons.send), onPressed: () async {
                    final t = _comment.text.trim();
                    if (t.isEmpty) return;
                    _comment.clear();
                    try {
                      await Reactions.send(videoId: v.id, owner: v.owner, expiresAt: v.expiresAt, me: widget.me, kind: 'comment', text: t);
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sent privately to ${v.ownerName} ✓')));
                    } catch (e) {
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not send: $e')));
                    }
                  }),
                ]),
              ),
            ),
          ]),
        );
      },
    );
  }
}


/// The uploader's private thread for one video: running totals (views, likes)
/// and the new like / comment / view messages. Each message disappears
/// 5 seconds after it appears on screen; the totals stay.
class OwnerThread extends StatefulWidget {
  final String videoId;
  const OwnerThread({super.key, required this.videoId});
  @override
  State<OwnerThread> createState() => _OwnerThreadState();
}

class _OwnerThreadState extends State<OwnerThread> {
  VideoThread? _t;
  final Map<String, DateTime> _shownAt = {};
  final Map<String, Reaction> _onScreen = {};
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    Reactions.changed.addListener(_reload);
    _reload();
    _tick = Timer.periodic(const Duration(milliseconds: 250), (_) => _expire());
  }

  @override
  void dispose() {
    Reactions.changed.removeListener(_reload);
    _tick?.cancel();
    final ids = _onScreen.keys.toSet();
    if (ids.isNotEmpty) Reactions.consume(widget.videoId, ids); // seen = gone
    super.dispose();
  }

  Future<void> _reload() async {
    final t = await Reactions.load(widget.videoId);
    if (!mounted) return;
    final now = DateTime.now();
    for (final r in t.items) {
      _shownAt.putIfAbsent(r.id, () => now);
      _onScreen.putIfAbsent(r.id, () => r);
    }
    setState(() => _t = t);
  }

  void _expire() {
    if (!mounted || _onScreen.isEmpty) return;
    final now = DateTime.now();
    final done = _shownAt.entries.where((e) => _onScreen.containsKey(e.key) && now.difference(e.value).inMilliseconds >= viewSeconds * 1000).map((e) => e.key).toSet();
    if (done.isNotEmpty) {
      done.forEach(_onScreen.remove);
      Reactions.consume(widget.videoId, done);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final t = _t;
    final items = _onScreen.values.toList()..sort((a, b) => a.at.compareTo(b.at));
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          _Counter(icon: Icons.visibility, color: cs.primary, value: t?.views ?? 0, label: 'views'),
          _Counter(icon: Icons.favorite, color: Colors.red, value: t?.likes ?? 0, label: 'likes'),
        ]),
      ),
      const Divider(height: 1),
      Expanded(
        child: items.isEmpty
            ? Center(child: Text('No new likes or comments.\nNew ones appear here and vanish $viewSeconds s after you see them.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)))
            : ListView(padding: const EdgeInsets.all(10), children: [
                for (final r in items)
                  Builder(builder: (_) {
                    final left = (viewSeconds * 1000 - DateTime.now().difference(_shownAt[r.id] ?? DateTime.now()).inMilliseconds).clamp(0, viewSeconds * 1000);
                    return Opacity(
                      opacity: (left / 1000).clamp(0.15, 1.0),
                      child: Card(
                        child: ListTile(
                          leading: Icon(r.kind == 'like' ? Icons.favorite : r.kind == 'view' ? Icons.visibility : Icons.chat_bubble_outline, color: r.kind == 'like' ? Colors.red : cs.primary),
                          title: Text(r.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(r.label),
                          trailing: Text('${(left / 1000).ceil()}s', style: TextStyle(color: cs.error, fontWeight: FontWeight.w700)),
                        ),
                      ),
                    );
                  }),
              ]),
      ),
    ]);
  }
}

class _Counter extends StatelessWidget {
  final IconData icon;
  final Color color;
  final int value;
  final String label;
  const _Counter({required this.icon, required this.color, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(width: 6),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
          child: Text('$value', key: ValueKey(value), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        ),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
      ]);
}
