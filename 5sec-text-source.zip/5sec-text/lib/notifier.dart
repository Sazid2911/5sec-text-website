// The "5 Sec Text" signature tone "Vanish": a bright two-note rising chime that
// dissolves into a soft whoosh (the message disappearing). Played for every new
// message / video reaction.
// * App open: the tone plays in the app.
// * App in the background: a notification with the same tone. For privacy the
//   notification never shows names or message text - just "New message".
// Note: notifications while the app is fully closed would need a push server;
// this version uses no paid services, so it alerts while the app is running.
import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:just_audio/just_audio.dart';
import 'package:permission_handler/permission_handler.dart';

import 'bg_service.dart';

import 'data.dart';
import 'reactions.dart';

class Notifier {
  static final _player = AudioPlayer();
  static final _fln = FlutterLocalNotificationsPlugin();
  static StreamSubscription? _sub;
  static AppLifecycleListener? _life;
  static bool _foreground = true;
  static Set<String>? _known;
  static int _lastReactions = -1;
  static int _id = 0;

  // ---- on/off setting (asked once after install, changeable in Settings) ----
  static const _store = FlutterSecureStorage();
  static const _key = 'notifications_on';
  /// null = not asked yet.
  static bool? enabled;
  static Future<void> loadSetting() async {
    try { final v = await _store.read(key: _key); enabled = v == null ? null : v == '1'; } catch (_) {}
  }
  /// Turns notifications on/off. Turning on asks Android for permission; returns false if the phone blocks it.
  static Future<bool> setEnabled(bool on) async {
    enabled = on;
    await _store.write(key: _key, value: on ? '1' : '0');
    if (!on) { await BgService.stop(); return true; }
    final android = _fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final ok = await android?.requestNotificationsPermission();
    // Let the background service keep running on phones that close apps to save battery.
    try { if (!await Permission.ignoreBatteryOptimizations.isGranted) await Permission.ignoreBatteryOptimizations.request(); } catch (_) {}
    await BgService.start();
    _fgPing();
    return ok ?? true;
  }

  static const _channel = AndroidNotificationChannel(
    'messages_5sec', 'Messages',
    description: 'New 5 Sec Text messages',
    importance: Importance.high,
    playSound: true,
    sound: RawResourceAndroidNotificationSound('five_sec_tone'),
  );

  static Future<void> start(String me) async {
    if (_sub != null) return;
    await _fln.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    ));
    final android = _fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(_channel);
    await loadSetting();
    if (enabled == true) await android?.requestNotificationsPermission();
    _life = AppLifecycleListener(onStateChange: (s) {
      _foreground = s == AppLifecycleState.resumed;
      BgService.setForeground(_foreground);
    });
    // Background service: alerts for new messages while the app is closed.
    if (enabled != false) { await BgService.start(); _fgPing(); }

    _sub = Repo.myChats().listen((chats) {
      final now = {for (final c in chats.where((c) => c.hasNewFor(me))) '${c.id}@${c.updatedAt.millisecondsSinceEpoch}'};
      final first = _known == null;
      final fresh = first ? <String>{} : now.difference(_known!);
      _known = now;
      if (fresh.isNotEmpty) ping();
    });
    Reactions.changed.addListener(_onReaction);
  }

  static void _onReaction() async {
    final n = (await Reactions.unreadThreads()).fold<int>(0, (s, t) => s + t.unread);
    if (_lastReactions >= 0 && n > _lastReactions) ping(text: 'New activity on your status');
    _lastReactions = n;
  }

  static Timer? _fgTimer;
  /// Keeps telling the background service whether the app is on screen (so it doesn't double-alert).
  static void _fgPing() {
    _fgTimer?.cancel();
    BgService.setForeground(_foreground);
    _fgTimer = Timer.periodic(const Duration(seconds: 10), (_) => BgService.setForeground(_foreground));
  }

  static Future<void> ping({String text = 'New message'}) async {
    if (enabled == false) return; // switched off in Settings
    if (!_foreground && await BgService.running()) return; // the background service shows it
    if (_foreground) {
      try {
        await _player.setAsset('assets/sounds/five_sec_tone.ogg');
        await _player.play();
      } catch (_) {}
    } else {
      await _fln.show(_id++ % 1000, '5 Sec Text', text, NotificationDetails(
        android: AndroidNotificationDetails(_channel.id, _channel.name,
            channelDescription: _channel.description, importance: Importance.high, priority: Priority.high,
            sound: const RawResourceAndroidNotificationSound('five_sec_tone'), playSound: true, visibility: NotificationVisibility.secret),
        iOS: const DarwinNotificationDetails(sound: 'five_sec_tone.wav', presentSound: true),
      ));
    }
  }

  static void stop() {
    _fgTimer?.cancel();
    BgService.stop();
    _sub?.cancel();
    _sub = null;
    _known = null;
    _life?.dispose();
    Reactions.changed.removeListener(_onReaction);
  }
}
