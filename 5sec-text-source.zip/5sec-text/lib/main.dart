import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_theme.dart';
import 'auth_screen.dart';
import 'data.dart';
import 'firebase_options.dart';

const appName = '5 Sec Text';
const brand = Color(0xFF2E9E4F); // default theme colour (Green); users can change it in Settings
const siteUrl = 'https://5sectext.com';
const privacyUrl = '$siteUrl/privacy.html';
const termsUrl = '$siteUrl/terms.html';

/// Current Terms of Use version. Raise it when terms.html changes: every user
/// must accept the new version before using the app again.
const termsVersion = 1;

/// Grievance Officer (IT Rules 2021, Rule 3(2)). Must be filled in before launch.
const grievanceName = 'Mohammed Sajid Sheikh';
const grievanceEmail = 'fivesectext@gmail.com';
const grievanceAddress = 'Ground Floor, Durgapur Road, Tukum, Chandrapur-442401, Maharashtra, India';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.android);
  await ViewTime.load();
  await AppTheme.load();
  runApp(const FiveSecApp());
}

class FiveSecApp extends StatelessWidget {
  const FiveSecApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: AppTheme.color,
      builder: (context, seed, _) => MaterialApp(
      title: appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: seed, useMaterial3: true, brightness: Brightness.light),
      darkTheme: ThemeData(colorSchemeSeed: seed, useMaterial3: true, brightness: Brightness.dark),
      home: SimGate(child: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Splash();
          final user = snap.data;
          if (user == null) return const AuthScreen();
          if (!user.emailVerified) return const VerifyEmailScreen();
          return FutureBuilder<void>(
            future: _freshToken(user),
            builder: (context, t) => t.connectionState == ConnectionState.done ? ProfileGate(uid: user.uid) : const Splash(),
          );
        },
      )),
    ),
    );
  }
}

/// Firestore rules require a verified email. A token issued before the user tapped the
/// verification link still says "not verified", so refresh it once when needed.
final Map<String, Future<void>> _refreshes = {};
Future<void> _freshToken(User user) => _refreshes[user.uid] ??= () async {
      try {
        final r = await user.getIdTokenResult();
        if (r.claims?['email_verified'] != true) await user.getIdToken(true);
      } catch (_) {}
    }();

class Splash extends StatelessWidget {
  const Splash({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: CircularProgressIndicator()));
}

/// The app only works while an active SIM card is in the phone.
/// Checked at start and every time the app comes back to the foreground.
class SimGate extends StatefulWidget {
  final Widget child;
  const SimGate({super.key, required this.child});
  @override
  State<SimGate> createState() => _SimGateState();
}

class _SimGateState extends State<SimGate> with WidgetsBindingObserver {
  static const _ch = MethodChannel('fivesec/device');
  bool? _ok;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _check();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _check();
  }

  Future<void> _check() async {
    bool ok;
    try {
      ok = await _ch.invokeMethod<bool>('simReady') ?? false;
    } catch (_) {
      ok = false;
    }
    if (mounted) setState(() => _ok = ok);
  }

  @override
  Widget build(BuildContext context) {
    if (_ok == null) return const Splash();
    if (_ok == true) return widget.child;
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.sim_card_alert_outlined, size: 72, color: cs.error),
              const SizedBox(height: 16),
              const Text('Active SIM card needed', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text('$appName only works on a phone with an active SIM card inserted.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
              const SizedBox(height: 24),
              FilledButton(onPressed: _check, child: const Text('Check again')),
            ]),
          ),
        ),
      ),
    );
  }
}
