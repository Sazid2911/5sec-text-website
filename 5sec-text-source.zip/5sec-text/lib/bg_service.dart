// Background service: keeps watching for new messages while the app is closed,
// so the "New message" notification (with the 5 Sec tone) arrives without
// opening the app. Free - no push server needed.
// * Runs as an Android foreground service with a small silent
//   "5 Sec Text is active" notification (Android requires one).
// * Notifications never show names or message text - just "New message".
// * Turned on/off with Settings → Notifications.
import 'dart:async';
import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'firebase_options.dart';

const _statusChannel = AndroidNotificationChannel('bg_5sec', 'Running in background',
    description: 'Keeps 5 Sec Text ready to alert you about new messages', importance: Importance.min, playSound: false, showBadge: false);
const _msgChannel = AndroidNotificationChannel('messages_5sec', 'Messages',
    description: 'New 5 Sec Text messages', importance: Importance.high, playSound: true,
    sound: RawResourceAndroidNotificationSound('five_sec_tone'));
const _statusId = 5501;

class BgService {
  static final _svc = FlutterBackgroundService();
  static bool _configured = false;

  static Future<void> _configure() async {
    if (_configured) return;
    final fln = FlutterLocalNotificationsPlugin();
    final android = fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(_statusChannel);
    await android?.createNotificationChannel(_msgChannel);
    await _svc.configure(
      androidConfiguration: AndroidConfiguration(
        onStart: bgMain,
        autoStart: false,
        autoStartOnBoot: true,
        isForegroundMode: true,
        notificationChannelId: _statusChannel.id,
        initialNotificationTitle: '5 Sec Text',
        initialNotificationContent: 'Ready for new messages',
        foregroundServiceNotificationId: _statusId,
        foregroundServiceTypes: [AndroidForegroundType.remoteMessaging],
      ),
      iosConfiguration: IosConfiguration(autoStart: false),
    );
    _configured = true;
  }

  static Future<void> start() async {
    try {
      await _configure();
      if (!await _svc.isRunning()) await _svc.startService();
    } catch (_) {}
  }

  static Future<void> stop() async {
    try { if (await _svc.isRunning()) _svc.invoke('stop'); } catch (_) {}
  }

  static Future<bool> running() async { try { return await _svc.isRunning(); } catch (_) { return false; } }

  /// The app tells the service when it is on screen (then the app plays the tone itself).
  static void setForeground(bool fg) { try { _svc.invoke('fg', {'on': fg}); } catch (_) {} }
}

/// Entry point of the background isolate.
@pragma('vm:entry-point')
Future<void> bgMain(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();
  WidgetsFlutterBinding.ensureInitialized();
  try { await Firebase.initializeApp(options: DefaultFirebaseOptions.android); } catch (_) {}

  final fln = FlutterLocalNotificationsPlugin();
  await fln.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
  var appOnScreen = false;
  var id = 100;
  StreamSubscription? chatsSub, inboxSub, authSub;
  Set<String>? known;
  int? lastInbox;

  service.on('stop').listen((_) async {
    await chatsSub?.cancel(); await inboxSub?.cancel(); await authSub?.cancel();
    await service.stopSelf();
  });
  service.on('fg').listen((e) => appOnScreen = e?['on'] == true);

  Future<bool> allowed() async {
    try { return await const FlutterSecureStorage().read(key: 'notifications_on') != '0'; } catch (_) { return true; }
  }

  Future<void> notify(String text) async {
    if (appOnScreen || !await allowed()) return;
    await fln.show(id++ % 1000 + 100, '5 Sec Text', text, NotificationDetails(
      android: AndroidNotificationDetails(_msgChannel.id, _msgChannel.name,
          channelDescription: _msgChannel.description, importance: Importance.high, priority: Priority.high,
          sound: const RawResourceAndroidNotificationSound('five_sec_tone'), playSound: true,
          visibility: NotificationVisibility.secret, autoCancel: true),
    ));
  }

  void watch(User? user) {
    chatsSub?.cancel(); inboxSub?.cancel();
    known = null; lastInbox = null;
    if (user == null) return;
    final me = user.uid;
    final db = FirebaseFirestore.instance;
    chatsSub = db.collection('chats').where('members', arrayContains: me).snapshots().listen((s) {
      final now = <String>{};
      for (final d in s.docs) {
        final m = d.data();
        final from = (m['lastFrom'] ?? '') as String;
        final up = m['updatedAt'];
        if (from.isEmpty || from == me || up is! Timestamp) continue;
        final seen = (m['seenAt'] is Map) ? (m['seenAt'] as Map)[me] : null;
        if (seen is Timestamp && !up.toDate().isAfter(seen.toDate())) continue;
        now.add('${d.id}@${up.millisecondsSinceEpoch}');
      }
      final fresh = known == null ? <String>{} : now.difference(known!);
      known = now;
      if (fresh.isNotEmpty) notify('New message');
    }, onError: (_) {});
    inboxSub = db.collection('inbox').doc(me).collection('items').snapshots().listen((s) {
      final n = s.size;
      if (lastInbox != null && n > lastInbox!) notify('New activity on your status');
      lastInbox = n;
    }, onError: (_) {});
  }

  authSub = FirebaseAuth.instance.authStateChanges().listen(watch);
}
