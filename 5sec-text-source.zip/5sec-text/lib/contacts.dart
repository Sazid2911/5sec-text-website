import 'dart:async';
// Find friends from the phone's contacts, by the name you saved them under.
//
// Privacy design:
// * A mobile number is OPTIONAL. Sign-in stays email-only. If a user adds their
//   number, only a scrambled code (SHA-256 hash with an app key) is stored on the
//   server, in phones/<hash> -> {uid}. The number itself stays on that phone.
// * Reading contacts needs the user's permission (shown with a clear notice first).
//   The contact list is read on the phone and is never uploaded or stored. For each
//   contact the app sends only the scrambled code of the number to check whether
//   someone on 5 Sec Text added that number.
// * Numbers are not verified by SMS (that costs money), so the app always shows the
//   person's @username so you can confirm it is really them.
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cryptography/cryptography.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:permission_handler/permission_handler.dart';

import 'audit.dart';
import 'chat_screen.dart';
import 'data.dart';
import 'videos.dart';

const _pepper = '5sectext-contacts-v1';

/// Country dial codes offered when adding a number (Phase 1 countries first).
const dialCodes = <String, String>{
  '+91': 'India',
  '+92': 'Pakistan',
  '+880': 'Bangladesh',
  '+966': 'Saudi Arabia',
  '+971': 'UAE',
  '+974': 'Qatar',
  '+968': 'Oman',
  '+965': 'Kuwait',
  '+973': 'Bahrain',
  '+44': 'United Kingdom',
  '+1': 'USA / Canada',
};

const inviteText = 'Join me on 5 Sec Text: messages disappear 5 seconds after they are read. https://5sectext.com';

class PhoneIndex {
  static const _store = FlutterSecureStorage();
  static final _phones = db.collection('phones');
  static final Map<String, AppUser?> _cache = {};

  /// Returns +<digits> (E.164 style) or null if it doesn't look like a phone number.
  static String? normalize(String raw, String defaultCc) {
    var s = raw.replaceAll(RegExp(r'[^\d+]'), '');
    if (s.startsWith('00')) s = '+${s.substring(2)}';
    if (!s.startsWith('+')) s = '$defaultCc${s.replaceFirst(RegExp(r'^0+'), '')}';
    final digits = s.replaceAll('+', '');
    if (digits.length < 8 || digits.length > 15) return null;
    return '+$digits';
  }

  static Future<String> hash(String e164) async {
    final h = await Sha256().hash(utf8.encode('$_pepper|$e164'));
    return base64Url.encode(h.bytes).replaceAll('=', '');
  }

  static Future<String?> myNumber() => _store.read(key: 'my_phone_$myUid');

  /// The country code of my own number, used for contacts saved without +code.
  static Future<String> myCc() async {
    final n = await myNumber();
    if (n != null) {
      final codes = dialCodes.keys.toList()..sort((a, b) => b.length.compareTo(a.length));
      for (final cc in codes) {
        if (n.startsWith(cc)) return cc;
      }
    }
    return '+91';
  }

  static Future<void> setMyNumber(String cc, String local) async {
    final e164 = normalize(local, cc);
    if (e164 == null) throw 'Enter a valid mobile number';
    final h = await hash(e164);
    final ref = _phones.doc(h);
    final existing = await ref.get();
    final owner = existing.data()?['uid'];
    if (existing.exists && owner != myUid) {
      throw 'This number is already linked to another 5 Sec Text account. If it is yours, contact support.';
    }
    final me = await db.collection('users').doc(myUid).get();
    final old = me.data()?['phoneHash'] as String?;
    if (old != null && old != h) await _phones.doc(old).delete().catchError((_) {});
    if (!existing.exists) await ref.set({'uid': myUid, 'at': FieldValue.serverTimestamp()});
    await me.reference.update({'phoneHash': h});
    await _store.write(key: 'my_phone_$myUid', value: e164);
    await Audit.log('phone_added');
  }

  static Future<void> removeMyNumber() async {
    final me = await db.collection('users').doc(myUid).get();
    final h = me.data()?['phoneHash'] as String?;
    if (h != null) {
      await _phones.doc(h).delete().catchError((_) {});
      await me.reference.update({'phoneHash': FieldValue.delete()});
      await Audit.log('phone_removed');
    }
    await _store.delete(key: 'my_phone_$myUid');
  }

  /// Who on 5 Sec Text added this number (null = nobody).
  static Future<AppUser?> lookup(String e164) async {
    if (_cache.containsKey(e164)) return _cache[e164];
    AppUser? found;
    try {
      final d = await _phones.doc(await hash(e164)).get();
      final uid = d.data()?['uid'] as String?;
      if (uid != null && uid != myUid) {
        final u = await db.collection('users').doc(uid).get();
        if (u.exists) found = AppUser.fromDoc(u);
      }
    } catch (_) {}
    _cache[e164] = found;
    // A phone contact who is on the app can see my status (like WhatsApp). Removable in "Who can see my status".
    if (found != null) VideoRepo.addViewerIfNew(found.uid, found.name, found.username);
    return found;
  }

  static bool checked(String e164) => _cache.containsKey(e164);
  static AppUser? cached(String e164) => _cache[e164];
}

/// Usernames I linked myself to contacts saved in my phone. Kept ONLY on this phone
/// (encrypted storage), never uploaded. Key = the phone contact's id.
class LocalLinks {
  static const _store = FlutterSecureStorage();
  static Map<String, Map<String, String>> _links = {};
  static String get _key => 'contact_links_$myUid';

  static Future<void> load() async {
    try {
      final raw = await _store.read(key: _key);
      if (raw == null) { _links = {}; return; }
      _links = (jsonDecode(raw) as Map).map((k, v) => MapEntry(k as String, Map<String, String>.from(v as Map)));
    } catch (_) {
      _links = {};
    }
  }

  static AppUser? userFor(String contactId) {
    final l = _links[contactId];
    return l == null ? null : AppUser(l['uid']!, l['name'] ?? '', l['username'] ?? '');
  }

  static Future<void> link(String contactId, AppUser u) async {
    _links[contactId] = {'uid': u.uid, 'name': u.name, 'username': u.username};
    await _store.write(key: _key, value: jsonEncode(_links));
  }

  static Future<void> unlink(String contactId) async {
    _links.remove(contactId);
    await _store.write(key: _key, value: jsonEncode(_links));
  }
}

/// Dialog to add or change my own number. Returns true if saved.
Future<bool> showPhoneDialog(BuildContext context) async {
  final ctl = TextEditingController();
  var cc = await PhoneIndex.myCc();
  if (!context.mounted) return false;
  String? err;
  var busy = false;
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, setD) => AlertDialog(
        title: const Text('Your mobile number (optional)'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Friends who have this number saved will see you in their contacts on 5 Sec Text. '
              'It is stored only as a scrambled code and is never shown to anyone. You can remove it any time.'),
          const SizedBox(height: 12),
          Row(children: [
            DropdownButton<String>(
              value: cc,
              items: [for (final e in dialCodes.entries) DropdownMenuItem(value: e.key, child: Text(e.key))],
              onChanged: (v) => setD(() => cc = v ?? cc),
            ),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: ctl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile number'))),
          ]),
          if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: TextStyle(color: Theme.of(c).colorScheme.error))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(
            onPressed: busy
                ? null
                : () async {
                    setD(() { busy = true; err = null; });
                    try {
                      await PhoneIndex.setMyNumber(cc, ctl.text);
                      if (c.mounted) Navigator.pop(c, true);
                    } catch (e) {
                      setD(() { busy = false; err = '$e'; });
                    }
                  },
            child: const Text('Save'),
          ),
        ],
      ),
    ),
  );
  return ok == true;
}

class _Contact {
  final String id, name;
  final List<String> numbers; // normalised
  _Contact(this.id, this.name, this.numbers);
}

/// Phone contacts, searchable by the name you saved them under (or by @username).
class ContactsScreen extends StatefulWidget {
  final AppUser me;
  const ContactsScreen({super.key, required this.me});
  @override
  State<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  final _q = TextEditingController();
  Timer? _debounce;
  String _onlineFor = '';
  List<AppUser> _online = [];
  bool? _allowed;
  bool _loading = false, _scanning = false;
  int _scanned = 0;
  List<_Contact> _contacts = [];
  String? _myNumber;
  final Set<String> _checking = {};

  @override
  void initState() {
    super.initState();
    _init();
    _q.addListener(() {
      setState(() {});
      _debounce?.cancel();
      _debounce = Timer(const Duration(milliseconds: 400), _searchOnline);
    });
  }

  Future<void> _searchOnline() async {
    final q = _q.text.trim();
    if (q == _onlineFor) return;
    _onlineFor = q;
    final r = q.length < 2 ? <AppUser>[] : await Repo.searchUsers(q);
    if (mounted && _q.text.trim() == q) setState(() => _online = r);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _q.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    _myNumber = await PhoneIndex.myNumber();
    final granted = await Permission.contacts.isGranted;
    if (!mounted) return;
    setState(() => _allowed = granted);
    if (granted) await _load();
  }

  Future<void> _ask() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Find friends from your contacts'),
        content: const Text('5 Sec Text will read the names and numbers in your phone contacts, on this phone only, '
            'to show which of your contacts use 5 Sec Text.\n\n'
            'Your contact list is never uploaded or stored. Only a scrambled code of each number is checked. '
            'You can turn this off any time in your phone settings.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Not now')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Continue')),
        ],
      ),
    );
    if (yes != true) return;
    final ok = await FlutterContacts.requestPermission(readonly: true);
    if (!mounted) return;
    setState(() => _allowed = ok);
    if (ok) {
      await _load();
    } else if (await Permission.contacts.isPermanentlyDenied) {
      openAppSettings();
    }
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    await LocalLinks.load();
    final cc = await PhoneIndex.myCc();
    final raw = await FlutterContacts.getContacts(withProperties: true);
    final list = <_Contact>[];
    for (final c in raw) {
      final nums = <String>{};
      for (final p in c.phones) {
        final n = PhoneIndex.normalize(p.normalizedNumber.isNotEmpty ? p.normalizedNumber : p.number, cc);
        if (n != null) nums.add(n);
      }
      if (nums.isNotEmpty && c.displayName.trim().isNotEmpty) list.add(_Contact(c.id, c.displayName.trim(), nums.toList()));
    }
    list.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    if (!mounted) return;
    setState(() { _contacts = list; _loading = false; });
  }

  AppUser? _userFor(_Contact c) {
    final linked = LocalLinks.userFor(c.id);
    if (linked != null) return linked;
    for (final n in c.numbers) {
      final u = PhoneIndex.cached(n);
      if (u != null) return u;
    }
    return null;
  }

  bool _isChecked(_Contact c) => c.numbers.every(PhoneIndex.checked);

  /// Checks only the contacts currently on screen (keeps database reads low).
  void _checkVisible(List<_Contact> shown) {
    for (final c in shown.take(25)) {
      for (final n in c.numbers) {
        if (PhoneIndex.checked(n) || _checking.contains(n)) continue;
        _checking.add(n);
        PhoneIndex.lookup(n).then((_) {
          _checking.remove(n);
          if (mounted) setState(() {});
        });
      }
    }
  }

  Future<void> _scanAll() async {
    setState(() { _scanning = true; _scanned = 0; });
    for (final c in _contacts) {
      for (final n in c.numbers) {
        await PhoneIndex.lookup(n);
      }
      if (!mounted) return;
      setState(() => _scanned++);
    }
    if (mounted) setState(() => _scanning = false);
  }

  Future<void> _chat(AppUser u) async {
    final id = await Repo.openDirectChat(widget.me, u);
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: id, me: widget.me)));
  }

  Future<void> _byUsername(String q) async {
    final u = await Repo.findByUsername(q);
    if (!mounted) return;
    if (u == null || u.uid == widget.me.uid) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(u == null ? 'No user with username @${q.replaceAll('@', '')}' : 'That\'s you 🙂')));
    } else {
      _chat(u);
    }
  }

  /// Link a 5 Sec Text username to a contact saved in my phone (stored only on this phone).
  Future<void> _linkUsername(_Contact c) async {
    final ctl = TextEditingController();
    String? err;
    AppUser? found;
    var busy = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, setD) => AlertDialog(
          title: Text('Link a username to ${c.name}'),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Type their 5 Sec Text username. The link is saved only on your phone, so you can find them by the name in your contacts.'),
            const SizedBox(height: 12),
            TextField(
              controller: ctl,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Username', prefixText: '@', border: OutlineInputBorder()),
              onChanged: (_) => setD(() { found = null; err = null; }),
            ),
            if (found != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: CircleAvatar(child: Text(found!.name.isEmpty ? '?' : found!.name[0].toUpperCase())),
                  title: Text(found!.name),
                  subtitle: Text('@${found!.username}'),
                ),
              ),
            if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: TextStyle(color: Theme.of(d).colorScheme.error))),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
            FilledButton(
              onPressed: busy
                  ? null
                  : () async {
                      if (found != null) { Navigator.pop(d, true); return; }
                      setD(() { busy = true; err = null; });
                      final u = await Repo.findByUsername(ctl.text);
                      setD(() {
                        busy = false;
                        if (u == null) {
                          err = 'No user with that username';
                        } else if (u.uid == widget.me.uid) {
                          err = 'That\'s you 🙂';
                        } else {
                          found = u;
                        }
                      });
                    },
              child: Text(found == null ? 'Find' : 'Link'),
            ),
          ],
        ),
      ),
    );
    if (ok == true && found != null) {
      await LocalLinks.link(c.id, found!);
      if (mounted) {
        setState(() {});
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('@${found!.username} linked to ${c.name}')));
      }
    }
  }

  Future<void> _unlink(_Contact c) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text('Remove link for ${c.name}?'),
        content: const Text('This only removes the link on your phone. Your chats are not affected.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Remove link')),
        ],
      ),
    );
    if (yes == true) {
      await LocalLinks.unlink(c.id);
      if (mounted) setState(() {});
    }
  }

  void _invite() {
    Clipboard.setData(const ClipboardData(text: inviteText));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invite copied. Paste it in SMS or any chat app.')));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final q = _q.text.trim();
        final qDigits = q.replaceAll(RegExp(r'\D'), '');
    final shown = q.isEmpty
        ? _contacts
        : _contacts.where((c) {
            final u = _userFor(c);
            return matchesWords('${c.name} ${u?.name ?? ''} ${u?.username ?? ''}', q) || (qDigits.length >= 3 && c.numbers.any((n) => n.contains(qDigits)));
          }).toList();
    final onApp = _contacts.where((c) => _userFor(c) != null).toList();
    if (_allowed == true && !_loading) WidgetsBinding.instance.addPostFrameCallback((_) => _checkVisible(shown));

    return Scaffold(
      appBar: AppBar(title: const Text('Find friends')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: TextField(
            controller: _q,
            textInputAction: TextInputAction.search,
            onSubmitted: (v) { if (v.trim().startsWith('@')) _byUsername(v); },
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: 'Search a contact name, number or @username',
              filled: true,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
            ),
          ),
        ),
        if (_myNumber == null)
          Card(
            margin: const EdgeInsets.fromLTRB(12, 6, 12, 2),
            color: cs.primaryContainer,
            child: ListTile(
              leading: const Icon(Icons.phone_iphone),
              title: const Text('Let friends find you'),
              subtitle: const Text('Add your mobile number (optional) so people who saved it can see you here.'),
              trailing: TextButton(
                onPressed: () async { if (await showPhoneDialog(context)) { _myNumber = await PhoneIndex.myNumber(); if (mounted) setState(() {}); } },
                child: const Text('Add'),
              ),
            ),
          ),
        Expanded(child: _body(cs, q, shown, onApp)),
      ]),
    );
  }

  Widget _body(ColorScheme cs, String q, List<_Contact> shown, List<_Contact> onApp) {
    final usernameTile = q.isEmpty
        ? null
        : ListTile(
            leading: const CircleAvatar(child: Icon(Icons.alternate_email)),
            title: Text('Search @${q.replaceAll('@', '').toLowerCase()} as a username'),
            onTap: () => _byUsername(q),
          );
    if (_allowed == null || _loading) return const Center(child: CircularProgressIndicator());
    if (_allowed == false) {
      return ListView(padding: const EdgeInsets.all(20), children: [
        if (usernameTile != null) usernameTile,
        ..._onlineRows(cs, q),
        const SizedBox(height: 12),
        Icon(Icons.contacts_outlined, size: 64, color: cs.primary),
        const SizedBox(height: 12),
        const Text('Search friends by the names saved in your phone', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text('Allow contacts to see which of your contacts use 5 Sec Text. Your contact list stays on your phone.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
        const SizedBox(height: 16),
        FilledButton(onPressed: _ask, child: const Text('Allow contacts')),
        const SizedBox(height: 8),
        Text('You can always search by @username instead.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
      ]);
    }
    return ListView(children: [
      if (usernameTile != null) usernameTile,
      ..._onlineRows(cs, q),
      if (q.isEmpty) ...[
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: Row(children: [
            Expanded(child: Text(onApp.isEmpty ? 'Contacts on 5 Sec Text' : 'On 5 Sec Text (${onApp.length})', style: const TextStyle(fontWeight: FontWeight.w700))),
            TextButton.icon(
              onPressed: _scanning ? null : _scanAll,
              icon: _scanning ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.refresh, size: 18),
              label: Text(_scanning ? 'Checking $_scanned/${_contacts.length}' : 'Check all contacts'),
            ),
          ]),
        ),
        for (final c in onApp) _row(cs, c),
        if (onApp.isEmpty) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text('None found yet. Tap "Check all contacts", or invite friends below.', style: TextStyle(color: cs.onSurfaceVariant))),
        const Divider(height: 24),
        const Padding(padding: EdgeInsets.fromLTRB(16, 0, 16, 4), child: Text('All contacts', style: TextStyle(fontWeight: FontWeight.w700))),
      ],
      if (shown.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Text('No contact matches "$q".', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant))),
      for (final c in shown.take(300)) _row(cs, c),
      const SizedBox(height: 24),
    ]);
  }

  /// People on 5 Sec Text whose name or username matches what was typed.
  List<Widget> _onlineRows(ColorScheme cs, String q) {
    if (q.length < 2 || _online.isEmpty) return const [];
    return [
      const Padding(padding: EdgeInsets.fromLTRB(16, 10, 16, 2), child: Text('People on 5 Sec Text', style: TextStyle(fontWeight: FontWeight.w700))),
      for (final u in _online.take(8))
        ListTile(
          leading: CircleAvatar(backgroundColor: cs.primary, foregroundColor: cs.onPrimary, child: Text(u.name.isEmpty ? '?' : u.name[0].toUpperCase())),
          title: Text(u.name), subtitle: Text('@${u.username}'),
          trailing: FilledButton(onPressed: () => _chat(u), child: const Text('Chat')),
        ),
      const Divider(height: 16),
    ];
  }

  Widget _row(ColorScheme cs, _Contact c) {
    final u = _userFor(c);
    final linked = LocalLinks.userFor(c.id) != null;
    final done = _isChecked(c);
    return ListTile(
      onLongPress: linked ? () => _unlink(c) : () => _linkUsername(c),
      leading: CircleAvatar(
        backgroundColor: u != null ? cs.primary : cs.surfaceContainerHighest,
        foregroundColor: u != null ? cs.onPrimary : cs.onSurfaceVariant,
        child: Text(c.name[0].toUpperCase()),
      ),
      title: Text(c.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(u != null ? '@${u.username} · ${linked ? 'linked by you' : 'on 5 Sec Text'}' : c.numbers.first, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        if (u != null)
          FilledButton(onPressed: () => _chat(u), child: const Text('Chat'))
        else if (!done)
          const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
        PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'link') _linkUsername(c);
            if (v == 'unlink') _unlink(c);
            if (v == 'invite') _invite();
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: linked ? 'unlink' : 'link', child: Text(linked ? 'Remove username link' : 'Link a username')),
            if (u == null) const PopupMenuItem(value: 'invite', child: Text('Invite to 5 Sec Text')),
          ],
        ),
      ]),
    );
  }
}
