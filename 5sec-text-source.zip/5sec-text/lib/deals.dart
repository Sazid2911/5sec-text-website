// "Deals" tab - a public status board for discounts only.
// Anyone (suppliers, vendors, shops, users) can post a discount coupon / promo
// code or announce a sale. Every post must state the discount and an expiry
// date; posts vanish automatically when the offer ends (max 30 days).
// Other kinds of content are not allowed - users can report posts that aren't deals.
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

import 'audit.dart';
import 'compliance.dart';
import 'data.dart';
import 'nudity.dart';

const dealCategories = ['All', 'Food', 'Grocery', 'Fashion', 'Electronics', 'Mobile & Internet', 'Travel', 'Health & Beauty', 'Home', 'Services', 'Other'];
const maxActiveDeals = 10;

/// Sub-categories, so shoppers can jump straight to e.g. Fashion → Shoes.
const dealSubcategories = <String, List<String>>{
  'Food': ['Restaurants', 'Cafes', 'Delivery', 'Sweets & Bakery'],
  'Grocery': ['Supermarket', 'Fresh food', 'Household'],
  'Fashion': ['Shoes', 'Clothing', 'Bags', 'Watches & Jewellery', 'Kids'],
  'Electronics': ['Phones', 'Laptops', 'TV & Audio', 'Appliances', 'Gaming'],
  'Mobile & Internet': ['Recharge', 'Data plans', 'Accessories'],
  'Travel': ['Flights', 'Hotels', 'Car rental', 'Tours'],
  'Health & Beauty': ['Pharmacy', 'Cosmetics', 'Salon & Spa', 'Fitness'],
  'Home': ['Furniture', 'Decor', 'Kitchen', 'Garden'],
  'Services': ['Car service', 'Cleaning', 'Education', 'Repairs'],
};

/// Where the offer can be used.
const dealWhere = <String, String>{'online': 'Online', 'store': 'In store', 'both': 'Online & in store'};

/// Rough size of a discount, for "Biggest discount" sorting: 40% OFF → 40, Buy 1 Get 1 → 50.
int discountScore(String text) {
  final t = text.toLowerCase();
  final pct = RegExp(r'(\d{1,3})\s*%').allMatches(t).map((m) => int.parse(m.group(1)!)).where((v) => v <= 100);
  if (pct.isNotEmpty) return pct.reduce((a, b) => a > b ? a : b);
  if (RegExp(r'buy\s*1\s*get\s*1|bogo|1\s*\+\s*1').hasMatch(t)) return 50;
  if (RegExp(r'buy\s*2\s*get\s*1').hasMatch(t)) return 33;
  if (t.contains('free')) return 30;
  return 0;
}

class Deal {
  final String id, owner, ownerName, vendor, title, discount, code, link, category, details;
  final DateTime createdAt, expiresAt;
  final Uint8List? image; // optional picture (flyer / product photo). Videos are not allowed in Deals.
  final int flags; // number of people who reported it; hidden at 3+
  final String city, where, sub; // where: online | store | both
  final Set<String> up, down; // "code worked" / "didn't work" votes (user ids)
  bool affiliate = false; // posted from an affiliate network: we may earn a commission
  String address = ''; // shop address (in-store deals)
  double? lat, lng; // pinned shop location
  bool get pinned => lat != null && lng != null;
  /// Opens Google Maps with directions to the shop (pin first, else the written address).
  Uri? get mapsUri {
    if (pinned) return Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$lat,$lng');
    final q = [address, city].where((x) => x.trim().isNotEmpty).join(', ');
    return q.isEmpty ? null : Uri.parse('https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent('$vendor, $q')}');
  }
  String source = ''; // 'admin' = posted by the 5 Sec Deals team (bulk upload), 'vendor-web' = vendor portal
  bool get official => source == 'admin';
  Deal(this.id, this.owner, this.ownerName, this.vendor, this.title, this.discount, this.code, this.link, this.category, this.details, this.createdAt, this.expiresAt, this.image,
      [this.flags = 0, this.city = '', this.where = 'both', this.sub = '', this.up = const {}, this.down = const {}]);
  factory Deal.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    DateTime ts(Object? v) => v is Timestamp ? v.toDate() : DateTime.now();
    String s(String k) => (m[k] ?? '') as String;
    final img = m['image'];
    return Deal(d.id, s('owner'), s('ownerName'), s('vendor'), s('title'), s('discount'), s('code'), s('link'), s('category'), s('details'), ts(m['createdAt']), ts(m['expiresAt']),
        img is Blob ? img.bytes : null, (m['flags'] as List? ?? const []).length,
        s('city'), dealWhere.containsKey(m['where']) ? m['where'] as String : 'both', s('sub'),
        Set<String>.from(m['up'] as List? ?? const []), Set<String>.from(m['down'] as List? ?? const []))
      ..affiliate = m['affiliate'] == true
      ..source = s('source')
      ..address = s('address')
      ..lat = (m['lat'] as num?)?.toDouble()
      ..lng = (m['lng'] as num?)?.toDouble();
  }
  int get votes => up.length + down.length;
  /// Share of people who said the code worked (null until someone votes).
  int? get workedPct => votes == 0 ? null : (up.length * 100 / votes).round();
  int get score => discountScore(discount);
  bool get online => where == 'online' || where == 'both';
  bool get inStore => where == 'store' || where == 'both';
  bool get expired => DateTime.now().isAfter(expiresAt);
  String get endsIn {
    final h = expiresAt.difference(DateTime.now()).inHours;
    if (h <= 0) return 'Ended';
    if (h < 24) return 'Ends in ${h}h';
    final d = (h / 24).ceil();
    return 'Ends in $d ${d == 1 ? 'day' : 'days'}';
  }
}

class DealRepo {
  static final _deals = db.collection('deals');
  static Stream<List<Deal>> feed() => _deals.orderBy('createdAt', descending: true).limit(500).snapshots()
      .map((s) => s.docs.map(Deal.fromDoc).where((d) => !d.expired).toList());
  static Stream<List<Deal>> mine() => _deals.where('owner', isEqualTo: myUid).snapshots()
      .map((s) => s.docs.map(Deal.fromDoc).where((d) => !d.expired).toList());
  /// `confirmedAt` records (server time) that the vendor ticked
  /// "I confirm this offer is genuine and lawful"; it is also kept in the 1-year log.
  static Future<void> post(AppUser me, {required String vendor, required String title, required String discount, required String code,
      required String link, required String category, required String details, required DateTime expiresAt, Uint8List? image,
      String sub = '', String where = 'both', String city = '', String address = '', double? lat, double? lng}) async {
    final ref = await _deals.add({
      'owner': me.uid, 'ownerName': me.name, 'vendor': vendor.trim(), 'title': title.trim(), 'discount': discount.trim(),
      'code': code.trim(), 'link': link.trim(), 'category': category, 'details': details.trim(),
      'sub': sub, 'where': where, 'city': city.trim(),
      if (address.trim().isNotEmpty) 'address': address.trim(),
      if (lat != null && lng != null) 'lat': lat,
      if (lat != null && lng != null) 'lng': lng,
      if (image != null) 'image': Blob(image),
      'createdAt': FieldValue.serverTimestamp(), 'expiresAt': Timestamp.fromDate(expiresAt), 'confirmedAt': FieldValue.serverTimestamp(),
    });
    await Audit.log('deal_posted', ref: ref.id, info: '${vendor.trim()} · ${discount.trim()} · ${title.trim()} · vendor confirmed genuine & lawful');
  }
  /// Vendors manage their own deals: edit any detail, change the end date, swap or remove the picture.
  static Future<void> update(String id, {required String vendor, required String title, required String discount, required String code,
      required String link, required String category, required String details, required DateTime expiresAt, Uint8List? image, bool removeImage = false,
      String sub = '', String where = 'both', String city = '', String address = '', double? lat, double? lng}) async {
    await _deals.doc(id).update({
      'vendor': vendor.trim(), 'title': title.trim(), 'discount': discount.trim(), 'code': code.trim(), 'link': link.trim(),
      'sub': sub, 'where': where, 'city': city.trim(),
      'category': category, 'details': details.trim(), 'expiresAt': Timestamp.fromDate(expiresAt), 'updatedAt': FieldValue.serverTimestamp(),
      'address': address.trim(),
      'lat': (lat != null && lng != null) ? lat : FieldValue.delete(),
      'lng': (lat != null && lng != null) ? lng : FieldValue.delete(),
      'confirmedAt': FieldValue.serverTimestamp(),
      if (image != null) 'image': Blob(image),
      if (image == null && removeImage) 'image': FieldValue.delete(),
    });
    await Audit.log('deal_updated', ref: id, info: '${vendor.trim()} · ${discount.trim()} · ${title.trim()} · vendor confirmed genuine & lawful');
  }
  static Future<void> delete(String id) async {
    await _deals.doc(id).delete();
    await Audit.log('deal_ended', ref: id);
  }
  static Future<void> flag(String id) => _deals.doc(id).update({'flags': FieldValue.arrayUnion([myUid])});
  /// "Did the code work?" One vote per person; changing it moves the vote.
  static Future<void> vote(String id, bool worked) => _deals.doc(id).update({
        worked ? 'up' : 'down': FieldValue.arrayUnion([myUid]),
        worked ? 'down' : 'up': FieldValue.arrayRemove([myUid]),
      });
}

class DealsScreen extends StatefulWidget {
  final AppUser me;
  const DealsScreen({super.key, required this.me});
  @override
  State<DealsScreen> createState() => _DealsScreenState();
}

class _DealsScreenState extends State<DealsScreen> {
  String _cat = 'All';
  String _sub = 'All';
  String _q = '';
  String _sort = 'discount'; // discount | ending | new | trusted
  String _where = 'all'; // all | online | store
  String _city = 'All cities';
  bool _mineOnly = false;

  static const _sorts = {'discount': 'Biggest discount', 'near': 'Nearest shops', 'ending': 'Ending soon', 'new': 'Newest', 'trusted': 'Most trusted codes'};
  Position? _here;

  Future<void> _setSort(String v) async {
    if (v == 'near' && _here == null) {
      final p = await myPosition(context);
      if (p == null) return;
      _here = p;
    }
    setState(() => _sort = v);
  }

  double _km(Deal d) => !d.pinned || _here == null ? 1e9 : Geolocator.distanceBetween(_here!.latitude, _here!.longitude, d.lat!, d.lng!) / 1000;

  List<Deal> _sorted(List<Deal> list) {
    int trust(Deal d) => d.workedPct == null ? 50 : d.workedPct!;
    switch (_sort) {
      case 'discount':
        list.sort((a, b) { final c = b.score.compareTo(a.score); return c != 0 ? c : trust(b).compareTo(trust(a)); });
      case 'near':
        list.sort((a, b) => _km(a).compareTo(_km(b)));
      case 'ending':
        list.sort((a, b) => a.expiresAt.compareTo(b.expiresAt));
      case 'trusted':
        list.sort((a, b) { final c = trust(b).compareTo(trust(a)); return c != 0 ? c : b.votes.compareTo(a.votes); });
      default:
        list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    }
    return list;
  }

  Widget _drop<T>(T value, Map<T, String> items, ValueChanged<T> onChanged, IconData icon) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: InputChip(
          avatar: Icon(icon, size: 18),
          label: DropdownButtonHideUnderline(
            child: DropdownButton<T>(
              value: value,
              isDense: true,
              items: [for (final e in items.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
              onChanged: (v) { if (v != null) onChanged(v); },
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Deals & Coupons', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'My deals',
            icon: Icon(_mineOnly ? Icons.person : Icons.person_outline),
            onPressed: () => setState(() => _mineOnly = !_mineOnly),
          ),
        ],
      ),
      body: StreamBuilder<List<String>>(
        stream: Repo.myBlocked(),
        builder: (context, bl) {
          final blocked = (bl.data ?? const <String>[]).toSet();
          return StreamBuilder<List<Deal>>(
            stream: _mineOnly ? DealRepo.mine() : DealRepo.feed(),
            builder: (context, snap) {
              final q = _q.toLowerCase();
              final visible = (snap.data ?? const <Deal>[])
                  .where((d) => !blocked.contains(d.owner) && (d.flags < 3 || d.owner == widget.me.uid))
                  .toList();
              final cities = <String>{for (final d in visible) if (d.city.trim().isNotEmpty) d.city.trim()}.toList()..sort();
              if (_city != 'All cities' && !cities.contains(_city)) _city = 'All cities';
              final deals = _sorted(visible
                  .where((d) => _cat == 'All' || d.category == _cat)
                  .where((d) => _sub == 'All' || d.sub == _sub)
                  .where((d) => _where == 'all' || (_where == 'online' ? d.online : d.inStore))
                  // a city filter shows that city's shops plus online-only deals (usable anywhere)
                  .where((d) => _city == 'All cities' || d.city.toLowerCase() == _city.toLowerCase() || d.where == 'online')
                  .where((d) => q.isEmpty || '${d.vendor} ${d.title} ${d.details} ${d.category} ${d.sub} ${d.city}'.toLowerCase().contains(q))
                  .toList());
              final subs = dealSubcategories[_cat] ?? const <String>[];
              return Column(children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                  child: TextField(
                    onChanged: (v) => setState(() => _q = v),
                    decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Search shops, brands, products', filled: true,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
                  ),
                ),
                SizedBox(
                  height: 48,
                  child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                    for (final c in dealCategories)
                      Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(label: Text(c), selected: _cat == c, onSelected: (_) => setState(() { _cat = c; _sub = 'All'; }))),
                  ]),
                ),
                if (subs.isNotEmpty)
                  SizedBox(
                    height: 44,
                    child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                      for (final c in ['All', ...subs])
                        Padding(padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: FilterChip(label: Text(c == 'All' ? 'All $_cat' : c), selected: _sub == c, onSelected: (_) => setState(() => _sub = c))),
                    ]),
                  ),
                SizedBox(
                  height: 48,
                  child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                    _drop<String>(_sort, _sorts, _setSort, Icons.sort),
                    _drop<String>(_where, const {'all': 'Online & in store', 'online': 'Online only', 'store': 'In store'}, (v) => setState(() => _where = v), Icons.storefront_outlined),
                    _drop<String>(_city, {'All cities': 'All cities', for (final c in cities) c: c}, (v) => setState(() => _city = v), Icons.place_outlined),
                  ]),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 2),
                  child: Align(alignment: Alignment.centerLeft, child: Text('${deals.length} ${deals.length == 1 ? 'deal' : 'deals'}', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant))),
                ),
                Expanded(
                  child: deals.isEmpty
                      ? Center(child: Text(_mineOnly ? 'You have no active deals.' : 'No deals here yet.\nTap "Post a deal" to share a discount.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)))
                      : ListView.builder(
                          padding: const EdgeInsets.fromLTRB(12, 4, 12, 90),
                          itemCount: deals.length,
                          itemBuilder: (_, i) => DealCard(deal: deals[i], me: widget.me),
                        ),
                ),
              ]);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.local_offer_outlined),
        label: const Text('Post a deal'),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PostDealScreen(me: widget.me))),
      ),
    );
  }
}

class DealCard extends StatelessWidget {
  final Deal deal;
  final AppUser me;
  const DealCard({super.key, required this.deal, required this.me});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final d = deal;
    final mine = d.owner == me.uid;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
          color: cs.tertiaryContainer,
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d.discount, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: cs.onTertiaryContainer)),
              Row(children: [
                Flexible(child: Text(d.vendor, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, color: cs.onTertiaryContainer))),
                if (d.official) Padding(padding: const EdgeInsets.only(left: 4), child: Icon(Icons.verified, size: 16, color: cs.primary)),
              ]),
              if (d.affiliate)
                Text('Affiliate link · we may earn a commission', style: TextStyle(fontSize: 11, color: cs.onTertiaryContainer.withValues(alpha: .75))),
            ])),
            Chip(label: Text(d.category), visualDensity: VisualDensity.compact),
            PopupMenuButton<String>(
              onSelected: (v) async {
                if (v == 'edit' && context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => PostDealScreen(me: me, existing: d)));
                if (v == 'end') await DealRepo.delete(d.id);
                if (v == 'report') {
                  await DealRepo.flag(d.id).catchError((_) {});
                  await Repo.report(chatId: 'deal:${d.id}', userUid: d.owner, reason: 'deal report');
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reported. Thank you.')));
                }
                if (v == 'block') await Repo.block(d.owner);
                if (v == 'complain' && context.mounted) {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => ComplaintScreen(targetType: 'deal', targetId: d.id, targetOwner: d.owner, targetLabel: '${d.vendor} · ${d.discount} · ${d.title}')));
                }
              },
              itemBuilder: (_) => [
                if (mine) const PopupMenuItem(value: 'edit', child: Text('Edit / update deal')),
                if (mine) const PopupMenuItem(value: 'end', child: Text('End deal now')),
                if (!mine) const PopupMenuItem(value: 'report', child: Text('Report (nudity, spam or not a real deal)')),
                if (!mine) const PopupMenuItem(value: 'block', child: Text('Hide this poster')),
                if (!mine) const PopupMenuItem(value: 'complain', child: Text('Complain to Grievance Officer')),
              ],
            ),
          ]),
        ),
        if (d.image != null)
          FutureBuilder<bool>(
            future: NudityCheck.isUnsafe(d.image!),
            builder: (_, chk) {
              if (!chk.hasData) return Container(height: 220, color: cs.surfaceContainerHighest);
              if (chk.data!) {
                return Container(height: 80, color: cs.surfaceContainerHighest, alignment: Alignment.center,
                    child: const Text('Picture hidden: not allowed in Deals'));
              }
              return Image.memory(d.image!, height: 220, fit: BoxFit.cover, gaplessPlayback: true);
            },
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(d.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Wrap(spacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
                if (d.sub.isNotEmpty) Text('${d.category} › ${d.sub}', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                if (d.online) Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.language, size: 14, color: cs.primary), Text(' Online', style: TextStyle(fontSize: 12, color: cs.primary))]),
                if (d.inStore) Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.place_outlined, size: 14, color: cs.primary),
                    Text(' ${d.city.isEmpty ? 'In store' : 'In store · ${d.city}'}', style: TextStyle(fontSize: 12, color: cs.primary))]),
              ]),
            ),
            if (d.details.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(d.details)),
            if (d.inStore && (d.address.isNotEmpty || d.pinned))
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Row(children: [
                  Icon(d.pinned ? Icons.location_on : Icons.place_outlined, size: 18, color: cs.primary),
                  const SizedBox(width: 4),
                  Expanded(child: Text(d.address.isNotEmpty ? d.address : 'Shop location pinned', style: const TextStyle(fontSize: 13))),
                  TextButton.icon(
                    icon: const Icon(Icons.directions, size: 18),
                    label: const Text('Directions'),
                    onPressed: () { final u = d.mapsUri; if (u != null) launchUrl(u, mode: LaunchMode.externalApplication); },
                  ),
                ]),
              ),
            const SizedBox(height: 10),
            if (d.code.isNotEmpty)
              Row(children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(border: Border.all(color: cs.primary, width: 2), borderRadius: BorderRadius.circular(10)),
                    child: Text(d.code, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 2)),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton.icon(
                  icon: const Icon(Icons.copy, size: 18),
                  label: const Text('Copy code'),
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: d.code));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Code copied')));
                  },
                ),
              ])
            else
              Text('No code needed', style: TextStyle(color: cs.primary, fontWeight: FontWeight.w700)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 4, 14, 0),
          child: Row(children: [
            TextButton.icon(
              onPressed: mine ? null : () => DealRepo.vote(d.id, true).catchError((_) {}),
              icon: Icon(d.up.contains(me.uid) ? Icons.thumb_up : Icons.thumb_up_outlined, size: 18),
              label: Text('Worked ${d.up.length}'),
            ),
            TextButton.icon(
              onPressed: mine ? null : () => DealRepo.vote(d.id, false).catchError((_) {}),
              icon: Icon(d.down.contains(me.uid) ? Icons.thumb_down : Icons.thumb_down_outlined, size: 18),
              label: Text('Didn\'t ${d.down.length}'),
              style: TextButton.styleFrom(foregroundColor: cs.error),
            ),
            const Spacer(),
            if (d.workedPct != null)
              Text('${d.workedPct}% say it worked', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
                  color: d.workedPct! >= 60 ? cs.primary : cs.error)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 0),
          child: Text('Offer provided by ${d.vendor}, who is responsible for it. Terms set by the vendor.',
              style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 6, 6, 8),
          child: Row(children: [
            Icon(Icons.timer_outlined, size: 16, color: cs.error),
            Text(' ${d.endsIn}', style: TextStyle(color: cs.error, fontWeight: FontWeight.w600)),
            Text('  ·  by ${d.ownerName}', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
            const Spacer(),
            if (d.link.isNotEmpty)
              TextButton.icon(
                icon: const Icon(Icons.open_in_new, size: 18),
                label: Text(Uri.tryParse(d.link)?.host ?? 'Open'),
                onPressed: () => launchUrl(Uri.parse(d.link), mode: LaunchMode.externalApplication),
              ),
          ]),
        ),
      ]),
    );
  }
}

class PostDealScreen extends StatefulWidget {
  final AppUser me;
  final Deal? existing; // set when a vendor edits one of their own deals
  const PostDealScreen({super.key, required this.me, this.existing});
  @override
  State<PostDealScreen> createState() => _PostDealScreenState();
}

class _PostDealScreenState extends State<PostDealScreen> {
  final _vendor = TextEditingController(), _title = TextEditingController(), _discount = TextEditingController();
  final _code = TextEditingController(), _link = TextEditingController(), _details = TextEditingController();
  String _category = 'Other';
  String _subcat = '';
  String _whereSel = 'both';
  final _city = TextEditingController();
  final _address = TextEditingController();
  double? _lat, _lng;
  bool _locating = false;
  DateTime _expires = DateTime.now().add(const Duration(days: 7));
  bool _agree = false, _busy = false;
  Uint8List? _image;
  bool _removedImage = false;
  String? _err;

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final d = widget.existing;
    if (d != null) {
      _vendor.text = d.vendor; _title.text = d.title; _discount.text = d.discount; _code.text = d.code;
      _link.text = d.link; _details.text = d.details; _category = dealCategories.contains(d.category) && d.category != 'All' ? d.category : 'Other';
      _subcat = (dealSubcategories[_category] ?? const []).contains(d.sub) ? d.sub : '';
      _whereSel = d.where; _city.text = d.city;
      _address.text = d.address; _lat = d.lat; _lng = d.lng;
      _expires = d.expiresAt; _image = d.image; _agree = false; // vendor must re-confirm on every update
    }
  }

  /// Pin the shop at the phone's current location (stand inside the shop and tap).
  Future<void> _pinHere() async {
    setState(() { _locating = true; _err = null; });
    final p = await myPosition(context);
    if (!mounted) return;
    setState(() { _locating = false; if (p != null) { _lat = p.latitude; _lng = p.longitude; } });
  }

  /// Pin from a Google Maps link / "lat, lng" text the vendor pastes.
  Future<void> _pinFromLink() async {
    final ctl = TextEditingController(text: (await Clipboard.getData('text/plain'))?.text ?? '');
    if (!mounted) return;
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Paste a map location'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('In Google Maps, long-press your shop → copy the coordinates (e.g. 26.4207, 50.0888), or Share → Copy link, then paste here.'),
        const SizedBox(height: 10),
        TextField(controller: ctl, maxLines: 3, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: '26.4207, 50.0888  or  https://maps…')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Use'))],
    ));
    if (ok != true) return;
    final ll = parseLatLng(ctl.text);
    setState(() {
      if (ll != null) { _lat = ll.$1; _lng = ll.$2; _err = null; }
      else { _err = 'Could not find a location in that text. Short links (maps.app.goo.gl) don\'t include it — copy the coordinates instead.'; }
    });
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(context: context, firstDate: now, lastDate: now.add(const Duration(days: 30)), initialDate: _expires);
    if (d != null) setState(() => _expires = DateTime(d.year, d.month, d.day, 23, 59));
  }

  Future<void> _pickImage(ImageSource src) async {
    final x = await ImagePicker().pickImage(source: src, maxWidth: 1080, maxHeight: 1080, imageQuality: 65);
    if (x == null) return;
    var bytes = await x.readAsBytes();
    if (bytes.length > 700 * 1024) {
      final y = await ImagePicker().pickImage(source: src, maxWidth: 720, maxHeight: 720, imageQuality: 50);
      if (y == null) return;
      bytes = await y.readAsBytes();
    }
    if (bytes.length > 700 * 1024) { setState(() => _err = 'Picture is too large'); return; }
    setState(() => _err = 'Checking picture…');
    if (await NudityCheck.isUnsafe(bytes)) {
      setState(() { _image = null; _err = 'This picture is not allowed. Nudity or sexual content can\'t be posted in Deals.'; });
      return;
    }
    setState(() { _image = bytes; _err = null; });
  }

  Future<void> _post() async {
    String? err;
    final link = _link.text.trim();
    if (_vendor.text.trim().isEmpty) err = 'Enter the shop / brand name';
    else if (_discount.text.trim().isEmpty) err = 'Enter the discount (e.g. 20% OFF, SAR 50 off, Buy 1 Get 1)';
    else if (_title.text.trim().isEmpty) err = 'Enter what the deal is on';
    else if (link.isNotEmpty && !(link.startsWith('https://'))) err = 'Links must start with https://';
    else if (hasBlockedWords('${_vendor.text} ${_title.text} ${_discount.text} ${_details.text} ${_code.text}')) err = 'Adult or sexual content is not allowed in Deals.';
    else if (_image != null && await NudityCheck.isUnsafe(_image!)) err = 'This picture is not allowed in Deals.';
    else if (_whereSel != 'online' && _city.text.trim().isEmpty) err = 'Enter the city where the shop is (or choose Online)';
    else if (hasBlockedWords(_address.text)) err = 'Adult or sexual content is not allowed in Deals.';
    else if (!_agree) err = 'Please confirm this offer is genuine and lawful';
    if (err != null) { setState(() => _err = err); return; }
    setState(() { _busy = true; _err = null; });
    try {
      if (_editing) {
        final changedImage = _image != null && !identical(_image, widget.existing!.image);
        await DealRepo.update(widget.existing!.id, vendor: _vendor.text, title: _title.text, discount: _discount.text, code: _code.text,
            link: link, category: _category, details: _details.text, expiresAt: _expires,
            image: changedImage ? _image : null, removeImage: _removedImage && _image == null,
            sub: _subcat, where: _whereSel, city: _whereSel == 'online' ? '' : _city.text,
            address: _whereSel == 'online' ? '' : _address.text, lat: _whereSel == 'online' ? null : _lat, lng: _whereSel == 'online' ? null : _lng);
      } else {
        final mine = await DealRepo.mine().first;
        if (mine.length >= maxActiveDeals) throw 'You can have up to $maxActiveDeals active deals. End one first.';
        await DealRepo.post(widget.me, vendor: _vendor.text, title: _title.text, discount: _discount.text, code: _code.text,
            link: link, category: _category, details: _details.text, expiresAt: _expires, image: _image,
            sub: _subcat, where: _whereSel, city: _whereSel == 'online' ? '' : _city.text,
            address: _whereSel == 'online' ? '' : _address.text, lat: _whereSel == 'online' ? null : _lat, lng: _whereSel == 'online' ? null : _lng);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() { _busy = false; _err = '$e'; });
    }
  }

  InputDecoration _dec(String label, [String? hint]) => InputDecoration(labelText: label, hintText: hint, border: const OutlineInputBorder());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Update deal' : 'Post a deal')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Only discount coupons, promo codes and sale offers can be posted here. You can add one picture; videos, nudity and sexual content are not allowed - pictures are checked automatically.'),
        const SizedBox(height: 14),
        if (_image != null)
          Stack(alignment: Alignment.topRight, children: [
            ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(_image!, height: 200, width: double.infinity, fit: BoxFit.cover)),
            IconButton.filledTonal(icon: const Icon(Icons.close), onPressed: () => setState(() { _image = null; _removedImage = true; })),
          ]),
        Row(children: [
          Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.photo_camera_outlined), label: const Text('Take picture'), onPressed: () => _pickImage(ImageSource.camera))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.image_outlined), label: const Text('From phone'), onPressed: () => _pickImage(ImageSource.gallery))),
        ]),
        const SizedBox(height: 14),
        TextField(controller: _vendor, maxLength: 40, decoration: _dec('Shop / brand / supplier name')),
        TextField(controller: _discount, maxLength: 24, decoration: _dec('Discount', 'e.g. 20% OFF, SAR 50 off, Buy 1 Get 1')),
        TextField(controller: _title, maxLength: 80, decoration: _dec('Deal on', 'e.g. All pizzas, Winter jackets, Mobile data packs')),
        TextField(controller: _code, maxLength: 30, textCapitalization: TextCapitalization.characters, decoration: _dec('Coupon code (leave empty if none needed)')),
        TextField(controller: _link, maxLength: 200, keyboardType: TextInputType.url, decoration: _dec('Website / app link (optional)', 'https://…')),
        TextField(controller: _details, maxLength: 300, maxLines: 3, decoration: _dec('Details / conditions (optional)', 'Minimum order, branches, online only…')),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _category,
          decoration: _dec('Category'),
          items: [for (final c in dealCategories.skip(1)) DropdownMenuItem(value: c, child: Text(c))],
          onChanged: (v) => setState(() { _category = v ?? 'Other'; _subcat = ''; }),
        ),
        if ((dealSubcategories[_category] ?? const []).isNotEmpty) ...[
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _subcat,
            decoration: _dec('Type (helps shoppers find it)'),
            items: [
              const DropdownMenuItem(value: '', child: Text('Choose…')),
              for (final c in dealSubcategories[_category]!) DropdownMenuItem(value: c, child: Text(c)),
            ],
            onChanged: (v) => setState(() => _subcat = v ?? ''),
          ),
        ],
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _whereSel,
          decoration: _dec('Where can it be used?'),
          items: [for (final e in dealWhere.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
          onChanged: (v) => setState(() => _whereSel = v ?? 'both'),
        ),
        if (_whereSel != 'online') ...[
          const SizedBox(height: 12),
          TextField(controller: _city, maxLength: 40, textCapitalization: TextCapitalization.words, decoration: _dec('City', 'e.g. Dammam, Mumbai, Karachi')),
          TextField(controller: _address, maxLength: 150, maxLines: 2, minLines: 1, textCapitalization: TextCapitalization.sentences,
              decoration: _dec('Shop address (optional)', 'Building, street, area, landmark — e.g. Shop 12, Al Rashid Mall, Khobar')),
          Card(
            margin: EdgeInsets.zero,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(_lat != null ? Icons.location_on : Icons.add_location_alt_outlined, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_lat != null ? 'Shop location pinned (${_lat!.toStringAsFixed(5)}, ${_lng!.toStringAsFixed(5)})' : 'Pin the shop on the map (optional)',
                      style: const TextStyle(fontWeight: FontWeight.w700))),
                ]),
                const SizedBox(height: 4),
                Text('Shoppers get a Directions button and can sort deals by "Nearest shops".', style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                const SizedBox(height: 8),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  OutlinedButton.icon(
                    icon: _locating ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.my_location),
                    label: const Text('I\'m at the shop — use my location'),
                    onPressed: _locating ? null : _pinHere,
                  ),
                  OutlinedButton.icon(icon: const Icon(Icons.content_paste), label: const Text('Paste from Google Maps'), onPressed: _pinFromLink),
                  if (_lat != null) ...[
                    TextButton.icon(icon: const Icon(Icons.map_outlined), label: const Text('Check on map'),
                        onPressed: () => launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=$_lat,$_lng'), mode: LaunchMode.externalApplication)),
                    TextButton.icon(icon: const Icon(Icons.close), label: const Text('Remove pin'), onPressed: () => setState(() { _lat = null; _lng = null; })),
                  ],
                ]),
              ]),
            ),
          ),
        ],
        const SizedBox(height: 12),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.event),
          title: const Text('Offer ends'),
          subtitle: Text('${_expires.day}/${_expires.month}/${_expires.year} - the post disappears automatically then'),
          trailing: TextButton(onPressed: _pickDate, child: const Text('Change')),
        ),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          value: _agree,
          onChanged: (v) => setState(() => _agree = v ?? false),
          title: const Text('I confirm this offer is genuine and lawful', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: const Text('I am responsible for this offer and will honour it, I hold any permit the law requires for it, '
              'and it contains no nudity, adult or misleading content.'),
          controlAffinity: ListTileControlAffinity.leading,
        ),
        if (_err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_err!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        const SizedBox(height: 12),
        FilledButton(onPressed: _busy ? null : _post, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)), child: _busy ? const CircularProgressIndicator() : Text(_editing ? 'Save changes' : 'Post deal')),
      ]),
    );
  }
}


/// Current phone location (asks for permission once). Null if refused or location is off.
Future<Position?> myPosition(BuildContext context) async {
  void say(String t) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t))); }
  try {
    if (!await Geolocator.isLocationServiceEnabled()) { say('Turn on Location (GPS) first.'); await Geolocator.openLocationSettings(); return null; }
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.deniedForever) { say('Location is blocked for 5 Sec Text. Allow it in phone settings.'); await Geolocator.openAppSettings(); return null; }
    if (p == LocationPermission.denied) { say('Location permission is needed for this.'); return null; }
    return await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 20)));
  } catch (_) {
    say('Could not get your location. Try again near a window or outdoors.');
    return null;
  }
}

/// Reads "lat, lng" from text or a Google Maps link (@lat,lng · q=lat,lng · ll=lat,lng · !3dlat!4dlng).
(double, double)? parseLatLng(String text) {
  final t = Uri.decodeFull(text);
  final pats = [
    RegExp(r'!3d(-?\d{1,2}\.\d+)!4d(-?\d{1,3}\.\d+)'),
    RegExp(r'@(-?\d{1,2}\.\d+),(-?\d{1,3}\.\d+)'),
    RegExp(r'[?&](?:q|ll|query|destination|daddr)=(-?\d{1,2}\.\d+),\s*(-?\d{1,3}\.\d+)'),
    RegExp(r'(-?\d{1,2}\.\d{3,})\s*,\s*(-?\d{1,3}\.\d{3,})'),
  ];
  for (final re in pats) {
    final m = re.firstMatch(t);
    if (m != null) {
      final a = double.parse(m.group(1)!), b = double.parse(m.group(2)!);
      if (a.abs() <= 90 && b.abs() <= 180) return (a, b);
    }
  }
  return null;
}
