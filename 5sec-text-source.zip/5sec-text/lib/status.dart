// Status (WhatsApp-style): share photos and videos with your contacts for 24 hours.
//
// * Up to 10 updates at a time, each disappears after 24 h.
// * Camera or gallery.
// * Who can see: your contacts = people you chat with, phone contacts who are on the app,
//   and anyone you add in "Who can see my status". You can remove anyone.
// * The photo/video file is stored ONLY on your phone. Contacts receive it directly from
//   your phone over an encrypted peer-to-peer connection, so they can view it while your
//   phone is online with the app open. The server only keeps a small card (owner, caption,
//   expiry) for 24 h.
// * Every photo and video is checked on the phone for nudity before it can be posted.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

import 'app_theme.dart';
import 'audit.dart';
import 'data.dart';
import 'nudity.dart';
import 'reactions.dart';
import 'videos.dart';

const _maxStatusVideo = Duration(seconds: 60);
const _maxStatusBytes = 60 * 1024 * 1024;
const _photoShow = Duration(seconds: 6);

LinearGradient get statusGradient => AppTheme.statusGradient();

/// Which status items I have already viewed (kept on this phone only).
class _Seen {
  static Set<String>? _ids;
  static Future<File> _f() async => File('${(await getApplicationDocumentsDirectory()).path}/status_seen_$myUid.json');
  static Future<Set<String>> load() async {
    if (_ids != null) return _ids!;
    try { final f = await _f(); _ids = f.existsSync() ? Set<String>.from(jsonDecode(await f.readAsString()) as List) : <String>{}; } catch (_) { _ids = <String>{}; }
    return _ids!;
  }
  static Future<void> add(String id) async {
    final s = await load();
    if (!s.add(id)) return;
    if (s.length > 500) s.remove(s.first);
    try { await (await _f()).writeAsString(jsonEncode(s.toList())); } catch (_) {}
  }
}

/// Adds the people I chat with (1-to-1) as status viewers, like WhatsApp contacts.
Future<void> syncChatContactsAsViewers() async {
  try {
    final chats = await Repo.myChats().first;
    final blocked = (await Repo.myBlocked().first).toSet();
    for (final c in chats) {
      final other = c.otherUid(myUid);
      if (other == null || other == myUid || blocked.contains(other)) continue;
      await VideoRepo.addViewerIfNew(other, c.names[other] ?? '', '');
    }
  } catch (_) {}
}

/// Ring around an avatar: colourful = new updates, grey = all seen.
class StatusRing extends StatelessWidget {
  final bool unseen;
  final Widget child;
  final double size;
  const StatusRing({super.key, required this.unseen, required this.child, this.size = 52});
  @override
  Widget build(BuildContext context) => Container(
        width: size + 6, height: size + 6,
        padding: const EdgeInsets.all(2.5),
        decoration: BoxDecoration(shape: BoxShape.circle, gradient: unseen ? statusGradient : null, color: unseen ? null : Colors.grey.shade400),
        child: Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(shape: BoxShape.circle, color: Theme.of(context).colorScheme.surface),
          child: ClipOval(child: SizedBox(width: size, height: size, child: child)),
        ),
      );
}

Widget initialAvatar(BuildContext context, String name, {double size = 52}) {
  final cs = Theme.of(context).colorScheme;
  final t = name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase();
  return Container(
    width: size, height: size, alignment: Alignment.center,
    decoration: BoxDecoration(gradient: LinearGradient(colors: [cs.primary, cs.tertiary])),
    child: Text(t, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: size * 0.42)),
  );
}

String agoText(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 1) return 'Just now';
  if (d.inMinutes < 60) return '${d.inMinutes} min ago';
  return '${d.inHours} h ago';
}

/// The Status tab body (used inside the home screen).
class StatusTab extends StatefulWidget {
  final AppUser me;
  const StatusTab({super.key, required this.me});
  @override
  State<StatusTab> createState() => _StatusTabState();
}

class _StatusTabState extends State<StatusTab> {
  int _refresh = 0;
  Set<String> _seen = {};

  @override
  void initState() {
    super.initState();
    syncChatContactsAsViewers();
    _Seen.load().then((s) { if (mounted) setState(() => _seen = s); });
  }

  Future<void> _reload() async {
    final s = await _Seen.load();
    if (mounted) setState(() { _seen = Set.of(s); _refresh++; });
  }

  Future<void> _open(List<VideoPost> items) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => StatusViewer(me: widget.me, items: items)));
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final me = widget.me;
    return StreamBuilder<List<String>>(
      stream: Repo.myBlocked(),
      builder: (context, bl) {
        final blocked = (bl.data ?? const <String>[]).toSet();
        return StreamBuilder<List<VideoPost>>(
          stream: VideoRepo.mine(),
          builder: (context, ms) => StreamBuilder<List<VideoPost>>(
            key: ValueKey(_refresh),
            stream: VideoRepo.friendsFeed(),
            builder: (context, fs) {
              final mine = [...(ms.data ?? const <VideoPost>[])]..sort((a, b) => a.createdAt.compareTo(b.createdAt));
              final byOwner = <String, List<VideoPost>>{};
              for (final v in fs.data ?? const <VideoPost>[]) {
                if (v.owner == me.uid || blocked.contains(v.owner) || v.flags >= 3) continue;
                (byOwner[v.owner] ??= []).add(v);
              }
              for (final l in byOwner.values) { l.sort((a, b) => a.createdAt.compareTo(b.createdAt)); }
              final groups = byOwner.values.toList()..sort((a, b) => b.last.createdAt.compareTo(a.last.createdAt));
              final recent = groups.where((g) => g.any((v) => !_seen.contains(v.id))).toList();
              final viewed = groups.where((g) => g.every((v) => _seen.contains(v.id))).toList();
              return RefreshIndicator(
                onRefresh: _reload,
                child: ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 96), children: [
                  _card(cs, Column(children: [
                    ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 6),
                      leading: Stack(clipBehavior: Clip.none, children: [
                        StatusRing(unseen: mine.isNotEmpty, child: initialAvatar(context, me.name)),
                        Positioned(right: -2, bottom: -2, child: CircleAvatar(radius: 11, backgroundColor: cs.primary, child: const Icon(Icons.add, size: 16, color: Colors.white))),
                      ]),
                      title: const Text('My status', style: TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text(mine.isEmpty ? 'Tap to add a photo or video' : '${mine.length} update${mine.length == 1 ? '' : 's'} · ${agoText(mine.last.createdAt)}'),
                      trailing: IconButton.filledTonal(icon: const Icon(Icons.photo_camera_outlined), onPressed: () => postStatus(context, me)),
                      onTap: () => mine.isEmpty ? postStatus(context, me) : _open(mine),
                    ),
                    if (mine.isNotEmpty) Padding(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                      child: Text('Saved only on this phone · contacts can view while your phone is online', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                    ),
                  ])),
                  if (recent.isNotEmpty) _header('Recent updates'),
                  for (final g in recent) _ownerRow(cs, g, true),
                  if (viewed.isNotEmpty) _header('Viewed updates'),
                  for (final g in viewed) _ownerRow(cs, g, false),
                  if (groups.isEmpty) Padding(
                    padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 12),
                    child: Column(children: [
                      ShaderMask(shaderCallback: (r) => statusGradient.createShader(r), child: const Icon(Icons.donut_large, size: 72, color: Colors.white)),
                      const SizedBox(height: 12),
                      const Text('No status updates yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      Text('When your contacts share a photo or video, it shows here for 24 hours.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
                    ]),
                  ),
                  const SizedBox(height: 8),
                  _card(cs, ListTile(
                    leading: const Icon(Icons.lock_outline),
                    title: const Text('Who can see my status'),
                    subtitle: const Text('Your chats and phone contacts on the app. Remove anyone here.'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FriendsScreen(me: me))),
                  )),
                ]),
              );
            },
          ),
        );
      },
    );
  }

  Widget _header(String t) => Padding(padding: const EdgeInsets.fromLTRB(8, 18, 8, 6), child: Text(t, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: .5)));

  Widget _card(ColorScheme cs, Widget child) => Card(elevation: 0, color: cs.surfaceContainerLow, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), child: child);

  Widget _ownerRow(ColorScheme cs, List<VideoPost> g, bool unseen) {
    final last = g.last;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      leading: StreamBuilder<bool>(
        stream: VideoRepo.online(last.owner),
        builder: (_, on) => Stack(clipBehavior: Clip.none, children: [
          StatusRing(unseen: unseen, child: initialAvatar(context, last.ownerName)),
          Positioned(right: 0, bottom: 0, child: CircleAvatar(radius: 7, backgroundColor: cs.surface, child: CircleAvatar(radius: 5, backgroundColor: on.data == true ? Colors.green : Colors.grey))),
        ]),
      ),
      title: Text(last.ownerName.isEmpty ? 'Contact' : last.ownerName, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text('${agoText(last.createdAt)} · ${g.length} update${g.length == 1 ? '' : 's'}'),
      onTap: () => _open(g),
    );
  }
}

/// Pick camera / gallery, photo / video, then post.
Future<void> postStatus(BuildContext context, AppUser me) async {
  final slot = await VideoRepo.freeSlot();
  if (!context.mounted) return;
  if (slot == null) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('You already have 10 status updates. Delete one or wait until one ends.')));
    return;
  }
  final choice = await showModalBottomSheet<String>(
    context: context,
    showDragHandle: true,
    builder: (c) => SafeArea(child: Wrap(children: [
      const ListTile(title: Text('Add to my status', style: TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('Visible to your contacts for 24 hours')),
      ListTile(leading: const Icon(Icons.photo_camera), title: const Text('Take photo'), onTap: () => Navigator.pop(c, 'cp')),
      ListTile(leading: const Icon(Icons.videocam), title: const Text('Record video (up to 60 s)'), onTap: () => Navigator.pop(c, 'cv')),
      ListTile(leading: const Icon(Icons.photo_library), title: const Text('Photo from gallery'), onTap: () => Navigator.pop(c, 'gp')),
      ListTile(leading: const Icon(Icons.video_library), title: const Text('Video from gallery'), onTap: () => Navigator.pop(c, 'gv')),
    ])),
  );
  if (choice == null) return;
  final src = choice.startsWith('c') ? ImageSource.camera : ImageSource.gallery;
  final photo = choice.endsWith('p');
  final x = photo
      ? await ImagePicker().pickImage(source: src, imageQuality: 82, maxWidth: 1600, maxHeight: 1600)
      : await ImagePicker().pickVideo(source: src, maxDuration: _maxStatusVideo);
  if (x == null || !context.mounted) return;
  await Navigator.push(context, MaterialPageRoute(builder: (_) => PostStatusScreen(me: me, slot: slot, file: File(x.path), photo: photo)));
}

class PostStatusScreen extends StatefulWidget {
  final AppUser me;
  final int slot;
  final File file;
  final bool photo;
  const PostStatusScreen({super.key, required this.me, required this.slot, required this.file, required this.photo});
  @override
  State<PostStatusScreen> createState() => _PostStatusScreenState();
}

class _PostStatusScreenState extends State<PostStatusScreen> {
  final _caption = TextEditingController();
  VideoPlayerController? _vc;
  String? _err;
  bool _checking = true, _busy = false, _ok = false;
  int _ms = 0;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final f = widget.file;
    try {
      if (await f.length() > _maxStatusBytes) { setState(() { _checking = false; _err = 'File is too large (max 60 MB).'; }); return; }
      if (widget.photo) {
        if (await NudityCheck.isUnsafe(await f.readAsBytes())) { setState(() { _checking = false; _err = 'This photo is not allowed. Nudity or sexual content can\'t be posted.'; }); return; }
      } else {
        final vc = VideoPlayerController.file(f);
        await vc.initialize();
        _ms = vc.value.duration.inMilliseconds;
        if (_ms > _maxStatusVideo.inMilliseconds + 1500) { await vc.dispose(); setState(() { _checking = false; _err = 'Video is too long (max 60 seconds).'; }); return; }
        if (await videoLooksUnsafe(f.path, _ms)) { await vc.dispose(); setState(() { _checking = false; _err = 'This video is not allowed. Nudity or sexual content can\'t be posted.'; }); return; }
        _vc = vc..setLooping(true)..play();
      }
      setState(() { _checking = false; _ok = true; });
    } catch (e) {
      setState(() { _checking = false; _err = 'Could not open this file.'; });
    }
  }

  @override
  void dispose() {
    _vc?.dispose();
    _caption.dispose();
    super.dispose();
  }

  Future<void> _post() async {
    if (hasBlockedWords(_caption.text)) { setState(() => _err = 'Caption has words that are not allowed.'); return; }
    setState(() => _busy = true);
    try {
      await VideoRepo.post(slot: widget.slot, source: widget.file, title: _caption.text, days: 1, hours: statusHours,
          durationMs: widget.photo ? 0 : _ms, me: widget.me, audience: 'friends', kind: widget.photo ? 'photo' : 'video');
      await syncChatContactsAsViewers();
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() { _busy = false; _err = 'Could not post: $e'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white, title: const Text('New status')),
      body: Column(children: [
        Expanded(child: Center(
          child: widget.photo
              ? Image.file(widget.file, fit: BoxFit.contain)
              : (_vc != null && _vc!.value.isInitialized ? AspectRatio(aspectRatio: _vc!.value.aspectRatio, child: VideoPlayer(_vc!)) : const CircularProgressIndicator(color: Colors.white)),
        )),
        if (_checking) const Padding(padding: EdgeInsets.all(12), child: Text('Checking content on your phone…', style: TextStyle(color: Colors.white70))),
        if (_err != null) Padding(padding: const EdgeInsets.all(12), child: Text(_err!, style: const TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.w700))),
        SafeArea(child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
          child: Row(children: [
            Expanded(child: TextField(
              controller: _caption, maxLength: 120, style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(hintText: 'Add a caption…', hintStyle: const TextStyle(color: Colors.white54), counterText: '', filled: true, fillColor: Colors.white12,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
            )),
            const SizedBox(width: 8),
            FloatingActionButton(
              onPressed: _ok && !_busy ? _post : null,
              backgroundColor: _ok ? AppTheme.color.value : Colors.grey,
              child: _busy ? const CircularProgressIndicator(color: Colors.white) : const Icon(Icons.send, color: Colors.white),
            ),
          ]),
        )),
      ]),
    );
  }
}

/// Full-screen viewer with progress bars (tap right = next, left = back, hold = pause).
class StatusViewer extends StatefulWidget {
  final AppUser me;
  final List<VideoPost> items;
  const StatusViewer({super.key, required this.me, required this.items});
  @override
  State<StatusViewer> createState() => _StatusViewerState();
}

class _StatusViewerState extends State<StatusViewer> with SingleTickerProviderStateMixin {
  late final AnimationController _prog = AnimationController(vsync: this)..addStatusListener((s) { if (s == AnimationStatus.completed) _next(); });
  int _i = 0;
  File? _file;
  VideoPlayerController? _vc;
  String? _status;
  double _p = 0;
  final _temp = <File>[];
  final _reply = TextEditingController();
  int _load = 0;

  VideoPost get _v => widget.items[_i];
  bool get _mine => _v.owner == widget.me.uid;

  @override
  void initState() {
    super.initState();
    _show();
  }

  @override
  void dispose() {
    _prog.dispose();
    _vc?.dispose();
    _reply.dispose();
    for (final f in _temp) { try { if (f.existsSync()) f.deleteSync(); } catch (_) {} }
    super.dispose();
  }

  Future<void> _show() async {
    final my = ++_load;
    _prog.stop();
    _prog.value = 0;
    await _vc?.dispose();
    _vc = null;
    setState(() { _file = null; _status = 'Loading…'; _p = 0; });
    final v = _v;
    File? f;
    if (_mine) {
      f = await VideoRepo.localFile(v.id);
      if (!f.existsSync()) f = null;
    } else {
      f = await fetchVideo(v, (p, s) { if (mounted && my == _load) setState(() { _p = p; _status = s; }); });
      if (f != null) _temp.add(f);
    }
    if (!mounted || my != _load) return;
    if (f == null) {
      setState(() => _status = _mine ? 'This file is no longer on your phone.' : '${v.ownerName} is offline right now. Status can be viewed while their phone is online with the app open.');
      _prog.duration = const Duration(seconds: 4);
      _prog.forward(from: 0);
      return;
    }
    if (!_mine) {
      _Seen.add(v.id);
      Reactions.sendView(videoId: v.id, owner: v.owner, expiresAt: v.expiresAt, me: widget.me).catchError((_) {});
    }
    if (v.isPhoto) {
      setState(() { _file = f; _status = null; });
      _prog.duration = _photoShow;
      _prog.forward(from: 0);
    } else {
      final vc = VideoPlayerController.file(f);
      try { await vc.initialize(); } catch (_) {}
      if (!mounted || my != _load) { vc.dispose(); return; }
      _vc = vc;
      setState(() { _file = f; _status = null; });
      final d = vc.value.duration;
      _prog.duration = d.inMilliseconds > 0 ? d : const Duration(seconds: 10);
      vc.play();
      _prog.forward(from: 0);
    }
  }

  void _next() {
    if (_i < widget.items.length - 1) { setState(() => _i++); _show(); } else { Navigator.maybePop(context); }
  }

  void _prev() {
    if (_i > 0) { setState(() => _i--); }
    _show();
  }

  void _pause(bool p) {
    if (p) { _prog.stop(); _vc?.pause(); } else if (_file != null || _status != null) { _prog.forward(); _vc?.play(); }
  }

  Future<void> _delete() async {
    _pause(true);
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Delete this status?'),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete'))],
    ));
    if (ok != true) { _pause(false); return; }
    await VideoRepo.delete(_v.id);
    await Audit.log('status_deleted', ref: _v.id);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _sendReply(String kind) async {
    final t = _reply.text.trim();
    if (kind == 'comment' && t.isEmpty) return;
    _reply.clear();
    FocusScope.of(context).unfocus();
    try {
      await Reactions.send(videoId: _v.id, owner: _v.owner, expiresAt: _v.expiresAt, me: widget.me, kind: kind, text: t);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(kind == 'like' ? 'Liked ❤' : 'Reply sent privately')));
    } catch (_) {}
    _pause(false);
  }

  @override
  Widget build(BuildContext context) {
    final v = _v;
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(children: [
          Positioned.fill(child: GestureDetector(
            onTapUp: (d) => d.localPosition.dx < MediaQuery.of(context).size.width / 3 ? _prev() : _next(),
            onLongPressStart: (_) => _pause(true),
            onLongPressEnd: (_) => _pause(false),
            child: Container(color: Colors.black, alignment: Alignment.center, child: _content()),
          )),
          // progress bars + header
          Positioned(left: 8, right: 8, top: 6, child: Column(children: [
            Row(children: [
              for (var k = 0; k < widget.items.length; k++) Expanded(child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2),
                child: AnimatedBuilder(animation: _prog, builder: (_, __) => LinearProgressIndicator(
                  value: k < _i ? 1 : k > _i ? 0 : _prog.value, minHeight: 3, borderRadius: BorderRadius.circular(2),
                  backgroundColor: Colors.white24, valueColor: const AlwaysStoppedAnimation(Colors.white))),
              )),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
              ClipOval(child: initialAvatar(context, _mine ? widget.me.name : v.ownerName, size: 36)),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_mine ? 'My status' : v.ownerName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                Text(agoText(v.createdAt), style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ])),
              if (_mine) IconButton(icon: const Icon(Icons.delete_outline, color: Colors.white), onPressed: _delete),
            ]),
          ])),
          // caption + footer
          Positioned(left: 0, right: 0, bottom: 0, child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (v.title.isNotEmpty) Container(
              width: double.infinity, color: Colors.black45, padding: const EdgeInsets.all(12),
              child: Text(v.title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 16)),
            ),
            _mine ? _ownerFooter() : _viewerFooter(),
          ])),
        ]),
      ),
    );
  }

  Widget _content() {
    if (_file == null) {
      return Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (_status == 'Loading…' || (_p > 0 && _p < 1) || (_status ?? '').startsWith('Connecting') || (_status ?? '').startsWith('Receiving'))
          CircularProgressIndicator(color: Colors.white, value: _p > 0 ? _p : null),
        const SizedBox(height: 16),
        Text(_status ?? '', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
      ]));
    }
    if (_v.isPhoto) return Image.file(_file!, fit: BoxFit.contain, width: double.infinity, height: double.infinity);
    final vc = _vc;
    if (vc == null || !vc.value.isInitialized) return const CircularProgressIndicator(color: Colors.white);
    return AspectRatio(aspectRatio: vc.value.aspectRatio, child: VideoPlayer(vc));
  }

  Widget _ownerFooter() => FutureBuilder<VideoThread>(
        future: Reactions.load(_v.id),
        builder: (context, t) => TextButton.icon(
          icon: const Icon(Icons.visibility, color: Colors.white),
          label: Text('${t.data?.views ?? 0} views  ·  ❤ ${t.data?.likes ?? 0}  ·  replies', style: const TextStyle(color: Colors.white)),
          onPressed: () async {
            _pause(true);
            await Navigator.push(context, MaterialPageRoute(builder: (_) => StatusRepliesScreen(videoId: _v.id)));
            _pause(false);
          },
        ),
      );

  Widget _viewerFooter() => Padding(
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
        child: Row(children: [
          Expanded(child: TextField(
            controller: _reply, maxLength: 300, style: const TextStyle(color: Colors.white),
            onTap: () => _pause(true),
            onSubmitted: (_) => _sendReply('comment'),
            decoration: InputDecoration(hintText: 'Reply privately…', hintStyle: const TextStyle(color: Colors.white54), counterText: '', filled: true, fillColor: Colors.white12,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
          )),
          IconButton(icon: const Icon(Icons.favorite_border, color: Colors.white), onPressed: () => _sendReply('like')),
          IconButton(icon: const Icon(Icons.send, color: Colors.white), onPressed: () => _sendReply('comment')),
        ]),
      );
}

/// Views, likes and private replies on one of my status updates (kept on my phone only).
class StatusRepliesScreen extends StatelessWidget {
  final String videoId;
  const StatusRepliesScreen({super.key, required this.videoId});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Views & replies')),
        body: OwnerThread(videoId: videoId),
      );
}
