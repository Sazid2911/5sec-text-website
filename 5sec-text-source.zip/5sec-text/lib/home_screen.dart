import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'app_theme.dart';
import 'chat_screen.dart';
import 'notifier.dart';
import 'contacts.dart';
import 'deals.dart';
import 'offline.dart';
import 'data.dart';
import 'main.dart';
import 'settings_screen.dart';
import 'reactions.dart';
import 'status.dart';
import 'videos.dart';

LinearGradient get homeGradient => AppTheme.gradient();

/// Favourite contacts, starred on this phone only.
class Favourites {
  static const _store = FlutterSecureStorage();
  static final ValueNotifier<Map<String, String>> list = ValueNotifier({}); // uid -> name
  static String get _key => 'favs_$myUid';
  static Future<void> load() async {
    try {
      final v = await _store.read(key: _key);
      list.value = v == null ? {} : Map<String, String>.from(jsonDecode(v) as Map);
    } catch (_) { list.value = {}; }
  }
  static bool has(String uid) => list.value.containsKey(uid);
  static Future<void> toggle(String uid, String name) async {
    final m = Map<String, String>.from(list.value);
    if (m.remove(uid) == null) m[uid] = name;
    list.value = m;
    await _store.write(key: _key, value: jsonEncode(m));
  }
}

Future<void> openChatWith(BuildContext context, AppUser me, String uid) async {
  final u = await Repo.watchUser(uid).first;
  if (u == null || !context.mounted) return;
  final id = await Repo.openDirectChat(me, u);
  if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: id, me: me)));
}

class HomeScreen extends StatefulWidget {
  final AppUser me;
  const HomeScreen({super.key, required this.me});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  final Set<int> _built = {0};

  @override
  void initState() {
    super.initState();
    Favourites.load();
    WidgetsBinding.instance.addPostFrameCallback((_) => _askNotifications());
  }

  /// First start after installing: ask once whether to turn on message notifications.
  Future<void> _askNotifications() async {
    await Notifier.loadSetting();
    if (Notifier.enabled != null || !mounted) return;
    final yes = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        icon: const Icon(Icons.notifications_active_outlined),
        title: const Text('Turn on notifications?'),
        content: const Text('Get the 5 Sec tone when a new message arrives. For privacy, notifications never show names or message text — just "New message".\n\nYou can change this any time in Settings.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('No')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Yes, turn on')),
        ],
      ),
    );
    await Notifier.setEnabled(yes == true);
  }

  static const _titles = ['Chats', 'Status', 'Contacts', 'Deals'];

  @override
  Widget build(BuildContext context) {
    final me = widget.me;
    final cs = Theme.of(context).colorScheme;
    final pages = <Widget>[
      _ChatsTab(me: me),
      StatusTab(me: me),
      _ContactsTab(me: me),
      DealsScreen(me: me),
    ];
    return Scaffold(
      appBar: _tab == 3 ? null : AppBar(
        foregroundColor: Colors.white,
        backgroundColor: Colors.transparent,
        flexibleSpace: Container(decoration: BoxDecoration(gradient: homeGradient)),
        titleSpacing: 16,
        title: Row(children: [
          Container(
            width: 34, height: 34, alignment: Alignment.center,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), borderRadius: BorderRadius.circular(10)),
            child: const Text('5', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: Colors.white)),
          ),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(appName, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 19)),
            Text(_titles[_tab], style: TextStyle(fontSize: 12, color: Colors.white.withValues(alpha: .8))),
          ]),
        ]),
        actions: [
          IconButton(
            tooltip: 'Offline chat (Bluetooth)',
            icon: const Icon(Icons.bluetooth),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => OfflineScreen(me: me))),
          ),
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen(me: me))),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(gradient: LinearGradient(
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [cs.primaryContainer.withValues(alpha: .55), cs.surface, cs.surface],
        )),
        child: IndexedStack(index: _tab, children: [
          for (var i = 0; i < pages.length; i++) _built.contains(i) ? pages[i] : const SizedBox.shrink(),
        ]),
      ),
      floatingActionButton: switch (_tab) {
        0 => _GradientFab(icon: Icons.add_comment_outlined, label: 'New chat',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewChatScreen(me: me)))),
        1 => _GradientFab(icon: Icons.photo_camera_outlined, label: 'Add status', onTap: () => postStatus(context, me)),
        2 => _GradientFab(icon: Icons.person_search_outlined, label: 'Find people',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ContactsScreen(me: me)))),
        _ => null,
      },
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() { _tab = i; _built.add(i); }),
        destinations: [
          NavigationDestination(icon: _ChatsBadge(me: me), selectedIcon: const Icon(Icons.chat_bubble), label: 'Chats'),
          const NavigationDestination(icon: Icon(Icons.donut_large_outlined), selectedIcon: Icon(Icons.donut_large), label: 'Status'),
          const NavigationDestination(icon: Icon(Icons.star_outline), selectedIcon: Icon(Icons.star), label: 'Contacts'),
          const NavigationDestination(icon: Icon(Icons.local_offer_outlined), selectedIcon: Icon(Icons.local_offer), label: 'Deals'),
        ],
      ),
    );
  }
}

class _ChatsBadge extends StatelessWidget {
  final AppUser me;
  const _ChatsBadge({required this.me});
  @override
  Widget build(BuildContext context) => StreamBuilder<List<Chat>>(
        stream: Repo.myChats(),
        builder: (_, s) {
          final n = (s.data ?? const <Chat>[]).where((c) => c.hasNewFor(me.uid)).length;
          return Badge(isLabelVisible: n > 0, label: Text('$n'), child: const Icon(Icons.chat_bubble_outline));
        },
      );
}

class _GradientFab extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _GradientFab({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(gradient: homeGradient, borderRadius: BorderRadius.circular(18),
            boxShadow: [BoxShadow(color: AppTheme.color.value.withValues(alpha: .35), blurRadius: 14, offset: const Offset(0, 6))]),
        child: FloatingActionButton.extended(
          onPressed: onTap, backgroundColor: Colors.transparent, foregroundColor: Colors.white, elevation: 0, highlightElevation: 0,
          icon: Icon(icon), label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
      );
}

/// Chats tab. Privacy: only UNREAD chats are listed (no names, no previews) and they vanish once opened.
class _ChatsTab extends StatelessWidget {
  final AppUser me;
  const _ChatsTab({required this.me});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ValueListenableBuilder<int>(
      valueListenable: Reactions.changed,
      builder: (context, _, __) => FutureBuilder<List<VideoThread>>(
        future: Reactions.unreadThreads(),
        builder: (context, ts) {
          final threads = ts.data ?? const <VideoThread>[];
          return StreamBuilder<List<Chat>>(
            stream: Repo.myChats(),
            builder: (context, snap) {
              final unread = (snap.data ?? const <Chat>[]).where((c) => c.hasNewFor(me.uid)).toList()
                ..sort((a, b) => a.updatedAt.compareTo(b.updatedAt));
              if (unread.isEmpty && threads.isEmpty) return _empty(context, cs);
              return ListView.builder(
                padding: const EdgeInsets.fromLTRB(0, 10, 0, 96),
                itemCount: threads.length + unread.length,
                itemBuilder: (context, i) {
                  if (i < threads.length) return _threadRow(context, me, threads[i]);
                  final c = unread[i - threads.length];
                  final icon = c.lastType == 'image' ? Icons.photo_camera : c.lastType == 'voice' ? Icons.mic : c.lastType == 'video' ? Icons.videocam : Icons.lock;
                  return Card(
                    elevation: 0,
                    color: cs.surfaceContainerLow,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    child: ListTile(
                      leading: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(shape: BoxShape.circle, gradient: homeGradient),
                        child: Icon(icon, color: Colors.white),
                      ),
                      title: const Text('New message', style: TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('Tap to open · disappears $viewSeconds s after you see it', style: TextStyle(color: cs.onSurfaceVariant)),
                      trailing: Text(_time(c.updatedAt), style: TextStyle(fontSize: 12, color: cs.primary, fontWeight: FontWeight.w700)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: c.id, me: me))),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }

  Widget _empty(BuildContext context, ColorScheme cs) => ListView(padding: const EdgeInsets.fromLTRB(20, 36, 20, 110), children: [
        Center(child: Container(
          width: 128, height: 128,
          decoration: BoxDecoration(shape: BoxShape.circle, gradient: homeGradient,
              boxShadow: [BoxShadow(color: AppTheme.color.value.withValues(alpha: .35), blurRadius: 30, offset: const Offset(0, 12))]),
          child: Stack(alignment: Alignment.center, children: [
            const Icon(Icons.chat_bubble, size: 64, color: Colors.white),
            Padding(padding: const EdgeInsets.only(bottom: 6), child: Text('5', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: cs.primary))),
          ]),
        )),
        const SizedBox(height: 22),
        const Text('You\'re all caught up', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Text('New messages appear here. Each one vanishes $viewSeconds seconds after you read it — no history, no traces.',
            textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, height: 1.4)),
        const SizedBox(height: 24),
        Row(children: [
          Expanded(child: _Tile(icon: Icons.lock_outline, title: 'Encrypted', text: 'End-to-end', color: AppTheme.color.value)),
          const SizedBox(width: 10),
          Expanded(child: _Tile(icon: Icons.timer_outlined, title: '$viewSeconds s', text: 'Vanish timer', color: const Color(0xFFDB2777))),
          const SizedBox(width: 10),
          Expanded(child: _Tile(icon: Icons.no_photography_outlined, title: 'No screenshots', text: 'Blocked', color: const Color(0xFFF59E0B))),
        ]),
        const SizedBox(height: 14),
        Card(
          elevation: 0, color: cs.surfaceContainerLow, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          child: ListTile(
            leading: const CircleAvatar(backgroundColor: Color(0xFF2563EB), foregroundColor: Colors.white, child: Icon(Icons.bluetooth)),
            title: const Text('No internet?', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Chat with someone nearby over Bluetooth'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => OfflineScreen(me: me))),
          ),
        ),
      ]);
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String title, text;
  final Color color;
  const _Tile({required this.icon, required this.title, required this.text, required this.color});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
        decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(16)),
        child: Column(children: [
          Icon(icon, color: color),
          const SizedBox(height: 6),
          Text(title, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
          Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ]),
      );
}

/// Contacts tab: favourites (starred on this phone) + recent chats.
class _ContactsTab extends StatelessWidget {
  final AppUser me;
  const _ContactsTab({required this.me});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return StreamBuilder<List<Chat>>(
      stream: Repo.myChats(),
      builder: (context, snap) {
        final recent = (snap.data ?? const <Chat>[]).take(30).toList();
        return ValueListenableBuilder<Map<String, String>>(
          valueListenable: Favourites.list,
          builder: (context, favs, _) => ListView(padding: const EdgeInsets.fromLTRB(12, 14, 12, 110), children: [
            Row(children: [
              Expanded(child: _action(context, Icons.contacts_outlined, 'Phone contacts', () => Navigator.push(context, MaterialPageRoute(builder: (_) => ContactsScreen(me: me))))),
              const SizedBox(width: 10),
              Expanded(child: _action(context, Icons.alternate_email, 'By username', () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewChatScreen(me: me))))),
            ]),
            const SizedBox(height: 18),
            const Text('FAVOURITES', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 1)),
            const SizedBox(height: 10),
            if (favs.isEmpty)
              Text('Tap ☆ on a recent chat to add it here.', style: TextStyle(color: cs.onSurfaceVariant))
            else
              SizedBox(
                height: 96,
                child: ListView(scrollDirection: Axis.horizontal, children: [
                  for (final e in favs.entries)
                    Padding(
                      padding: const EdgeInsets.only(right: 14),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(40),
                        onTap: () => openChatWith(context, me, e.key),
                        onLongPress: () => Favourites.toggle(e.key, e.value),
                        child: SizedBox(width: 68, child: Column(children: [
                          StatusRing(unseen: true, size: 56, child: initialAvatar(context, e.value, size: 56)),
                          const SizedBox(height: 4),
                          Text(e.value.isEmpty ? 'Contact' : e.value.split(' ').first, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                        ])),
                      ),
                    ),
                ]),
              ),
            const SizedBox(height: 18),
            const Text('RECENT', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: 1)),
            const SizedBox(height: 6),
            if (recent.isEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text('No chats yet.', style: TextStyle(color: cs.onSurfaceVariant))),
            for (final c in recent)
              Card(
                elevation: 0, color: cs.surfaceContainerLow, margin: const EdgeInsets.symmetric(vertical: 4),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  leading: ClipOval(child: c.isGroup
                      ? Container(width: 44, height: 44, decoration: BoxDecoration(gradient: homeGradient), child: const Icon(Icons.group, color: Colors.white))
                      : initialAvatar(context, c.title(me.uid), size: 44)),
                  title: Text(c.title(me.uid), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(c.hasNewFor(me.uid) ? 'New message' : 'Last activity ${_time(c.updatedAt)}',
                      style: TextStyle(color: c.hasNewFor(me.uid) ? cs.primary : cs.onSurfaceVariant, fontWeight: c.hasNewFor(me.uid) ? FontWeight.w700 : null)),
                  trailing: c.isGroup ? null : IconButton(
                    tooltip: 'Favourite',
                    icon: Icon(favs.containsKey(c.otherUid(me.uid)) ? Icons.star : Icons.star_outline, color: favs.containsKey(c.otherUid(me.uid)) ? const Color(0xFFF59E0B) : null),
                    onPressed: () => Favourites.toggle(c.otherUid(me.uid)!, c.title(me.uid)),
                  ),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: c.id, me: me))),
                ),
              ),
            const SizedBox(height: 8),
            Text('Favourites are saved only on this phone. Message history is never shown — chats keep only what is unread.',
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
          ]),
        );
      },
    );
  }

  Widget _action(BuildContext context, IconData icon, String label, VoidCallback onTap) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(gradient: homeGradient, borderRadius: BorderRadius.circular(16)),
          child: InkWell(
            borderRadius: BorderRadius.circular(16), onTap: onTap,
            child: Padding(padding: const EdgeInsets.symmetric(vertical: 16), child: Column(children: [
              Icon(icon, color: Colors.white),
              const SizedBox(height: 6),
              Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            ])),
          ),
        ),
      );
}

/// A status of mine with new likes / replies / views.
Widget _threadRow(BuildContext context, AppUser me, VideoThread t) {
  final cs = Theme.of(context).colorScheme;
  return Card(
    elevation: 0,
    color: cs.surfaceContainerLow,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
    child: ListTile(
      leading: Container(width: 44, height: 44, decoration: BoxDecoration(shape: BoxShape.circle, gradient: statusGradient), child: const Icon(Icons.donut_large, color: Colors.white)),
      title: Text('My status${t.title.isEmpty ? '' : ' · ${t.title}'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Row(children: [
        Icon(Icons.visibility, size: 16, color: cs.primary), Text(' ${t.views}   '),
        const Icon(Icons.favorite, size: 16, color: Colors.red), Text(' ${t.likes}   '),
        Text('${t.unread} new', style: TextStyle(color: cs.primary, fontWeight: FontWeight.w700)),
      ]),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StatusRepliesScreen(videoId: t.videoId))),
    ),
  );
}

String _two(int v) => v.toString().padLeft(2, '0');
String _time(DateTime t) {
  final now = DateTime.now();
  if (now.difference(t).inHours < 24 && now.day == t.day) return '${_two(t.hour)}:${_two(t.minute)}';
  return '${t.day}/${t.month}';
}

class NewChatScreen extends StatefulWidget {
  final AppUser me;
  const NewChatScreen({super.key, required this.me});
  @override
  State<NewChatScreen> createState() => _NewChatScreenState();
}

class _NewChatScreenState extends State<NewChatScreen> {
  final _q = TextEditingController();
  final _groupName = TextEditingController();
  AppUser? _found;
  String? _msg;
  bool _busy = false, _group = false;
  final List<AppUser> _picked = [];
  final _code = TextEditingController();
  Timer? _deb;
  List<AppUser> _online = [];
  final Map<String, (String, String)> _local = {}; // uid -> (name, username): my chats, favourites, status contacts

  @override
  void initState() {
    super.initState();
    _loadLocal();
    _loadGroups();
    _q.addListener(() {
      setState(() { _found = null; _msg = null; });
      _deb?.cancel();
      _deb = Timer(const Duration(milliseconds: 350), _live);
    });
  }

  @override
  void dispose() {
    _deb?.cancel();
    super.dispose();
  }

  Future<void> _loadLocal() async {
    try {
      for (final c in await Repo.myChats().first) {
        final o = c.otherUid(widget.me.uid);
        if (o != null && o != widget.me.uid) _local[o] = (c.names[o] ?? '', '');
      }
    } catch (_) {}
    Favourites.list.value.forEach((uid, name) => _local.putIfAbsent(uid, () => (name, '')));
    try {
      for (final d in (await VideoRepo.friends().first).docs) {
        final m = d.data();
        _local[d.id] = ((m['name'] ?? _local[d.id]?.$1 ?? '') as String, (m['username'] ?? '') as String);
      }
    } catch (_) {}
    if (mounted) setState(() {});
  }

  Future<void> _live() async {
    final q = _q.text.trim();
    final r = await Repo.searchUsers(q);
    if (mounted && _q.text.trim() == q) setState(() => _online = r);
  }

  /// Tap on a suggestion: open the chat, or add to the new group.
  Future<void> _pick(String uid) async {
    final u = _online.where((x) => x.uid == uid).firstOrNull ?? await Repo.watchUser(uid).first;
    if (u == null || !mounted) return;
    if (_group) {
      setState(() { if (!_picked.any((p) => p.uid == u.uid)) _picked.add(u); _q.clear(); });
    } else {
      await _openDirect(u);
    }
  }

  Future<void> _search() async {
    setState(() { _busy = true; _msg = null; _found = null; });
    try {
      final u = await Repo.findByUsername(_q.text);
      if (u == null) {
        _msg = 'No user with that username';
      } else if (u.uid == widget.me.uid) {
        _msg = 'That\'s you 🙂';
      } else {
        _found = u;
      }
    } catch (e) {
      _msg = 'Search failed: $e';
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _openDirect(AppUser u) async {
    final id = await Repo.openDirectChat(widget.me, u);
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: id, me: widget.me)));
  }

  /// My groups whose name (= group code) matches what was typed, any word order.
  List<Chat> _myGroups = [];
  Future<void> _loadGroups() async {
    try { _myGroups = (await Repo.myChats().first).where((c) => c.isGroup).toList(); } catch (_) {}
    if (mounted) setState(() {});
  }

  void _openGroup(Chat c) => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: c.id, me: widget.me)));

  Future<void> _openByCode() async {
    final q = _code.text.trim();
    if (q.isEmpty) return;
    final match = _myGroups.where((c) => c.name.toLowerCase() == q.toLowerCase() || c.code.toLowerCase() == q.toLowerCase()).toList();
    if (match.length == 1) { _openGroup(match.first); return; }
    setState(() => _msg = match.isEmpty ? 'None of your groups is called "$q"' : 'More than one group has this name — pick one below');
  }

  List<Widget> _groupResults() {
    final q = _code.text.trim();
    final cs = Theme.of(context).colorScheme;
    final list = q.isEmpty ? _myGroups : _myGroups.where((c) => matchesWords('${c.name} ${c.code}', q)).toList();
    if (list.isEmpty) {
      return [Padding(padding: const EdgeInsets.only(top: 8), child: Text(q.isEmpty ? 'You are not in any group yet.' : 'No group of yours matches "$q".', style: TextStyle(color: cs.onSurfaceVariant)))];
    }
    return [
      for (final c in list.take(20))
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 4),
          leading: CircleAvatar(backgroundColor: cs.primary, foregroundColor: cs.onPrimary, child: const Icon(Icons.group)),
          title: Text(c.name.isEmpty ? 'Group' : c.name, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${c.members.length} members${c.hasNewFor(widget.me.uid) ? ' · new message' : ''}'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _openGroup(c),
        ),
    ];
  }

  List<Widget> _suggestions() {
    final q = _q.text.trim();
    if (q.isEmpty) return const [];
    final cs = Theme.of(context).colorScheme;
    final mine = _local.entries.where((e) => matchesWords('${e.value.$1} ${e.value.$2}', q)).take(10).toList();
    final online = _online.where((u) => !_local.containsKey(u.uid) && matchesWords('${u.name} ${u.username}', q)).take(10).toList();
    Widget row(String uid, String name, String sub, bool known) => ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 4),
          leading: CircleAvatar(backgroundColor: known ? cs.primary : cs.secondaryContainer, foregroundColor: known ? cs.onPrimary : cs.onSecondaryContainer,
              child: Text(name.isEmpty ? '?' : name[0].toUpperCase())),
          title: Text(name.isEmpty ? (sub.isEmpty ? 'Contact' : sub) : name),
          subtitle: sub.isEmpty ? null : Text(sub),
          trailing: _group
              ? (_picked.any((p) => p.uid == uid) ? const Icon(Icons.check_circle, color: Colors.green) : const Icon(Icons.person_add_alt_1))
              : const Icon(Icons.chat_bubble_outline),
          onTap: () => _pick(uid),
        );
    return [
      if (mine.isNotEmpty) const Padding(padding: EdgeInsets.only(top: 12), child: Text('Your contacts', style: TextStyle(fontWeight: FontWeight.w700))),
      for (final e in mine) row(e.key, e.value.$1, e.value.$2.isEmpty ? '' : '@${e.value.$2}', true),
      if (online.isNotEmpty) const Padding(padding: EdgeInsets.only(top: 12), child: Text('On 5 Sec Text', style: TextStyle(fontWeight: FontWeight.w700))),
      for (final u in online) row(u.uid, u.name, '@${u.username}', false),
      if (mine.isEmpty && online.isEmpty && q.length >= 2)
        Padding(padding: const EdgeInsets.only(top: 12), child: Text('No match yet. Press search to look up the exact username "@${q.replaceAll('@', '').toLowerCase()}".',
            style: TextStyle(color: cs.onSurfaceVariant))),
    ];
  }

  Future<void> _createGroup() async {
    if (_groupName.text.trim().isEmpty || _picked.isEmpty) {
      setState(() => _msg = 'Give the group a name and add at least one person');
      return;
    }
    final name = _groupName.text.trim().toLowerCase();
    if (_myGroups.any((c) => c.name.trim().toLowerCase() == name)) {
      setState(() => _msg = 'You already have a group called "${_groupName.text.trim()}". Pick a different name — the name is the group code.');
      return;
    }
    final id = await Repo.createGroup(widget.me, _groupName.text, _picked);
    if (!mounted) return;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: id, me: widget.me)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_group ? 'New group' : 'New chat')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SegmentedButton<bool>(
          segments: const [
            ButtonSegment(value: false, label: Text('Person'), icon: Icon(Icons.person_outline)),
            ButtonSegment(value: true, label: Text('Group'), icon: Icon(Icons.group_outlined)),
          ],
          selected: {_group},
          onSelectionChanged: (s) => setState(() { _group = s.first; _msg = null; }),
        ),
        const SizedBox(height: 16),
        if (!_group) ...[
          Card(
            margin: EdgeInsets.zero,
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.contacts_outlined)),
              title: const Text('Find from my contacts', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Search by the name saved in your phone'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ContactsScreen(me: widget.me))),
            ),
          ),
          const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Text('— or search by username —', textAlign: TextAlign.center)),
        ],
        if (_group) ...[
          Row(children: [
            Expanded(child: TextField(controller: _code, textCapitalization: TextCapitalization.words, onChanged: (_) => setState(() => _msg = null), onSubmitted: (_) => _openByCode(),
                decoration: const InputDecoration(labelText: 'Find your group by name', hintText: 'The group name is its code', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()))),
            const SizedBox(width: 8),
            FilledButton(onPressed: _openByCode, child: const Text('Open')),
          ]),
          ..._groupResults(),
          const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Text('— or create a new group —', textAlign: TextAlign.center)),
          TextField(controller: _groupName, maxLength: 40, decoration: const InputDecoration(labelText: 'Group name', border: OutlineInputBorder())),
          const SizedBox(height: 8),
        ],
        Row(children: [
          Expanded(
            child: TextField(
              controller: _q,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _search(),
              decoration: const InputDecoration(labelText: 'Search name or username', hintText: 'Type any part of a name, e.g. "saj"', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: _busy ? null : _search, icon: const Icon(Icons.search)),
        ]),
        ..._suggestions(),
        if (_msg != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_msg!)),
        if (_found != null)
          Card(
            margin: const EdgeInsets.only(top: 12),
            child: ListTile(
              leading: CircleAvatar(child: Text(_found!.name.isEmpty ? '?' : _found!.name[0].toUpperCase())),
              title: Text(_found!.name),
              subtitle: Text('@${_found!.username}'),
              trailing: _group
                  ? FilledButton.tonal(
                      onPressed: () => setState(() {
                        if (!_picked.any((p) => p.uid == _found!.uid)) _picked.add(_found!);
                        _found = null;
                        _q.clear();
                      }),
                      child: const Text('Add'))
                  : FilledButton(onPressed: () => _openDirect(_found!), child: const Text('Chat')),
            ),
          ),
        if (_group) ...[
          const SizedBox(height: 16),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final p in _picked) InputChip(label: Text(p.name), onDeleted: () => setState(() => _picked.remove(p))),
          ]),
          const SizedBox(height: 16),
          FilledButton(onPressed: _createGroup, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)), child: Text('Create group (${_picked.length + 1} people)')),
        ],
      ]),
    );
  }
}
