// Firebase project "5sec-text" (project id: fivesec-text).
// These are public identifiers, not secrets; access is protected by firestore.rules.
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAm4w2IxqEDBoa7dQS0zHAmnzju9MSZWgE',
    appId: '1:155273836189:android:77870b616ac0c850510674',
    messagingSenderId: '155273836189',
    projectId: 'fivesec-text',
    storageBucket: 'fivesec-text.firebasestorage.app',
  );
}
