// App colour chosen by the user in Settings. The design stays the same (gradient header,
// gradient buttons, status rings); only the colours follow the chosen theme colour.
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AppTheme {
  static const options = <String, Color>{
    'Purple': Color(0xFF6C3CE0),
    'Blue': Color(0xFF1E64F0),
    'Teal': Color(0xFF00897B),
    'Green': Color(0xFF2E9E4F),
    'Orange': Color(0xFFF2700F),
    'Pink': Color(0xFFD63384),
    'Red': Color(0xFFD32F2F),
    'Indigo': Color(0xFF3F51B5),
    'Brown': Color(0xFF795548),
    'Graphite': Color(0xFF455A64),
  };
  static const _store = FlutterSecureStorage();
  static final ValueNotifier<Color> color = ValueNotifier(options['Green']!); // default: Green

  static Future<void> load() async {
    try {
      final v = await _store.read(key: 'app_color');
      if (v != null) color.value = Color(int.parse(v));
    } catch (_) {}
  }

  static const _device = MethodChannel('fivesec/device');

  /// Changes the app colour and the home-screen icon to match.
  static Future<void> set(Color c) async {
    color.value = c;
    try { await _store.write(key: 'app_color', value: c.toARGB32().toString()); } catch (_) {}
    final name = options.entries.where((e) => e.value.toARGB32() == c.toARGB32()).map((e) => e.key.toLowerCase()).firstOrNull;
    if (name != null) {
      try { await _device.invokeMethod('setIcon', {'name': name}); } catch (_) {}
    }
  }

  static Color _shift(Color c, double hue, double light) {
    final h = HSLColor.fromColor(c);
    return h.withHue((h.hue + hue) % 360).withLightness((h.lightness + light).clamp(0.15, 0.75)).toColor();
  }

  /// Header / buttons: darker shade → theme colour → neighbouring accent.
  static LinearGradient gradient() {
    final c = color.value;
    return LinearGradient(colors: [_shift(c, -4, -0.14), c, _shift(c, 60, 0.02)], begin: Alignment.topLeft, end: Alignment.bottomRight);
  }

  /// Status rings: theme colour → accent → warm highlight.
  static LinearGradient statusGradient() {
    final c = color.value;
    return LinearGradient(colors: [c, _shift(c, 60, 0.02), _shift(c, 130, 0.08)], begin: Alignment.topLeft, end: Alignment.bottomRight);
  }
}
