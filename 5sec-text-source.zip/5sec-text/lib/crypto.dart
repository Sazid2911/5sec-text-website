// End-to-end encryption for 5 Sec Text.
//
// Each phone creates an X25519 key pair on first use. The private key never
// leaves the phone (Android Keystore-backed secure storage); the public key
// is published on the user's profile.
//
// Every message gets a fresh random AES-256-GCM key. The content (text, photo,
// voice or video) is encrypted with it, and that key is then "wrapped"
// (encrypted) separately for each chat member - including the sender - with a
// key derived from X25519(sender, member) + HKDF-SHA256. The server only ever
// stores ciphertext and wrapped keys, so it cannot read any message.
import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'data.dart';

class E2E {
  static final _x = X25519();
  static final _aes = AesGcm.with256bits();
  static final _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
  static const _store = FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));

  static SimpleKeyPair? _kp;
  static String? _kpUid;
  static String? _myPub;
  static Future<void>? _initing;
  static final Map<String, SecretKey> _pairCache = {};

  /// This phone's public key (base64). Sent with every message so receivers use
  /// exactly the key the message was sealed with.
  static Future<String> myPub() async { await init(); return _myPub!; }

  /// Load (or create) this phone's key pair and publish the public key.
  /// Safe to call many times at once: only ONE key pair is ever created
  /// (two parallel first-starts used to create two different keys, so the
  /// published key and the key on the phone could differ and nothing decrypted).
  static Future<void> init() {
    if (_kp != null && _kpUid == myUid) return Future.value();
    return _initing ??= _load().whenComplete(() => _initing = null);
  }

  static Future<void> _load() async {
    final uid = myUid;
    final storeKey = 'x25519_$uid';
    final saved = await _store.read(key: storeKey);
    SimpleKeyPair kp;
    if (saved != null) {
      kp = await _x.newKeyPairFromSeed(base64Decode(saved));
    } else {
      kp = await _x.newKeyPair();
      await _store.write(key: storeKey, value: base64Encode(await kp.extractPrivateKeyBytes()));
      // read back: make sure the key really is stored before publishing it
      final check = await _store.read(key: storeKey);
      if (check != null) kp = await _x.newKeyPairFromSeed(base64Decode(check));
    }
    _kp = kp;
    _kpUid = uid;
    _pairCache.clear();
    _myPub = base64Encode((await kp.extractPublicKey()).bytes);
    // Always make sure the published key matches the key on this phone.
    final published = await _pubOf(uid).catchError((_) => null);
    if (published != _myPub) {
      await db.collection('users').doc(uid).update({'pub': _myPub});
    }
  }

  static Future<String?> _pubOf(String uid) async {
    final d = await db.collection('users').doc(uid).get();
    return d.data()?['pub'] as String?;
  }

  static Future<SecretKey?> _pairKey(String uid, {String? knownPub}) async {
    final pubB64 = knownPub ?? await _pubOf(uid);
    if (pubB64 == null) return null;
    final cacheKey = '$uid:$pubB64';
    final hit = _pairCache[cacheKey];
    if (hit != null) return hit;
    final shared = await _x.sharedSecretKey(
      keyPair: _kp!,
      remotePublicKey: SimplePublicKey(base64Decode(pubB64), type: KeyPairType.x25519),
    );
    final k = await _hkdf.deriveKey(secretKey: shared, nonce: utf8.encode('5sec-text-v1'), info: utf8.encode('wrap'));
    _pairCache[cacheKey] = k;
    return k;
  }

  /// Encrypts [plain] for every uid in [members]. Returns the ciphertext and
  /// the per-member wrapped keys. Throws if a member has never opened the app
  /// (no public key yet).
  static Future<(Uint8List, Map<String, String>)> seal(Uint8List plain, List<String> members) async {
    await init();
    final contentKey = await _aes.newSecretKey();
    final contentKeyBytes = await contentKey.extractBytes();
    final box = await _aes.encrypt(plain, secretKey: contentKey);
    final wrapped = <String, String>{};
    for (final uid in members.toSet()) {
      final pk = await _pairKey(uid);
      if (pk == null) throw 'A member has not opened the app yet, so messages to them cannot be encrypted.';
      final w = await _aes.encrypt(contentKeyBytes, secretKey: pk);
      wrapped[uid] = base64Encode(w.concatenation());
    }
    return (Uint8List.fromList(box.concatenation()), wrapped);
  }

  /// Decrypts a message sent by [from]. Returns null if it can't be opened
  /// (e.g. it was sent to an older key before this phone was reinstalled).
  static Future<Uint8List?> open(Uint8List cipher, Map<String, String> wrapped, String from, {String? senderPub}) async {
    try {
      await init();
      final mine = wrapped[myUid];
      if (mine == null) return null;
      // Use the sender's key the message was sealed with (falls back to their current key for older messages).
      final pk = await _pairKey(from, knownPub: (senderPub != null && senderPub.isNotEmpty) ? senderPub : null);
      if (pk == null) return null;
      final contentKeyBytes = await _aes.decrypt(
        SecretBox.fromConcatenation(base64Decode(mine), nonceLength: 12, macLength: 16),
        secretKey: pk,
      );
      final plain = await _aes.decrypt(
        SecretBox.fromConcatenation(cipher, nonceLength: 12, macLength: 16),
        secretKey: SecretKey(contentKeyBytes),
      );
      return Uint8List.fromList(plain);
    } catch (_) {
      return null;
    }
  }

  // ---- helpers for the video tab (per-video key shared with friends) ----
  static Future<List<int>> randomKey() async => (await _aes.newSecretKey()).extractBytes();

  static Future<Map<String, String>> wrapFor(List<int> keyBytes, Iterable<String> uids) async {
    await init();
    final out = <String, String>{};
    for (final uid in uids.toSet()) {
      final pk = await _pairKey(uid);
      if (pk == null) continue; // friend hasn't opened the app yet; re-wrapped later
      out[uid] = base64Encode((await _aes.encrypt(keyBytes, secretKey: pk)).concatenation());
    }
    return out;
  }

  static Future<List<int>?> unwrapFrom(Map<String, String> wk, String from) async {
    try {
      await init();
      final mine = wk[myUid];
      final pk = await _pairKey(from);
      if (mine == null || pk == null) return null;
      return await _aes.decrypt(SecretBox.fromConcatenation(base64Decode(mine), nonceLength: 12, macLength: 16), secretKey: pk);
    } catch (_) {
      return null;
    }
  }

  static Future<Uint8List> aesSeal(List<int> plain, List<int> key) async =>
      Uint8List.fromList((await _aes.encrypt(plain, secretKey: SecretKey(key))).concatenation());

  static Future<Uint8List?> aesOpen(Uint8List cipher, List<int> key) async {
    try {
      return Uint8List.fromList(await _aes.decrypt(SecretBox.fromConcatenation(cipher, nonceLength: 12, macLength: 16), secretKey: SecretKey(key)));
    } catch (_) {
      return null;
    }
  }

  static Future<void> saveSecret(String name, List<int> bytes) => _store.write(key: name, value: base64Encode(bytes));
  static Future<List<int>?> loadSecret(String name) async { final v = await _store.read(key: name); return v == null ? null : base64Decode(v); }
  static Future<void> deleteSecret(String name) => _store.delete(key: name);

  static Future<void> forget() async {
    _kp = null;
    _kpUid = null;
    _pairCache.clear();
  }
}
