// On-device nudity / sexual-content check for pictures in the Deals tab.
// Uses a small MobileNetV2 classifier (assets/models/nsfw.tflite, MIT licence,
// converted from NSFWJS). Runs entirely on the phone - pictures are never sent
// anywhere for checking.
import 'dart:typed_data';

import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

class NudityCheck {
  static Interpreter? _it;
  static final Map<int, bool> _cache = {};

  static Future<Interpreter> _load() async => _it ??= await Interpreter.fromAsset('assets/models/nsfw.tflite');

  /// True if the picture looks like nudity or sexual content (or can't be read).
  static Future<bool> isUnsafe(Uint8List bytes) async {
    final key = Object.hashAll([bytes.length, ...bytes.take(64), ...bytes.skip(bytes.length > 64 ? bytes.length - 64 : 0)]);
    final hit = _cache[key];
    if (hit != null) return hit;
    bool unsafe;
    try {
      final decoded = img.decodeImage(bytes);
      if (decoded == null) return true;
      final r = img.copyResize(decoded, width: 224, height: 224);
      final input = [
        List.generate(224, (y) => List.generate(224, (x) {
              final p = r.getPixel(x, y);
              return [p.r / 255.0, p.g / 255.0, p.b / 255.0];
            }))
      ];
      final out = [List<double>.filled(5, 0)];
      (await _load()).run(input, out);
      final p = out[0]; // 0 Drawing, 1 Hentai, 2 Neutral, 3 Porn, 4 Sexy
      unsafe = p[3] > 0.45 || p[1] > 0.45 || p[4] > 0.6 || (p[1] + p[3] + p[4]) > 0.7;
    } catch (_) {
      unsafe = true; // fail closed
    }
    _cache[key] = unsafe;
    return unsafe;
  }
}

/// Checks a video by sampling frames across its length (on the phone).
/// True if any frame looks like nudity / sexual content.
Future<bool> videoLooksUnsafe(String path, int durationMs, {int samples = 10}) async {
  final dur = durationMs > 0 ? durationMs : 30000;
  for (var i = 0; i < samples; i++) {
    final ms = ((i + 0.5) * dur / samples).round();
    try {
      final frame = await VideoThumbnail.thumbnailData(video: path, imageFormat: ImageFormat.JPEG, timeMs: ms, maxWidth: 320, quality: 70);
      if (frame != null && await NudityCheck.isUnsafe(frame)) return true;
    } catch (_) {}
  }
  return false;
}

/// Words that are never allowed in deal text.
const _blockedWords = ['nude', 'nudes', 'naked', 'porn', 'xxx', 'sex', 'sexy', 'escort', 'onlyfans', 'adult content', 'nsfw'];
bool hasBlockedWords(String text) {
  final t = ' ${text.toLowerCase().replaceAll(RegExp(r'[^a-z0-9 ]'), ' ')} ';
  return _blockedWords.any((w) => t.contains(' $w '));
}
