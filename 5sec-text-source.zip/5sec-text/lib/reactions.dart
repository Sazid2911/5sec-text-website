// Likes and comments on videos are sent to the uploader as end-to-end encrypted
// direct messages. The server only relays them: the uploader's phone decrypts
// each one, saves it in a local file on the phone, and deletes it from the
// server immediately. So likes/comments live only on the uploader's phone.
//
// On the uploader's phone each video appears like a contact named after the
// video ("🎬 <title>"), and its likes and comments show inside that thread.
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'crypto.dart';
import 'data.dart';

class Reaction {
  final String id, from, name, kind, text; // kind: like | comment | view
  final DateTime at;
  Reaction(this.id, this.from, this.name, this.kind, this.text, this.at);
  Map<String, dynamic> toJson() => {'i': id, 'f': from, 'n': name, 'k': kind, 't': text, 'a': at.millisecondsSinceEpoch};
  factory Reaction.fromJson(Map<String, dynamic> j) => Reaction((j['i'] ?? '') as String, j['f'] as String, j['n'] as String,
      j['k'] as String, (j['t'] ?? '') as String, DateTime.fromMillisecondsSinceEpoch(j['a'] as int));
  String get label => kind == 'like' ? 'liked your status ❤' : kind == 'view' ? 'viewed your status 👁' : text;
}

/// One video's thread on the uploader's phone: running totals (views, likes)
/// plus the new like/comment/view messages waiting to be seen. Each message
/// disappears 5 seconds after the uploader sees it; the totals stay.
class VideoThread {
  final String videoId, title;
  final Set<String> likers, viewers;
  final List<Reaction> items;
  VideoThread(this.videoId, this.title, this.likers, this.viewers, this.items);
  int get likes => likers.length;
  int get views => viewers.length;
  int get unread => items.length;
}

class Reactions {
  /// Bumped whenever local reaction data changes, so screens can refresh.
  static final ValueNotifier<int> changed = ValueNotifier(0);

  static Future<Directory> _dir() async {
    final d = Directory('${(await getApplicationDocumentsDirectory()).path}/reactions_$myUid');
    if (!d.existsSync()) d.createSync(recursive: true);
    return d;
  }

  static Future<File> _file(String videoId) async => File('${(await _dir()).path}/$videoId.json');

  static Future<VideoThread> load(String videoId) async {
    final f = await _file(videoId);
    if (!f.existsSync()) return VideoThread(videoId, '', {}, {}, []);
    final j = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
    return VideoThread(
      videoId,
      (j['title'] ?? '') as String,
      Set<String>.from(j['likers'] ?? const []),
      Set<String>.from(j['viewers'] ?? const []),
      [for (final r in (j['items'] as List? ?? const [])) Reaction.fromJson(Map<String, dynamic>.from(r as Map))],
    );
  }

  static Future<void> _save(VideoThread t) async {
    final f = await _file(t.videoId);
    await f.writeAsString(jsonEncode({'title': t.title, 'likers': t.likers.toList(), 'viewers': t.viewers.toList(), 'items': [for (final r in t.items) r.toJson()]}));
    changed.value++;
  }

  /// Removes messages that have been seen (called 5 s after they appeared on screen).
  static Future<void> consume(String videoId, Set<String> ids) async {
    final t = await load(videoId);
    await _save(VideoThread(t.videoId, t.title, t.likers, t.viewers, t.items.where((r) => !ids.contains(r.id)).toList()));
  }

  /// Threads with new messages, for the home screen.
  static Future<List<VideoThread>> unreadThreads() async {
    final out = <VideoThread>[];
    for (final f in (await _dir()).listSync().whereType<File>()) {
      final t = await load(f.uri.pathSegments.last.replaceAll('.json', ''));
      if (t.unread > 0) out.add(t);
    }
    return out;
  }

  static Future<void> deleteFor(String videoId) async {
    final f = await _file(videoId);
    if (f.existsSync()) f.deleteSync();
    changed.value++;
  }

  // ---------------- viewer side ----------------
  static Future<File> _likedFile() async => File('${(await getApplicationDocumentsDirectory()).path}/liked_$myUid.json');

  static Future<bool> iLiked(String videoId) async {
    final f = await _likedFile();
    if (!f.existsSync()) return false;
    return (jsonDecode(await f.readAsString()) as List).contains(videoId);
  }

  static Future<bool> _viewedBefore(String videoId) async {
    final f = File('${(await getApplicationDocumentsDirectory()).path}/viewed_$myUid.json');
    final list = f.existsSync() ? List<String>.from(jsonDecode(await f.readAsString()) as List) : <String>[];
    if (list.contains(videoId)) return true;
    list.add(videoId);
    await f.writeAsString(jsonEncode(list));
    return false;
  }

  /// Tells the uploader "someone watched" - once per person per video.
  static Future<void> sendView({required String videoId, required String owner, required DateTime expiresAt, required AppUser me}) async {
    if (owner == me.uid || await _viewedBefore(videoId)) return;
    await send(videoId: videoId, owner: owner, expiresAt: expiresAt, me: me, kind: 'view');
  }

  static Future<void> _setLiked(String videoId, bool liked) async {
    final f = await _likedFile();
    final list = f.existsSync() ? List<String>.from(jsonDecode(await f.readAsString()) as List) : <String>[];
    list.remove(videoId);
    if (liked) list.add(videoId);
    await f.writeAsString(jsonEncode(list));
  }

  /// Sends a like / unlike / comment privately to the uploader.
  static Future<void> send({required String videoId, required String owner, required DateTime expiresAt, required AppUser me, required String kind, String text = ''}) async {
    final plain = Uint8List.fromList(utf8.encode(jsonEncode({'k': kind, 't': text})));
    final (cipher, wk) = await E2E.seal(plain, [owner, me.uid]);
    await db.collection('inbox').doc(owner).collection('items').add({
      'from': me.uid,
      'name': me.name,
      'video': videoId,
      'data': Blob(cipher),
      'wk': wk,
      'e': 1,
      'createdAt': FieldValue.serverTimestamp(),
      'expireAt': Timestamp.fromDate(expiresAt),
    });
    if (kind == 'like') await _setLiked(videoId, true);
    if (kind == 'unlike') await _setLiked(videoId, false);
  }

  // ---------------- uploader side ----------------
  static StreamSubscription? _sub;
  static final Set<String> _busy = {};

  static void listen() {
    _sub ??= db.collection('inbox').doc(myUid).collection('items').snapshots().listen((s) {
      for (final d in s.docs) {
        if (_busy.add(d.id)) _receive(d);
      }
    }, onError: (_) {});
  }

  static void stop() {
    _sub?.cancel();
    _sub = null;
  }

  static Future<void> _receive(QueryDocumentSnapshot<Map<String, dynamic>> d) async {
    final m = d.data();
    final blob = m['data'];
    final from = (m['from'] ?? '') as String;
    final videoId = (m['video'] ?? '') as String;
    if (blob is Blob) {
      final plain = await E2E.open(blob.bytes, Map<String, String>.from(m['wk'] ?? const {}), from);
      if (plain != null) {
        final j = jsonDecode(utf8.decode(plain)) as Map<String, dynamic>;
        final t = await load(videoId);
        var title = t.title;
        if (title.isEmpty) {
          final v = await db.collection('videos').doc(videoId).get();
          title = (v.data()?['title'] ?? 'My video') as String;
        }
        final ts = m['createdAt'];
        final at = ts is Timestamp ? ts.toDate() : DateTime.now();
        final kind = (j['k'] ?? 'comment') as String;
        final likers = {...t.likers}, viewers = {...t.viewers};
        final items = [...t.items];
        final r = Reaction(d.id, from, (m['name'] ?? '') as String, kind, (j['t'] ?? '') as String, at);
        if (kind == 'unlike') {
          likers.remove(from);
        } else {
          if (kind == 'like') { if (!likers.add(from)) { await d.reference.delete().catchError((_) {}); return; } }
          if (kind == 'view') { if (!viewers.add(from)) { await d.reference.delete().catchError((_) {}); return; } }
          items.add(r);
        }
        await _save(VideoThread(videoId, title, likers, viewers, items));
      }
    }
    await d.reference.delete().catchError((_) {}); // relay only: nothing stays on the server
  }
}
