import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:video_player/video_player.dart';

import 'data.dart';
import 'nudity.dart';

const _maxDocBytes = 900 * 1024; // Firestore documents are limited to 1 MiB
const _maxVoice = Duration(minutes: 2);
const _maxVideo = Duration(seconds: 30);

/// Rules of the chat screen:
/// * Everything is end-to-end encrypted (see crypto.dart).
/// * Texts and photos vanish 5-30 s (user setting) after they are seen; voice and video play once.
///   Hold (long-press) a message or photo to pause its timer; let go to continue.
/// * The sender can see their own photo/video/voice; the receiver sees it only when they tap it.
/// * Groups: sender names are hidden by default; the group admin can switch names on.
/// * Photos and videos: take them with the in-app camera or attach from the gallery. Every one is
///   checked for nudity on the phone before it is sent.
/// * Nothing can be saved or downloaded; screenshots/screen recording are blocked app-wide (FLAG_SECURE).
class ChatScreen extends StatefulWidget {
  final String chatId;
  final AppUser me;
  const ChatScreen({super.key, required this.chatId, required this.me});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  final _scroll = ScrollController();

  final Map<String, Msg> _viewing = {}; // incoming texts on screen
  final Map<String, DateTime> _openedAt = {};
  final Map<String, DateTime> _pausedSince = {}; // held down = timer paused
  final Set<String> _consumed = {};
  final Map<String, Uint8List?> _plain = {}; // decrypted content (null = cannot decrypt)
  final Set<String> _decrypting = {};

  Chat? _chat;
  Timer? _ticker;
  bool _blockedByMe = false, _blockedMe = false;
  int _lastCount = -1;
  double? _sending; // upload progress for videos

  final AudioRecorder _recorder = AudioRecorder();
  bool _recording = false;
  DateTime? _recStart;
  final AudioPlayer _player = AudioPlayer();
  Msg? _playing;
  StreamSubscription<PlayerState>? _playerSub;

  String get me => widget.me.uid;
  List<String> get _members => _chat?.members ?? const [];

  @override
  void initState() {
    super.initState();
    _ticker = Timer.periodic(const Duration(milliseconds: 250), (_) => _tick());
    Repo.markChatSeen(widget.chatId);
    _playerSub = _player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.completed && _playing != null) _finishVoice();
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    Repo.markChatSeen(widget.chatId);
    for (final m in _viewing.values) {
      Repo.markRead(widget.chatId, m, _members);
    }
    if (_playing != null) Repo.markRead(widget.chatId, _playing!, _members);
    _playerSub?.cancel();
    _player.dispose();
    _recorder.dispose();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _tick() {
    if (!mounted) return;
    final now = DateTime.now();
    final done = <String>[];
    _openedAt.forEach((id, t) {
      if (_pausedSince.containsKey(id)) return; // held: paused
      if (now.difference(t).inMilliseconds >= viewSeconds * 1000) done.add(id);
    });
    for (final id in done) {
      final m = _viewing.remove(id);
      _openedAt.remove(id);
      _consumed.add(id);
      _plain.remove(id);
      if (m != null) Repo.markRead(widget.chatId, m, _members);
    }
    if (_viewing.isNotEmpty || _recording || done.isNotEmpty) setState(() {});
    if (_recording && _recStart != null && now.difference(_recStart!) >= _maxVoice) _stopRecording(send: true);
  }

  void _hold(String id) {
    if (_openedAt.containsKey(id) && !_pausedSince.containsKey(id)) setState(() => _pausedSince[id] = DateTime.now());
  }

  void _release(String id) {
    final since = _pausedSince.remove(id);
    final opened = _openedAt[id];
    if (since != null && opened != null) setState(() => _openedAt[id] = opened.add(DateTime.now().difference(since)));
  }

  int _leftMs(String id) {
    final opened = _openedAt[id];
    if (opened == null) return viewSeconds * 1000;
    final ref = _pausedSince[id] ?? DateTime.now();
    return (viewSeconds * 1000 - ref.difference(opened).inMilliseconds).clamp(0, viewSeconds * 1000);
  }

  void _ensureDecrypted(Msg m) {
    if (m.type == 'video' || _plain.containsKey(m.id) || _decrypting.contains(m.id)) return;
    _decrypting.add(m.id);
    Repo.decrypt(m).then((v) {
      _decrypting.remove(m.id);
      _plain[m.id] = v;
      if (mounted) setState(() {});
    });
  }

  Future<void> _checkBlocks(Chat c) async {
    final other = c.otherUid(me);
    if (other == null) return;
    final a = await Repo.isBlocked(me, other);
    final b = await Repo.isBlocked(other, me);
    if (mounted) setState(() { _blockedByMe = a; _blockedMe = b; });
  }

  // ---------------- sending (in-app camera or gallery) ----------------
  Future<void> _sendText() async {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    _text.clear();
    setState(() {});
    await _guard(() => Repo.send(widget.chatId, _members, type: 'text', text: t));
  }

  Future<void> _takePhoto([ImageSource src = ImageSource.camera]) async {
    final x = await ImagePicker().pickImage(source: src, maxWidth: 1280, maxHeight: 1280, imageQuality: 60);
    if (x == null) return;
    final bytes = await x.readAsBytes();
    // Camera shots are temporary files - delete them. Gallery originals are left untouched.
    if (src == ImageSource.camera) await File(x.path).delete().catchError((_) => File(x.path));
    if (bytes.length > _maxDocBytes) {
      _snack(src == ImageSource.camera ? 'Photo too large, please take it again' : 'Photo too large, please pick a smaller one');
      return;
    }
    _snack('Checking photo…');
    if (await NudityCheck.isUnsafe(bytes)) {
      _snack('This photo is not allowed. Nudity or sexual content can\'t be sent.');
      return;
    }
    await _guard(() => Repo.send(widget.chatId, _members, type: 'image', data: bytes));
  }

  Future<void> _recordVideo([ImageSource src = ImageSource.camera]) async {
    final x = await ImagePicker().pickVideo(source: src, maxDuration: _maxVideo);
    if (x == null) return;
    final f = File(x.path);
    int ms = _maxVideo.inMilliseconds;
    try {
      final vc = VideoPlayerController.file(f);
      await vc.initialize();
      ms = vc.value.duration.inMilliseconds;
      await vc.dispose();
    } catch (_) {}
    Future<void> cleanup() async { if (src == ImageSource.camera) await f.delete().catchError((_) => f); }
    if (ms > _maxVideo.inMilliseconds + 1500) {
      await cleanup();
      _snack('Video is too long - pick one up to 30 seconds');
      return;
    }
    if (await f.length() > Repo.maxVideoBytes) {
      await cleanup();
      _snack('Video too large - keep it shorter');
      return;
    }
    _snack('Checking video…');
    if (await videoLooksUnsafe(f.path, ms)) {
      await cleanup();
      _snack('This video is not allowed. Nudity or sexual content can\'t be sent.');
      return;
    }
    final bytes = await f.readAsBytes();
    await cleanup();
    setState(() => _sending = 0);
    await _guard(() => Repo.sendVideo(widget.chatId, _members, bytes, ms, onProgress: (p) { if (mounted) setState(() => _sending = p); }));
    if (mounted) setState(() => _sending = null);
  }

  void _attachSheet() => showModalBottomSheet(
        context: context,
        showDragHandle: true,
        builder: (c) => SafeArea(
          child: Wrap(children: [
            ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('Photo from gallery'), onTap: () { Navigator.pop(c); _takePhoto(ImageSource.gallery); }),
            ListTile(leading: const Icon(Icons.video_library_outlined), title: const Text('Video from gallery (up to 30 s)'), onTap: () { Navigator.pop(c); _recordVideo(ImageSource.gallery); }),
            ListTile(leading: const Icon(Icons.photo_camera_outlined), title: const Text('Take a photo'), onTap: () { Navigator.pop(c); _takePhoto(); }),
            ListTile(leading: const Icon(Icons.videocam_outlined), title: const Text('Record a video (up to 30 s)'), onTap: () { Navigator.pop(c); _recordVideo(); }),
          ]),
        ),
      );

  Future<void> _startRecording() async {
    if (!await _recorder.hasPermission()) {
      _snack('Microphone permission is needed for voice messages');
      return;
    }
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/rec_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 32000, sampleRate: 22050, numChannels: 1), path: path);
    setState(() { _recording = true; _recStart = DateTime.now(); });
  }

  Future<void> _stopRecording({required bool send}) async {
    if (!_recording) return;
    final started = _recStart ?? DateTime.now();
    setState(() { _recording = false; _recStart = null; });
    final path = await _recorder.stop();
    if (path == null) return;
    final f = File(path);
    if (send) {
      final ms = DateTime.now().difference(started).inMilliseconds;
      final bytes = await f.readAsBytes();
      if (ms < 700) {
        _snack('Hold on a bit longer to record');
      } else if (bytes.length > _maxDocBytes) {
        _snack('Voice message is too long');
      } else {
        await _guard(() => Repo.send(widget.chatId, _members, type: 'voice', data: bytes, durationMs: ms));
      }
    }
    if (await f.exists()) await f.delete();
  }

  Future<void> _guard(Future<void> Function() fn) async {
    try {
      await fn();
      _scrollToEnd();
    } catch (e) {
      _snack(_blockedMe ? 'You can\'t message this person' : 'Could not send: $e');
    }
  }

  // ---------------- consuming ----------------
  void _consume(Msg m) {
    _consumed.add(m.id);
    _plain.remove(m.id);
    Repo.markRead(widget.chatId, m, _members);
    if (mounted) setState(() {});
  }

  Future<void> _openPhoto(Msg m) async {
    final mine = m.from == me;
    final bytes = _plain[m.id] ?? await Repo.decrypt(m);
    if (bytes == null) { _snack('This photo was locked to an older security key on this phone. Ask the sender to send it again.'); return; }
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(fullscreenDialog: true, builder: (_) => _TimedPhoto(bytes: bytes, own: mine)));
    if (!mine) _consume(m); // the sender's own copy stays until the receiver has seen it
  }

  Future<void> _openVideo(Msg m) async {
    final mine = m.from == me;
    await Navigator.push(context, MaterialPageRoute(fullscreenDialog: true, builder: (_) => _PlayOnceVideo(chatId: widget.chatId, msg: m, own: mine)));
    if (!mine) _consume(m);
  }

  Future<void> _playVoice(Msg m) async {
    if (_playing != null) return;
    final bytes = _plain[m.id] ?? await Repo.decrypt(m);
    if (bytes == null) { _snack('This voice message could not be decrypted'); return; }
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/v_${m.id}.m4a');
    await f.writeAsBytes(bytes, flush: true);
    setState(() => _playing = m);
    try {
      await _player.setFilePath(f.path);
      await _player.play();
    } catch (_) {
      _finishVoice();
    }
  }

  void _finishVoice() {
    final m = _playing;
    if (m == null) return;
    _playing = null;
    _player.stop();
    if (m.from != me) _consume(m); else if (mounted) setState(() {});
    getTemporaryDirectory().then((d) {
      final f = File('${d.path}/v_${m.id}.m4a');
      if (f.existsSync()) f.deleteSync();
    });
  }

  // ---------------- menu ----------------
  Future<void> _report() async {
    final reason = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Report'),
        content: TextField(controller: reason, maxLines: 3, decoration: const InputDecoration(hintText: 'What happened?', border: OutlineInputBorder())),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Send report'))],
      ),
    );
    if (ok == true) {
      await Repo.report(chatId: widget.chatId, userUid: _chat?.otherUid(me), reason: reason.text.trim());
      _snack('Thanks. Our team will review this report.');
    }
  }

  Future<void> _toggleBlock() async {
    final other = _chat?.otherUid(me);
    if (other == null) return;
    if (_blockedByMe) {
      await Repo.unblock(other);
    } else {
      await Repo.block(other);
    }
    setState(() => _blockedByMe = !_blockedByMe);
  }

  void _showCode() {
    final name = (_chat?.name ?? '').trim();
    showDialog(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Group code'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('The group name is its code. Groups are not listed on the home screen: members open it from New chat → Group by typing the group name (or part of it).'),
          const SizedBox(height: 16),
          Text(name.isEmpty ? '-' : name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))],
      ),
    );
  }

  Future<void> _leave() async {
    await Repo.leaveGroup(widget.chatId);
    if (mounted) Navigator.pop(context);
  }

  void _snack(String s) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    });
  }

  // ---------------- UI ----------------
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Chat?>(
      stream: Repo.watchChat(widget.chatId),
      builder: (context, cs) {
        final chat = cs.data;
        if (chat != null && (_chat == null || _chat!.members.length != chat.members.length)) {
          _chat = chat;
          _checkBlocks(chat);
        }
        _chat = chat ?? _chat;
        final title = _chat?.title(me) ?? '';
        final isGroup = _chat?.isGroup ?? false;
        return Scaffold(
          appBar: AppBar(
            titleSpacing: 0,
            title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(isGroup ? ((_chat?.anon ?? true) ? '🕶 Anonymous group · senders hidden' : '👤 Sender names shown') : '🔒 End-to-end encrypted · vanishes ${viewSeconds} s after seen',
                  style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ]),
            actions: [
              PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'report') _report();
                  if (v == 'block') _toggleBlock();
                  if (v == 'leave') _leave();
                  if (v == 'code') _showCode();
                  if (v == 'anon' || v == 'names') {
                    Repo.setGroupAnon(widget.chatId, v == 'anon').then((_) => _snack(v == 'anon' ? 'Sender names are now hidden' : 'Sender names are now shown'),
                        onError: (_) => _snack('Only the group admin can change this'));
                  }
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(value: 'report', child: Text('Report')),
                  if (!isGroup) PopupMenuItem(value: 'block', child: Text(_blockedByMe ? 'Unblock' : 'Block')),
                  if (isGroup) const PopupMenuItem(value: 'code', child: Text('Group code')),
                  if (isGroup && (_chat?.isAdmin(me) ?? false))
                    PopupMenuItem(value: (_chat?.anon ?? true) ? 'names' : 'anon',
                        child: Text((_chat?.anon ?? true) ? 'Admin: show sender names' : 'Admin: make senders anonymous')),
                  if (isGroup) const PopupMenuItem(value: 'leave', child: Text('Leave group')),
                ],
              ),
            ],
          ),
          body: Column(children: [
            Expanded(child: _messageList()),
            if (_sending != null) LinearProgressIndicator(value: _sending),
            _composer(),
          ]),
        );
      },
    );
  }

  Widget _messageList() {
    return StreamBuilder<List<Msg>>(
      stream: Repo.messages(widget.chatId),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final visible = <Msg>[];
        final seen = <String>{};
        for (final m in snap.data!) {
          seen.add(m.id);
          if (_consumed.contains(m.id)) continue;
          if (m.from == me) { _ensureDecrypted(m); visible.add(m); continue; }
          if (m.readBy.contains(me) && !_viewing.containsKey(m.id)) continue; // already seen earlier
          _ensureDecrypted(m);
          // The 5-second clock for a text starts only once it is actually readable on screen.
          if (m.type == 'text' && !_viewing.containsKey(m.id) && _plain.containsKey(m.id)) {
            _viewing[m.id] = m;
            _openedAt[m.id] = DateTime.now();
          }
          visible.add(m);
        }
        for (final m in _viewing.values) {
          if (!seen.contains(m.id)) visible.add(m);
        }
        visible.sort((a, b) => a.createdAt.compareTo(b.createdAt));
        if (visible.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Text('Nothing here.\nEverything you send is encrypted and disappears once it has been seen.',
                  textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
          );
        }
        if (visible.length != _lastCount) { _lastCount = visible.length; _scrollToEnd(); }
        return ListView.builder(
          controller: _scroll,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
          itemCount: visible.length,
          itemBuilder: (_, i) => _bubble(visible[i]),
        );
      },
    );
  }

  String _mmss(int ms) { final s = (ms / 1000).round(); return '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}'; }

  Widget _bubble(Msg m) {
    final cs = Theme.of(context).colorScheme;
    final mine = m.from == me;
    final isGroup = _chat?.isGroup ?? false;
    final bg = mine ? cs.primaryContainer : cs.surfaceContainerHighest;
    final plain = _plain[m.id];
    final tried = _plain.containsKey(m.id);
    Widget content;
    const bold = TextStyle(fontWeight: FontWeight.w600);

    if (m.type == 'text') {
      content = plain != null
          ? Text(utf8.decode(plain, allowMalformed: true), style: const TextStyle(fontSize: 16))
          : Text(tried ? '🔒 Can\'t open this message: it was locked to an older security key on this phone. Ask the sender to send it again.' : '🔒 Decrypting…', style: TextStyle(color: cs.onSurfaceVariant));
    } else if (m.type == 'image') {
      content = mine && plain != null
          // The sender sees what they sent (small preview, tap for full size).
          ? ClipRRect(borderRadius: BorderRadius.circular(10),
              child: Image.memory(plain, height: 200, width: 200, fit: BoxFit.cover, gaplessPlayback: true))
          : Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.photo_camera, color: cs.primary), const SizedBox(width: 8),
              Text(mine ? 'Photo sent' : 'Photo · tap to view for $viewSeconds s', style: bold)]);
    } else if (m.type == 'video') {
      content = Row(mainAxisSize: MainAxisSize.min, children: [Icon(mine ? Icons.videocam : Icons.play_circle_fill, color: cs.primary, size: 28), const SizedBox(width: 8),
        Text(mine ? 'Your video · ${_mmss(m.durationMs)} · tap to view' : 'Video · ${_mmss(m.durationMs)} · tap to watch once', style: bold)]);
    } else {
      final playing = _playing?.id == m.id;
      content = Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(playing ? Icons.graphic_eq : (mine ? Icons.mic : Icons.play_circle_fill), color: cs.primary, size: 28),
        const SizedBox(width: 8),
        Text(playing ? (mine ? 'Playing your voice note…' : 'Playing… (once only)') : mine ? 'Your voice note · ${_mmss(m.durationMs)} · tap to play' : 'Voice · ${_mmss(m.durationMs)} · tap to play once', style: bold),
      ]);
    }

    final footer = <Widget>[];
    if (!mine && m.type == 'text' && _openedAt[m.id] != null) {
      final total = viewSeconds * 1000;
      final left = _leftMs(m.id);
      final paused = _pausedSince.containsKey(m.id);
      footer.add(paused
          ? Icon(Icons.pause_circle_filled, size: 15, color: cs.primary)
          : SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, value: left / total)));
      footer.add(Text(paused ? ' paused · ${(left / 1000).ceil()}s' : ' ${(left / 1000).ceil()}s · hold to pause',
          style: TextStyle(fontSize: 12, color: paused ? cs.primary : cs.error, fontWeight: FontWeight.w700)));
    }
    if (mine) {
      final recipients = _members.where((u) => u != me).length;
      final read = m.readBy.length;
      footer.add(Text(isGroup && read > 0 ? 'Seen by $read/$recipients · ' : 'Sent · ', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant)));
      footer.add(Icon(read > 0 ? Icons.done_all : Icons.done, size: 14, color: cs.onSurfaceVariant));
    }

    final bubble = Container(
      margin: const EdgeInsets.symmetric(vertical: 3),
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(16), topRight: const Radius.circular(16),
          bottomLeft: Radius.circular(mine ? 16 : 4), bottomRight: Radius.circular(mine ? 4 : 16)),
      ),
      child: Column(crossAxisAlignment: mine ? CrossAxisAlignment.end : CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        if (isGroup && !mine)
          Text((_chat?.anon ?? true) ? 'Anonymous' : (_chat?.names[m.from] ?? ''),
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: (_chat?.anon ?? true) ? cs.onSurfaceVariant : cs.primary)),
        content,
        if (footer.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Row(mainAxisSize: MainAxisSize.min, children: footer)),
      ]),
    );

    VoidCallback? onTap;
    if (m.type == 'image') onTap = () => _openPhoto(m);
    if (m.type == 'voice') onTap = () => _playVoice(m);
    if (m.type == 'video') onTap = () => _openVideo(m);

    final timed = !mine && m.type == 'text' && _openedAt[m.id] != null;
    double opacity = 1;
    if (timed && !_pausedSince.containsKey(m.id)) opacity = (_leftMs(m.id) / 1000).clamp(0.15, 1.0);
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Opacity(
        opacity: opacity,
        child: GestureDetector(
          onTap: onTap,
          // Hold to pause the vanishing timer; let go to continue.
          onLongPressStart: timed ? (_) => _hold(m.id) : null,
          onLongPressEnd: timed ? (_) => _release(m.id) : null,
          onLongPressCancel: timed ? () => _release(m.id) : null,
          child: bubble,
        ),
      ),
    );
  }

  Widget _composer() {
    final cs = Theme.of(context).colorScheme;
    if (_blockedByMe || _blockedMe) {
      return SafeArea(
        child: Container(
          padding: const EdgeInsets.all(16),
          color: cs.surfaceContainerHigh,
          child: Text(_blockedByMe ? 'You blocked this person. Unblock them from the menu to chat.' : 'You can\'t send messages to this person.', textAlign: TextAlign.center),
        ),
      );
    }
    if (_recording) {
      final secs = _recStart == null ? 0 : DateTime.now().difference(_recStart!).inMilliseconds;
      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _stopRecording(send: false)),
            Icon(Icons.fiber_manual_record, color: cs.error),
            const SizedBox(width: 6),
            Expanded(child: Text('Recording… ${_mmss(secs)}', style: const TextStyle(fontWeight: FontWeight.w600))),
            IconButton.filled(icon: const Icon(Icons.send), onPressed: () => _stopRecording(send: true)),
          ]),
        ),
      );
    }
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(6, 4, 6, 6),
        child: Row(children: [
          Expanded(
            child: TextField(
              controller: _text,
              minLines: 1,
              maxLines: 5,
              maxLength: 2000,
              enableInteractiveSelection: true,
              textCapitalization: TextCapitalization.sentences,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Message',
                counterText: '',
                // Attach (gallery) and camera buttons inside the text box, like WhatsApp.
                suffixIcon: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(tooltip: 'Attach photo / video', icon: const Icon(Icons.attach_file), onPressed: _sending != null ? null : _attachSheet),
                  if (_text.text.trim().isEmpty)
                    IconButton(tooltip: 'Camera', icon: const Icon(Icons.photo_camera_outlined), onPressed: _sending != null ? null : () => _takePhoto()),
                ]),
                filled: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
              ),
            ),
          ),
          const SizedBox(width: 6),
          _text.text.trim().isEmpty
              ? IconButton.filled(icon: const Icon(Icons.mic), onPressed: _startRecording)
              : IconButton.filled(icon: const Icon(Icons.send), onPressed: _sendText),
        ]),
      ),
    );
  }
}

/// Photo shown for exactly 5 seconds, then closed for good. No save/share options.
class _TimedPhoto extends StatefulWidget {
  final Uint8List bytes;
  final bool own; // sender viewing their own photo: no timer
  const _TimedPhoto({required this.bytes, this.own = false});
  @override
  State<_TimedPhoto> createState() => _TimedPhotoState();
}

class _TimedPhotoState extends State<_TimedPhoto> {
  DateTime _start = DateTime.now();
  DateTime? _pausedAt;
  Timer? _t;
  bool _closed = false;
  int get _elapsed => (_pausedAt ?? DateTime.now()).difference(_start).inMilliseconds;
  @override
  void initState() {
    super.initState();
    if (widget.own) return;
    _t = Timer.periodic(const Duration(milliseconds: 100), (_) {
      if (!mounted || _closed) return;
      if (_pausedAt != null) return;
      if (_elapsed >= viewSeconds * 1000) {
        _closed = true;
        _t?.cancel();
        Navigator.of(context).maybePop();
      } else {
        setState(() {});
      }
    });
  }

  void _resume() {
    final p = _pausedAt;
    if (p == null) return;
    setState(() { _start = _start.add(DateTime.now().difference(p)); _pausedAt = null; });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.own) {
      return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white, title: const Text('Your photo')),
        body: Center(child: Image.memory(widget.bytes, gaplessPlayback: true)),
      );
    }
    final total = viewSeconds * 1000;
    final left = (total - _elapsed).clamp(0, total);
    final paused = _pausedAt != null;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
        title: Text(paused ? 'Paused · ${(left / 1000).ceil()} s left' : 'Disappears in ${(left / 1000).ceil()} s · hold to pause'),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(4), child: LinearProgressIndicator(value: left / total, color: paused ? Colors.white : Colors.redAccent)),
      ),
      body: GestureDetector(
        onLongPressStart: (_) => setState(() => _pausedAt = DateTime.now()),
        onLongPressEnd: (_) => _resume(),
        onLongPressCancel: _resume,
        child: Container(color: Colors.black, alignment: Alignment.center, child: Image.memory(widget.bytes, gaplessPlayback: true)),
      ),
    );
  }
}

/// Downloads, decrypts and plays a video exactly once (no seeking, pausing or saving),
/// then closes. The decrypted temp file is deleted immediately afterwards.
class _PlayOnceVideo extends StatefulWidget {
  final String chatId;
  final Msg msg;
  final bool own; // sender previewing their own video
  const _PlayOnceVideo({required this.chatId, required this.msg, this.own = false});
  @override
  State<_PlayOnceVideo> createState() => _PlayOnceVideoState();
}

class _PlayOnceVideoState extends State<_PlayOnceVideo> {
  VideoPlayerController? _vc;
  File? _file;
  String? _error;
  bool _closed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final bytes = await Repo.loadVideo(widget.chatId, widget.msg);
    if (bytes == null) { if (mounted) setState(() => _error = 'This video could not be decrypted'); return; }
    final dir = await getTemporaryDirectory();
    _file = File('${dir.path}/pv_${widget.msg.id}.mp4');
    await _file!.writeAsBytes(bytes, flush: true);
    final vc = VideoPlayerController.file(_file!);
    await vc.initialize();
    vc.addListener(() {
      final v = vc.value;
      if (!_closed && v.isInitialized && v.duration > Duration.zero && v.position >= v.duration) _close();
    });
    if (!mounted) { await vc.dispose(); return; }
    setState(() => _vc = vc);
    await vc.play();
  }

  void _close() {
    if (_closed) return;
    _closed = true;
    if (mounted) Navigator.of(context).maybePop();
  }

  @override
  void dispose() {
    _vc?.dispose();
    final f = _file;
    if (f != null && f.existsSync()) f.deleteSync();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final vc = _vc;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white,
          title: Text(widget.own ? 'Your video' : 'Plays once · hold to pause')),
      body: GestureDetector(
        onLongPressStart: (_) => vc?.pause(),
        onLongPressEnd: (_) => vc?.play(),
        onLongPressCancel: () => vc?.play(),
        child: Container(
          color: Colors.black,
          alignment: Alignment.center,
          child: _error != null
              ? Text(_error!, style: const TextStyle(color: Colors.white))
              : vc == null
                  ? const CircularProgressIndicator()
                  : AspectRatio(aspectRatio: vc.value.aspectRatio, child: VideoPlayer(vc)),
        ),
      ),
    );
  }
}
