// Offline mode: text chat with a nearby 5 Sec Text user over Bluetooth /
// Wi-Fi Direct (Google Nearby Connections) when there is no internet.
// * Text only - no photos, voice or video.
// * Phone-to-phone: no server, nothing stored. The link is encrypted by Nearby
//   Connections; both people see the same 4-character code to confirm who they
//   are talking to before accepting.
// * Same vanish rule: every message disappears (5-30 s, user setting) after it is seen.
// * Reliability: once connected we stop scanning/advertising (scanning keeps the radio
//   busy and drops messages), every message gets a delivery receipt, and failed
//   messages can be re-sent with one tap.
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:permission_handler/permission_handler.dart';

import 'data.dart';

const _serviceId = 'com.fivesectext.app.offline';

enum _St { sending, delivered, failed, received }

class _OMsg {
  final String id, text;
  final bool mine;
  _St st;
  DateTime? shownAt; // vanish clock starts when delivered (mine) or received (theirs)
  _OMsg(this.id, this.text, this.mine, this.st) { if (st == _St.received) shownAt = DateTime.now(); }
}

class OfflineScreen extends StatefulWidget {
  final AppUser me;
  const OfflineScreen({super.key, required this.me});
  @override
  State<OfflineScreen> createState() => _OfflineScreenState();
}

class _OfflineScreenState extends State<OfflineScreen> {
  final _nearby = Nearby();
  final Map<String, String> _found = {}; // endpointId -> display name
  final List<_OMsg> _msgs = [];
  final _text = TextEditingController();
  String? _peerId, _peerName, _code;
  String _status = 'Starting…';
  bool _needPerms = false, _searching = false;
  int _sdk = 0; // Android version (API level)
  String _diag = ''; // details shown under "Troubleshoot"
  String? _requesting; // endpoint we asked to connect to (avoid double requests)
  Timer? _tick;
  final String _session = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
  int _n = 0;
  final Set<String> _seenIds = {};

  String get _myName => '${widget.me.name} (@${widget.me.username})';

  @override
  void initState() {
    super.initState();
    _start();
    _tick = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (!mounted || _msgs.isEmpty) return;
      setState(() => _msgs.removeWhere((m) => m.shownAt != null && DateTime.now().difference(m.shownAt!).inMilliseconds >= viewSeconds * 1000));
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    _nearby.stopAdvertising();
    _nearby.stopDiscovery();
    _nearby.stopAllEndpoints();
    _text.dispose();
    super.dispose();
  }

  /// Only the permissions this Android version really uses are required.
  List<Permission> _needed() => [
        if (_sdk >= 31) ...[Permission.bluetoothScan, Permission.bluetoothAdvertise, Permission.bluetoothConnect],
        if (_sdk <= 32) Permission.locationWhenInUse, // Android 12 and older need location to find devices
        if (_sdk >= 33) Permission.nearbyWifiDevices,
      ];

  Future<void> _start() async {
    try { _sdk = await const MethodChannel('fivesec/device').invokeMethod<int>('sdkInt') ?? 0; } catch (_) {}
    if (_sdk == 0) _sdk = 33; // unknown: ask for the modern set
    final needed = _needed();
    final res = await [...needed, if (_sdk >= 33) Permission.locationWhenInUse].request(); // location optional on 13+
    final missing = needed.where((p) => !(res[p]?.isGranted ?? false) && !(res[p]?.isLimited ?? false)).toList();
    _diag = 'Android API $_sdk · ${res.entries.map((e) => '${e.key.toString().split('.').last}: ${e.value.name}').join(', ')}';
    if (missing.isNotEmpty) {
      final names = missing.map((p) => p == Permission.locationWhenInUse ? 'Location' : p == Permission.nearbyWifiDevices ? 'Nearby Wi-Fi devices' : 'Nearby devices').toSet().join(' and ');
      setState(() { _needPerms = true; _status = 'Allow "$names" for 5 Sec Text so phones can find each other. Tap "Open settings" if the question no longer appears.'; });
      return;
    }
    _needPerms = false;
    try {
      if (await Permission.bluetooth.serviceStatus.isDisabled) {
        setState(() => _status = 'Bluetooth is OFF. Turn it on in quick settings, then tap Retry.');
        return;
      }
    } catch (_) {}
    if (_sdk <= 32 && await Permission.locationWhenInUse.serviceStatus.isDisabled) {
      setState(() => _status = 'Location (GPS) is OFF. Android ${_sdk <= 30 ? '11' : '12'} and older need it on to find nearby phones. Turn it on, then tap Retry.');
      return;
    }
    await _search();
  }

  bool _already(Object e) => e.toString().toUpperCase().contains('ALREADY');

  Future<void> _search() async {
    // Always reset first: a previous session may still be advertising/scanning.
    try { await _nearby.stopDiscovery(); } catch (_) {}
    try { await _nearby.stopAdvertising(); } catch (_) {}
    String? err;
    try {
      await _nearby.startAdvertising(_myName, Strategy.P2P_CLUSTER,
          onConnectionInitiated: _onInit, onConnectionResult: _onResult, onDisconnected: _onDisconnected, serviceId: _serviceId);
    } catch (e) { if (!_already(e)) err = 'advertising: $e'; }
    try {
      await _nearby.startDiscovery(_myName, Strategy.P2P_CLUSTER,
          onEndpointFound: (id, name, serviceId) { if (mounted) setState(() => _found[id] = name); },
          onEndpointLost: (id) { if (mounted && id != null) setState(() => _found.remove(id)); },
          serviceId: _serviceId);
    } catch (e) { if (!_already(e)) err = '${err == null ? '' : '$err; '}discovery: $e'; }
    _searching = err == null;
    if (!mounted) return;
    setState(() {
      if (err != null) {
        _diag = '$_diag\nStart error: $err';
        _status = 'Bluetooth could not start. Check Bluetooth${_sdk <= 32 ? ' and Location' : ''} are ON, then tap Retry.';
      } else {
        _status = 'Looking for nearby 5 Sec Text users… Keep this screen open on both phones.';
      }
    });
  }

  Future<void> _stopSearch() async {
    if (!_searching) return;
    _searching = false;
    try { await _nearby.stopDiscovery(); } catch (_) {}
    try { await _nearby.stopAdvertising(); } catch (_) {}
  }

  Future<void> _connect(String id) async {
    if (_requesting != null) return; // one request at a time
    _requesting = id;
    setState(() => _status = 'Asking ${_found[id]} to chat… They will see a code to accept. (Only ONE of you needs to tap "Chat".)');
    try {
      await _nearby.requestConnection(_myName, id, onConnectionInitiated: _onInit, onConnectionResult: _onResult, onDisconnected: _onDisconnected);
    } catch (e) {
      _requesting = null;
      if (_already(e)) return; // the other phone already asked us - the accept dialog will show
      if (mounted) setState(() { _status = 'Could not reach ${_found[id]}. Move closer (within ~10 m) and try again.'; _diag = '$_diag\nConnect error: $e'; });
    }
    // Clear the lock if nothing happens within 30 s.
    Timer(const Duration(seconds: 30), () { if (_requesting == id && _peerId == null) { _requesting = null; if (mounted) setState(() => _status = 'No answer from ${_found[id] ?? 'the other phone'}. Try again.'); } });
  }

  Future<void> _onInit(String id, ConnectionInfo info) async {
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        title: const Text('Bluetooth chat'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(info.isIncomingConnection ? '${info.endpointName} wants to chat with you.' : 'Connecting to ${info.endpointName}.'),
          const SizedBox(height: 12),
          const Text('Check that both phones show the same code:'),
          const SizedBox(height: 8),
          Text(info.authenticationToken, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800, letterSpacing: 6)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Reject')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Accept')),
        ],
      ),
    );
    if (ok == true) {
      _peerName = info.endpointName;
      _code = info.authenticationToken;
      await _nearby.acceptConnection(id, onPayLoadRecieved: _onPayload);
    } else {
      await _nearby.rejectConnection(id);
    }
  }

  void _onPayload(String endpointId, Payload payload) {
    if (payload.type != PayloadType.BYTES || payload.bytes == null) return; // text only
    Map j;
    try { j = jsonDecode(utf8.decode(payload.bytes!)) as Map; } catch (_) { return; }
    final kind = j['k'] ?? 'm';
    if (kind == 'a') { // delivery receipt for one of my messages
      final m = _msgs.where((m) => m.id == j['id']).firstOrNull;
      if (m != null && mounted) setState(() { m.st = _St.delivered; m.shownAt ??= DateTime.now(); });
      return;
    }
    final mid = (j['id'] ?? 'x${_n++}') as String;
    final t = (j['t'] ?? '') as String;
    _raw(endpointId, {'k': 'a', 'id': mid}); // tell the sender it arrived
    if (t.isEmpty || !_seenIds.add(mid)) return; // ignore duplicates from a re-send
    if (mounted) setState(() => _msgs.add(_OMsg(mid, t, false, _St.received)));
  }

  Future<int?> _raw(String to, Map<String, dynamic> j) async {
    try {
      await _nearby.sendBytesPayload(to, Uint8List.fromList(utf8.encode(jsonEncode(j))));
      return 0;
    } catch (_) {
      return null;
    }
  }

  void _onResult(String id, Status status) {
    _requesting = null;
    if (!mounted) return;
    if (status == Status.CONNECTED) {
      _stopSearch(); // scanning while connected makes messages fail on many phones
      setState(() { _peerId = id; _status = 'Connected'; });
    } else {
      setState(() => _status = status == Status.REJECTED ? 'Request was declined.' : 'Could not connect. Move closer and try again.');
    }
  }

  void _onDisconnected(String id) {
    if (!mounted) return;
    setState(() {
      _peerId = null; _peerName = null; _code = null; _found.clear();
      for (final m in _msgs) { if (m.st == _St.sending) m.st = _St.failed; }
      _status = 'Disconnected. Looking for nearby users…';
    });
    _search();
  }

  Future<void> _send() async {
    final t = _text.text.trim();
    if (t.isEmpty || _peerId == null) return;
    _text.clear();
    final m = _OMsg('$_session-${_n++}', t, true, _St.sending);
    setState(() => _msgs.add(m));
    await _deliver(m);
  }

  Future<void> _deliver(_OMsg m) async {
    if (_peerId == null) { setState(() => m.st = _St.failed); return; }
    setState(() => m.st = _St.sending);
    final ok = await _raw(_peerId!, {'k': 'm', 'id': m.id, 't': m.text});
    if (!mounted) return;
    if (ok == null) { setState(() => m.st = _St.failed); return; }
    // No receipt within 8 s -> show as failed so it can be re-sent.
    Timer(const Duration(seconds: 8), () { if (mounted && m.st == _St.sending) setState(() => m.st = _St.failed); });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final connected = _peerId != null;
    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(connected ? (_peerName ?? 'Bluetooth chat') : 'Offline · Bluetooth', style: const TextStyle(fontWeight: FontWeight.w700)),
          Text(connected ? 'No internet needed · code $_code · text only' : 'Chat with someone nearby, no internet', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        ]),
        actions: [if (connected) IconButton(tooltip: 'Disconnect', icon: const Icon(Icons.link_off), onPressed: () { _nearby.disconnectFromEndpoint(_peerId!); _onDisconnected(_peerId!); })],
      ),
      body: connected ? _chat(cs) : _list(cs),
    );
  }

  Widget _list(ColorScheme cs) => ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          if (!_needPerms) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) else Icon(Icons.warning_amber, color: cs.error),
          const SizedBox(width: 12), Expanded(child: Text(_status))]),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          OutlinedButton.icon(icon: const Icon(Icons.refresh), label: const Text('Retry'), onPressed: _start),
          if (_needPerms) FilledButton.icon(icon: const Icon(Icons.settings), label: const Text('Open settings'), onPressed: openAppSettings),
        ]),
        const SizedBox(height: 8),
        Text('Tips: both people open this screen · Bluetooth ON · Location ON (Android 12 and older) · stay within ~10 m · only one person taps "Chat".', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
        if (_diag.isNotEmpty)
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: const Text('Troubleshoot', style: TextStyle(fontSize: 13)),
            children: [SelectableText(_diag, style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant))],
          ),
        const SizedBox(height: 16),
        if (_found.isEmpty) Text('No one found yet. The other person must also open "Offline · Bluetooth" in 5 Sec Text.', style: TextStyle(color: cs.onSurfaceVariant)),
        for (final e in _found.entries)
          Card(child: ListTile(leading: const Icon(Icons.bluetooth), title: Text(e.value), trailing: FilledButton(onPressed: () => _connect(e.key), child: const Text('Chat')))),
      ]);

  Widget _chat(ColorScheme cs) => Column(children: [
        Expanded(
          child: _msgs.isEmpty
              ? Center(child: Text('Say hello 👋\nMessages disappear $viewSeconds s after they are seen.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)))
              : ListView(padding: const EdgeInsets.all(10), children: [
                  for (final m in _msgs)
                    Builder(builder: (_) {
                      final left = m.shownAt == null ? viewSeconds * 1000 : (viewSeconds * 1000 - DateTime.now().difference(m.shownAt!).inMilliseconds).clamp(0, viewSeconds * 1000);
                      return Align(
                        alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Opacity(
                          opacity: (left / 1000).clamp(0.15, 1.0),
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 3),
                            padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
                            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                            decoration: BoxDecoration(color: m.mine ? cs.primaryContainer : cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(16)),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
                              Text(m.text, style: const TextStyle(fontSize: 16)),
                              if (m.st == _St.sending) Text('sending…', style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant))
                              else if (m.st == _St.failed) GestureDetector(onTap: () => _deliver(m),
                                  child: Text('not delivered · tap to retry', style: TextStyle(fontSize: 11, color: cs.error, fontWeight: FontWeight.w700)))
                              else Text('${m.mine ? '✓ delivered · ' : ''}${(left / 1000).ceil()}s', style: TextStyle(fontSize: 11, color: cs.error, fontWeight: FontWeight.w700)),
                            ]),
                          ),
                        ),
                      );
                    }),
                ]),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            child: Row(children: [
              Expanded(child: TextField(controller: _text, maxLength: 1000, minLines: 1, maxLines: 4, onSubmitted: (_) => _send(),
                  decoration: InputDecoration(hintText: 'Text message (Bluetooth)', counterText: '', filled: true,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)))),
              const SizedBox(width: 6),
              IconButton.filled(icon: const Icon(Icons.send), onPressed: _send),
            ]),
          ),
        ),
      ]);
}
