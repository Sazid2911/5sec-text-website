import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'audit.dart';
import 'crypto.dart';

final FirebaseFirestore db = FirebaseFirestore.instance;
final FirebaseAuth auth = FirebaseAuth.instance;
String get myUid => auth.currentUser!.uid;

/// Unread messages are removed by a Firestore TTL policy on `expireAt`.
const unreadLifetime = Duration(days: 7);

/// How long a text or photo stays on screen after it is opened. 5 s by default;
/// each user can choose 5-30 s in Settings (applies to messages they read).
int viewSeconds = 5;
int viewSecondsFor(String text) => viewSeconds;

class ViewTime {
  static const min = 5, max = 30, fallback = 5;
  static const _store = FlutterSecureStorage();

  static Future<void> load() async {
    try {
      final v = int.tryParse(await _store.read(key: 'view_seconds') ?? '');
      viewSeconds = (v == null || v < min || v > max) ? fallback : v;
    } catch (_) {
      viewSeconds = fallback;
    }
  }

  static Future<void> set(int seconds) async {
    viewSeconds = seconds.clamp(min, max);
    await _store.write(key: 'view_seconds', value: '$viewSeconds');
  }
}

class AppUser {
  final String uid, name, username;
  /// Confirmed at sign-up: 18 years or older.
  final bool adult;
  /// Version of the Terms of Use last accepted, and when (users are reminded every 3 months).
  final int termsVer;
  final DateTime? termsAt;
  AppUser(this.uid, this.name, this.username, {this.adult = false, this.termsVer = 0, this.termsAt});
  factory AppUser.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    final t = m['termsAt'];
    return AppUser(d.id, (m['name'] ?? '') as String, (m['username'] ?? '') as String,
        adult: m['adult'] == true, termsVer: (m['termsVer'] as num?)?.toInt() ?? 0, termsAt: t is Timestamp ? t.toDate() : null);
  }
}

class Chat {
  final String id;
  final List<String> members;
  final bool isGroup;
  final String name;
  final Map<String, String> names;
  final DateTime updatedAt;
  final String lastFrom;
  final String lastType;
  final Map<String, DateTime> seenAt;
  final String code;
  /// Groups: sender names hidden (true, the default) or shown. Only the group admin (creator) can change it.
  bool anon = true;
  String createdBy = '';
  bool isAdmin(String uid) => createdBy.isNotEmpty && createdBy == uid;
  Chat(this.id, this.members, this.isGroup, this.name, this.names, this.updatedAt, this.lastFrom, this.lastType, this.seenAt, this.code);

  /// True when someone else sent something after I last opened this chat.
  bool hasNewFor(String me) {
    if (lastFrom.isEmpty || lastFrom == me) return false;
    final seen = seenAt[me];
    return seen == null || updatedAt.isAfter(seen);
  }

  factory Chat.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    final ts = m['updatedAt'];
    return Chat(
      d.id,
      List<String>.from(m['members'] ?? const []),
      (m['isGroup'] ?? false) as bool,
      (m['name'] ?? '') as String,
      Map<String, String>.from(m['names'] ?? const {}),
      ts is Timestamp ? ts.toDate() : DateTime.now(),
      (m['lastFrom'] ?? '') as String,
      (m['lastType'] ?? '') as String,
      {
        for (final e in Map<String, dynamic>.from(m['seenAt'] ?? const {}).entries)
          if (e.value is Timestamp) e.key: (e.value as Timestamp).toDate()
      },
      (m['code'] ?? '') as String,
    )
      ..anon = m['anon'] != false
      ..createdBy = (m['createdBy'] ?? '') as String;
  }

  String title(String me) {
    if (isGroup) return name.isEmpty ? 'Group' : name;
    final other = members.firstWhere((u) => u != me, orElse: () => me);
    return names[other] ?? 'Chat';
  }

  String? otherUid(String me) => isGroup ? null : members.firstWhere((u) => u != me, orElse: () => me);
}

class Msg {
  final String id, from, type, text;
  final Uint8List? data;
  final int durationMs;
  final DateTime createdAt;
  final List<String> readBy;
  final int chunks; // videos are stored in pieces under messages/{id}/chunks/{n}
  final Map<String, String> wk; // per-member wrapped AES keys (end-to-end encryption)
  String spk = ''; // sender's public key used to seal this message
  Msg(this.id, this.from, this.type, this.text, this.data, this.durationMs, this.createdAt, this.readBy, [this.chunks = 0, this.wk = const {}]);

  factory Msg.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    final ts = m['createdAt'];
    final blob = m['data'];
    return Msg(
      d.id,
      (m['from'] ?? '') as String,
      (m['type'] ?? 'text') as String,
      (m['text'] ?? '') as String,
      blob is Blob ? blob.bytes : null,
      (m['durationMs'] ?? 0) as int,
      ts is Timestamp ? ts.toDate() : DateTime.now(),
      List<String>.from(m['readBy'] ?? const []),
      (m['chunks'] ?? 0) as int,
      Map<String, String>.from(m['wk'] ?? const {}),
    )..spk = (m['spk'] ?? '') as String;
  }
}

class Repo {
  static final _users = db.collection('users');
  static final _usernames = db.collection('usernames');
  static final _chats = db.collection('chats');
  static final _blocks = db.collection('blocks');

  // ---------------- profile ----------------
  static final usernamePattern = RegExp(r'^[a-z0-9_.]{3,20}$');

  /// [termsVersion] = the Terms of Use version the user accepted. Only people who
  /// confirmed they are 18+ can create a profile (also enforced by firestore.rules).
  static Future<void> createProfile(String name, String username, {required bool adult, required int termsVersion}) async {
    if (!adult) throw '5 Sec Text is only for people aged 18 and over.';
    final uid = myUid;
    final u = username.trim().toLowerCase();
    if (!usernamePattern.hasMatch(u)) {
      throw 'Username must be 3-20 characters: letters, numbers, _ or .';
    }
    await db.runTransaction((tx) async {
      final taken = await tx.get(_usernames.doc(u));
      if (taken.exists) throw 'That username is already taken';
      tx.set(_usernames.doc(u), {'uid': uid});
      tx.set(_users.doc(uid), {'name': name.trim(), 'username': u, 'createdAt': FieldValue.serverTimestamp(),
        'adult': true, 'termsVer': termsVersion, 'termsAt': FieldValue.serverTimestamp()});
    });
    await Audit.log('account_created', ref: uid, info: '@$u');
    await Audit.log('terms_accepted', info: 'v$termsVersion · confirmed 18+ · data consent given');
  }

  /// Re-accept updated Terms, or acknowledge the 3-monthly rules reminder.
  static Future<void> acceptTerms(int termsVersion) async {
    await _users.doc(myUid).update({'adult': true, 'termsVer': termsVersion, 'termsAt': FieldValue.serverTimestamp()});
    await Audit.log('terms_accepted', info: 'v$termsVersion · confirmed 18+');
  }

  static Stream<AppUser?> watchUser(String uid) =>
      _users.doc(uid).snapshots().map((d) => d.exists ? AppUser.fromDoc(d) : null);

  static Future<AppUser?> findByUsername(String username) async {
    final u = username.trim().toLowerCase().replaceAll('@', '');
    if (u.isEmpty) return null;
    final ref = await _usernames.doc(u).get();
    if (!ref.exists) return null;
    final uid = ref.data()!['uid'] as String;
    final d = await _users.doc(uid).get();
    return d.exists ? AppUser.fromDoc(d) : null;
  }

  // ---------------- chats ----------------
  static Stream<List<Chat>> myChats() => _chats.where('members', arrayContains: myUid).snapshots().map((s) {
        final list = s.docs.map(Chat.fromDoc).toList();
        list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
        return list;
      });

  static Stream<Chat?> watchChat(String id) =>
      _chats.doc(id).snapshots().map((d) => d.exists ? Chat.fromDoc(d) : null);

  static Future<String> openDirectChat(AppUser me, AppUser other) async {
    final ids = [me.uid, other.uid]..sort();
    final id = ids.join('_');
    final ref = _chats.doc(id);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'members': ids,
        'isGroup': false,
        'name': '',
        'names': {me.uid: me.name, other.uid: other.name},
        'createdBy': me.uid,
        'updatedAt': FieldValue.serverTimestamp(),
        'lastFrom': '',
        'lastType': '',
      });
    }
    return id;
  }

  static String _newCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = DateTime.now().microsecondsSinceEpoch;
    return List.generate(6, (i) => chars[(r ~/ (i * 7 + 3) + i * 13) % chars.length]).join();
  }

  static Future<void> markChatSeen(String chatId) =>
      _chats.doc(chatId).update({'seenAt.$myUid': FieldValue.serverTimestamp()}).catchError((_) {});

  /// Group admin only: show or hide who sent each message.
  static Future<void> setGroupAnon(String chatId, bool anon) => _chats.doc(chatId).update({'anon': anon});

  /// Live search for people on 5 Sec Text: username prefix + name prefix (any word order handled by the caller).
  static Future<List<AppUser>> searchUsers(String q, {int limit = 8}) async {
    final t = q.trim().replaceAll('@', '');
    if (t.length < 2) return const [];
    final found = <String, AppUser>{};
    final lower = t.toLowerCase();
    try {
      final u = await _usernames.orderBy(FieldPath.documentId).startAt([lower]).endAt(['$lower\uf8ff']).limit(limit).get();
      final users = await Future.wait(u.docs.map((d) => _users.doc(d.data()['uid'] as String).get()));
      for (final d in users) { if (d.exists) found[d.id] = AppUser.fromDoc(d); }
    } catch (_) {}
    String title(String s) => s.split(' ').map((w) => w.isEmpty ? w : w[0].toUpperCase() + w.substring(1).toLowerCase()).join(' ');
    for (final v in {t, title(t), lower, t.toUpperCase()}) {
      try {
        final s = await _users.where('name', isGreaterThanOrEqualTo: v).where('name', isLessThan: '$v\uf8ff').limit(limit).get();
        for (final d in s.docs) { found[d.id] = AppUser.fromDoc(d); }
      } catch (_) {}
    }
    found.remove(myUid);
    return found.values.toList();
  }

  static Future<String> createGroup(AppUser me, String name, List<AppUser> others) async {
    final all = [me, ...others];
    final ref = _chats.doc();
    await ref.set({
      'code': name.trim(), // the group name is its code (members find the group by typing its name)
      'members': all.map((u) => u.uid).toList(),
      'isGroup': true,
      'name': name.trim(),
      'names': {for (final u in all) u.uid: u.name},
      'createdBy': me.uid,
      'anon': true,
      'updatedAt': FieldValue.serverTimestamp(),
      'lastFrom': '',
      'lastType': '',
    });
    return ref.id;
  }

  static Future<void> leaveGroup(String chatId) =>
      _chats.doc(chatId).update({'members': FieldValue.arrayRemove([myUid])});

  // ---------------- messages ----------------
  static Stream<List<Msg>> messages(String chatId) => _chats
      .doc(chatId)
      .collection('messages')
      .orderBy('createdAt')
      .snapshots()
      .map((s) => s.docs.map(Msg.fromDoc).toList());

  /// Sends an end-to-end encrypted message. For text, [data] is empty and
  /// [text] is encrypted; for photos/voice, [data] holds the media bytes.
  static Future<void> send(String chatId, List<String> members, {required String type, String text = '', Uint8List? data, int durationMs = 0}) async {
    final plain = type == 'text' ? Uint8List.fromList(utf8.encode(text)) : data!;
    final (cipher, wk) = await E2E.seal(plain, members);
    final now = DateTime.now();
    final batch = db.batch();
    final msgRef = _chats.doc(chatId).collection('messages').doc();
    batch.set(msgRef, {
      'from': myUid,
      'type': type,
      'text': '',
      'data': Blob(cipher),
      'wk': wk,
      'spk': await E2E.myPub(),
      'e': 1,
      'durationMs': durationMs,
      'createdAt': FieldValue.serverTimestamp(),
      'readBy': <String>[],
      'expireAt': Timestamp.fromDate(now.add(unreadLifetime)),
    });
    batch.update(_chats.doc(chatId), {'updatedAt': FieldValue.serverTimestamp(), 'lastFrom': myUid, 'lastType': type});
    await batch.commit();
  }

  /// Decrypts a message's content. Returns null if it can't be opened.
  static Future<Uint8List?> decrypt(Msg m) async {
    if (m.data == null) return null;
    return E2E.open(m.data!, m.wk, m.from, senderPub: m.spk);
  }

  static const _chunkBytes = 900 * 1024;
  static const maxVideoBytes = 25 * 1024 * 1024;

  /// Videos are too big for one Firestore document, so they are split into
  /// ~900 KB chunks. The message itself is written last, once all chunks exist.
  static Future<void> sendVideo(String chatId, List<String> members, Uint8List plainBytes, int durationMs, {void Function(double)? onProgress}) async {
    final (bytes, wk) = await E2E.seal(plainBytes, members);
    final msgRef = _chats.doc(chatId).collection('messages').doc();
    final n = (bytes.length / _chunkBytes).ceil();
    final exp = Timestamp.fromDate(DateTime.now().add(unreadLifetime));
    for (var i = 0; i < n; i++) {
      final part = bytes.sublist(i * _chunkBytes, math.min((i + 1) * _chunkBytes, bytes.length));
      await msgRef.collection('chunks').doc('$i').set({'d': Blob(part), 'expireAt': exp});
      onProgress?.call((i + 1) / (n + 1));
    }
    final batch = db.batch();
    batch.set(msgRef, {
      'from': myUid,
      'type': 'video',
      'text': '',
      'wk': wk,
      'spk': await E2E.myPub(),
      'e': 1,
      'durationMs': durationMs,
      'chunks': n,
      'createdAt': FieldValue.serverTimestamp(),
      'readBy': <String>[],
      'expireAt': exp,
    });
    batch.update(_chats.doc(chatId), {'updatedAt': FieldValue.serverTimestamp(), 'lastFrom': myUid, 'lastType': 'video'});
    await batch.commit();
    onProgress?.call(1);
  }

  /// Downloads all chunks and decrypts the video. Null if it can't be opened.
  static Future<Uint8List?> loadVideo(String chatId, Msg m) async {
    final col = _chats.doc(chatId).collection('messages').doc(m.id).collection('chunks');
    final out = BytesBuilder(copy: false);
    for (var i = 0; i < m.chunks; i++) {
      final d = await col.doc('$i').get();
      final b = d.data()?['d'];
      if (b is Blob) out.add(b.bytes);
    }
    return E2E.open(out.toBytes(), m.wk, m.from, senderPub: m.spk);
  }

  static Future<void> _deleteChunks(String chatId, String msgId, int n) async {
    final col = _chats.doc(chatId).collection('messages').doc(msgId).collection('chunks');
    for (var i = 0; i < n; i++) {
      await col.doc('$i').delete().catchError((_) {});
    }
  }

  /// Marks a message as read by me. When every recipient has read it, the
  /// message is deleted from the server for everyone.
  static Future<void> markRead(String chatId, Msg m, List<String> members) async {
    final ref = _chats.doc(chatId).collection('messages').doc(m.id);
    var deleted = false;
    try {
      await db.runTransaction((tx) async {
        final snap = await tx.get(ref);
        if (!snap.exists) return;
        final readBy = Set<String>.from(snap.data()!['readBy'] ?? const [])..add(myUid);
        final from = snap.data()!['from'] as String;
        final recipients = members.where((u) => u != from).toSet();
        if (readBy.containsAll(recipients)) {
          tx.delete(ref);
          deleted = true;
        } else {
          tx.update(ref, {'readBy': FieldValue.arrayUnion([myUid])});
        }
      });
    } catch (_) {
      // Message already gone or offline - nothing else to do.
    }
    if (deleted && m.chunks > 0) await _deleteChunks(chatId, m.id, m.chunks);
  }

  // ---------------- safety ----------------
  static Future<bool> isBlocked(String blocker, String blocked) async =>
      (await _blocks.doc('${blocker}_$blocked').get()).exists;

  static Future<void> block(String uid) =>
      _blocks.doc('${myUid}_$uid').set({'blocker': myUid, 'blocked': uid, 'at': FieldValue.serverTimestamp()});

  static Future<void> unblock(String uid) => _blocks.doc('${myUid}_$uid').delete();

  static Stream<List<String>> myBlocked() => _blocks
      .where('blocker', isEqualTo: myUid)
      .snapshots()
      .map((s) => s.docs.map((d) => d.data()['blocked'] as String).toList());

  static Future<void> report({required String chatId, String? userUid, required String reason}) =>
      db.collection('reports').add({
        'reporter': myUid,
        'reportedUser': userUid ?? '',
        'chatId': chatId,
        'reason': reason,
        'createdAt': FieldValue.serverTimestamp(),
      });

  static Future<void> deleteAccount(AppUser me) async {
    // The 1-year activity log (no message content) is kept after deletion, as Indian law requires.
    await Audit.log('account_deleted', ref: me.uid, info: '@${me.username}');
    await _usernames.doc(me.username).delete();
    await _users.doc(me.uid).delete();
    await auth.currentUser!.delete();
  }
}

/// Search helper: every word typed must match the start of a word in [text] (any order),
/// or appear inside it. "saj she" matches "Sheikh Sajid"; "jid" matches "Sajid".
bool matchesWords(String text, String query) {
  final t = text.toLowerCase();
  final words = t.split(RegExp(r'[\s@._\-]+')).where((w) => w.isNotEmpty).toList();
  final q = query.toLowerCase().replaceAll('@', '').split(RegExp(r'\s+')).where((w) => w.isNotEmpty);
  if (q.isEmpty) return true;
  return q.every((p) => words.any((w) => w.startsWith(p)) || t.contains(p));
}
