// India compliance screens (IT Rules 2021 as amended in 2026, DPDP Act 2023):
//   * 18+ confirmation and Terms acceptance, with a rules reminder every 3 months
//   * Help & Grievance Officer screen with an in-app complaint form + acknowledgement
//   * Ban screen and staff notices (takedowns are done by Trust & Safety staff in
//     docs/safety/index.html - only for complaints and legal orders; vendors and
//     uploaders still manage their own posts)
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import 'audit.dart';
import 'data.dart';
import 'deals.dart';
import 'main.dart';
import 'videos.dart';

/// Users are reminded of the rules at least once every 3 months (IT Rules, 2026 amendment).
const rulesReminderEvery = Duration(days: 90);

bool needsConsent(AppUser me) =>
    !me.adult || me.termsVer < termsVersion || me.termsAt == null || DateTime.now().difference(me.termsAt!) > rulesReminderEvery;

void _open(String url) => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

// ---------------------------------------------------------------- data notice (DPDP Act 2023, s.5)

/// Itemised notice of what personal data is collected and why, shown before consent.
class DataNotice extends StatelessWidget {
  const DataNotice({super.key});

  static const items = [
    ('Email address', 'To sign you in (your password is handled by Google Firebase; we never see it) and to contact you about your account or complaints.'),
    ('Name and username', 'So friends can find you and know who they are talking to.'),
    ('18+ confirmation and Terms acceptance (with date)', 'Because the app is for adults only and the law requires a record.'),
    ('Encrypted messages, photos, voice and videos', 'Only to deliver them. We cannot read them; they are deleted as soon as they are read (unread: after 7 days).'),
    ('Encryption public key', 'So others can send you encrypted messages.'),
    ('Mobile number (optional, stored only as a scrambled code)', 'So people who have your number saved can find you. Remove it any time in Settings.'),
    ('Your phone contacts (only if you allow it)', 'Read on your phone to show which contacts use 5 Sec Text. Your contact list is never uploaded or stored; only scrambled codes of numbers are checked.'),
    ('Video and deal details you post (titles, shop, discount, picture)', 'To show them to other users until they end (30 days at most).'),
    ('Blocks, reports and complaints', 'To keep users safe and answer your complaints.'),
    ('Minimal activity log: sign-ins, account and post records - never message content', 'Required by Indian law to answer court and police orders. Kept 1 year, then deleted.'),
  ];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      color: cs.surfaceContainerHighest,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('What we collect and why', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 8),
          for (final (what, why) in items)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text.rich(TextSpan(children: [
                TextSpan(text: '• $what\n', style: const TextStyle(fontWeight: FontWeight.w700)),
                TextSpan(text: '   $why', style: TextStyle(color: cs.onSurfaceVariant)),
              ])),
            ),
          const Text('We never upload your contact list, and never collect your location or IP address. No ads, nothing sold. '
              'Data is stored with Google Firebase.'),
          const SizedBox(height: 8),
          const Text('Your rights', style: TextStyle(fontWeight: FontWeight.w700)),
          const Text('You can withdraw your consent at any time, as easily as you gave it: Settings → Withdraw consent & delete account. '
              'This deletes your account; only the 1-year activity log and complaints are kept until their period ends. '
              'You can also ask us for a summary of your data, correct or erase it, or nominate someone to act for you, by writing to our Grievance Officer. '
              'If you are not satisfied, you can complain to the Data Protection Board of India.'),
          const SizedBox(height: 4),
          Text('Grievance Officer: $grievanceName · $grievanceEmail', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
          TextButton(onPressed: () => _open(privacyUrl), child: const Text('Full Privacy Policy')),
        ]),
      ),
    );
  }
}

class DataNoticeScreen extends StatelessWidget {
  const DataNoticeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Your data & consent')),
        body: ListView(padding: const EdgeInsets.all(16), children: const [DataNotice()]),
      );
}

// ---------------------------------------------------------------- consent

class ConsentScreen extends StatefulWidget {
  final AppUser me;
  const ConsentScreen({super.key, required this.me});
  @override
  State<ConsentScreen> createState() => _ConsentScreenState();
}

class _ConsentScreenState extends State<ConsentScreen> {
  bool _adult = false, _terms = false, _data = false, _busy = false;
  String? _err;

  bool get _reminderOnly => widget.me.adult && widget.me.termsVer >= termsVersion;

  Future<void> _go() async {
    if (!_adult) { setState(() => _err = '5 Sec Text is only for people aged 18 and over.'); return; }
    if (!_terms) { setState(() => _err = 'Please accept the Terms of Use and Privacy Policy'); return; }
    if (!_reminderOnly && !_data) { setState(() => _err = 'Please give consent for the data use explained above, or sign out'); return; }
    setState(() { _busy = true; _err = null; });
    try {
      await Repo.acceptTerms(termsVersion); // ProfileGate rebuilds and opens the app
    } catch (e) {
      if (mounted) setState(() { _busy = false; _err = '$e'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(_reminderOnly ? 'Rules reminder' : 'Updated Terms of Use'), actions: [TextButton(onPressed: () => auth.signOut(), child: const Text('Sign out'))]),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Text(_reminderOnly ? 'A quick reminder of the rules (we show this every 3 months).' : 'Please read and accept our Terms of Use to continue.',
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        const SizedBox(height: 12),
        const Text('On 5 Sec Text you must not post or send anything that:\n'
            '• is obscene, pornographic, sexual, or shows nudity, including morphed or AI-made (deepfake) images\n'
            '• is harmful to children or exploits them in any way\n'
            '• harasses, threatens, defames or insults anyone, or targets their gender, religion, caste, race or ethnicity\n'
            '• impersonates someone, or is fake, misleading or a scam (including fake deals)\n'
            '• belongs to someone else (copyright, trademark) without permission\n'
            '• promotes gambling, money laundering, violence or any crime\n'
            '• threatens the unity, integrity, defence, security or sovereignty of India, public order or friendly relations with other countries\n'
            '• contains viruses or malicious code, or breaks any law in force.\n\n'
            'If you break these rules we may remove your content and suspend or permanently ban your account, and we must report some '
            'content (for example child sexual abuse material) to the authorities. Vendors are responsible for their own deals.'),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          TextButton(onPressed: () => _open(termsUrl), child: const Text('Read full Terms of Use')),
          TextButton(onPressed: () => _open(privacyUrl), child: const Text('Privacy Policy')),
        ]),
        if (!_reminderOnly) const DataNotice(),
        if (_reminderOnly) TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DataNoticeScreen())), child: const Text('What data we collect and why')),
        CheckboxListTile(contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, value: _adult,
            onChanged: (v) => setState(() => _adult = v ?? false), title: const Text('I confirm I am 18 years of age or older')),
        if (!_reminderOnly) CheckboxListTile(contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, value: _data,
            onChanged: (v) => setState(() => _data = v ?? false), title: const Text('I consent to 5 Sec Text using my data as explained above')),
        CheckboxListTile(contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, value: _terms,
            onChanged: (v) => setState(() => _terms = v ?? false), title: const Text('I have read and agree to the Terms of Use and Privacy Policy')),
        if (_err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_err!, style: TextStyle(color: cs.error))),
        const SizedBox(height: 16),
        FilledButton(onPressed: _busy ? null : _go, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)), child: const Text('Continue')),
        TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpScreen())), child: const Text('Help & Grievance Officer')),
      ]),
    );
  }
}

// ---------------------------------------------------------------- ban + notices

/// Shows a ban screen if Trust & Safety banned this account, and shows any notice
/// staff sent (e.g. "your deal was removed because…") once, with a way to appeal.
class BanGate extends StatefulWidget {
  final AppUser me;
  final Widget child;
  const BanGate({super.key, required this.me, required this.child});
  @override
  State<BanGate> createState() => _BanGateState();
}

class _BanGateState extends State<BanGate> {
  StreamSubscription? _notices;
  bool _showing = false;

  @override
  void initState() {
    super.initState();
    _notices = db.collection('notices').where('uid', isEqualTo: widget.me.uid).snapshots().listen((s) {
      if (s.docs.isNotEmpty && !_showing) _show(s.docs.first);
    }, onError: (_) {});
  }

  Future<void> _show(QueryDocumentSnapshot<Map<String, dynamic>> d) async {
    if (!mounted) return;
    _showing = true;
    final appeal = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        title: const Text('Notice from 5 Sec Text'),
        content: Text((d.data()['text'] ?? '') as String),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Disagree? Appeal')),
          FilledButton(onPressed: () => Navigator.pop(c, false), child: const Text('OK')),
        ],
      ),
    );
    await d.reference.delete().catchError((_) {});
    _showing = false;
    if (appeal == true && mounted) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => ComplaintScreen(category: Complaint.appeal, targetType: 'other', targetId: d.id)));
    }
  }

  @override
  void dispose() {
    _notices?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: db.collection('bans').doc(widget.me.uid).snapshots(),
      builder: (context, snap) {
        final ban = snap.data;
        if (ban == null || !ban.exists) return widget.child;
        final until = ban.data()?['until'];
        final untilDate = until is Timestamp ? until.toDate() : null;
        if (untilDate != null && untilDate.isBefore(DateTime.now())) return widget.child;
        final cs = Theme.of(context).colorScheme;
        return Scaffold(
          body: SafeArea(child: ListView(padding: const EdgeInsets.all(28), children: [
            const SizedBox(height: 40),
            Icon(Icons.block, size: 72, color: cs.error),
            const SizedBox(height: 16),
            Text(untilDate == null ? 'Your account has been banned' : 'Your account is suspended', textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Text('Reason: ${(ban.data()?['reason'] ?? 'breaking the Terms of Use') as String}', textAlign: TextAlign.center),
            if (untilDate != null) Text('Until ${untilDate.toLocal().toString().substring(0, 16)}', textAlign: TextAlign.center),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ComplaintScreen(category: Complaint.appeal, targetType: 'user'))),
              child: const Text('Appeal to the Grievance Officer'),
            ),
            TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HelpScreen())), child: const Text('Help')),
            TextButton(onPressed: () { VideoServer.stop(); auth.signOut(); }, child: const Text('Sign out')),
          ])),
        );
      },
    );
  }
}

// ---------------------------------------------------------------- help

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Help & Grievance Officer')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(
          color: cs.primaryContainer,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Grievance Officer', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: cs.onPrimaryContainer)),
              const SizedBox(height: 6),
              SelectableText('$grievanceName\n$grievanceEmail\n$grievanceAddress', style: TextStyle(color: cs.onPrimaryContainer)),
              const SizedBox(height: 10),
              Text('Under India\'s IT Rules, every complaint is acknowledged within 24 hours and resolved within 7 days. '
                  'Nudity, sexual or morphed (deepfake) images of a person and child sexual abuse material are acted on within 2 hours; '
                  'other unlawful content within 36 hours.', style: TextStyle(color: cs.onPrimaryContainer, fontSize: 13)),
            ]),
          ),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          icon: const Icon(Icons.report_outlined),
          label: const Text('File a complaint'),
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ComplaintScreen())),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          icon: const Icon(Icons.inbox_outlined),
          label: const Text('My complaints and replies'),
          style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MyComplaintsScreen())),
        ),
        const SizedBox(height: 8),
        ListTile(leading: const Icon(Icons.mail_outline), title: const Text('Email the Grievance Officer'), subtitle: const Text(grievanceEmail),
            onTap: () => launchUrl(Uri(scheme: 'mailto', path: grievanceEmail, query: 'subject=${Uri.encodeComponent('5 Sec Text grievance')}'))),
        ListTile(leading: const Icon(Icons.gavel_outlined), title: const Text('Terms of Use'), onTap: () => _open(termsUrl)),
        ListTile(leading: const Icon(Icons.privacy_tip_outlined), title: const Text('Privacy Policy'), onTap: () => _open(privacyUrl)),
        const Divider(),
        const _Faq('Can 5 Sec Text read my messages?', 'No. Messages, photos and videos are end-to-end encrypted and deleted after they are read. '
            'That is also why we cannot see a message you complain about: describe it and give the sender\'s username.'),
        const _Faq('Who checks Deals and Status?', 'Vendors and people who post status manage their own posts and are responsible for them. '
            'Pictures and videos are checked for nudity on the phone automatically, and posts reported by 3 people are hidden. '
            'Our Trust & Safety team only steps in for complaints and legal orders.'),
        const _Faq('Someone is bothering me', 'Open the chat menu and tap Block. You can also file a complaint here.'),
        const _Faq('How do I delete my account?', 'Settings → Withdraw consent & delete account.'),
      ]),
    );
  }
}

class _Faq extends StatelessWidget {
  final String q, a;
  const _Faq(this.q, this.a);
  @override
  Widget build(BuildContext context) => ExpansionTile(title: Text(q), childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12), children: [Text(a)]);
}

// ---------------------------------------------------------------- complaints

class Complaint {
  static const nudity = 'Nudity, sexual content or a morphed / deepfake image of a person';
  static const child = 'Child sexual abuse material';
  static const impersonation = 'Impersonation or fake account';
  static const privacy = 'Privacy violation or identity theft';
  static const harassment = 'Harassment, threats or hate';
  static const fakeDeal = 'Fake, misleading or unlawful deal';
  static const ip = 'Copyright or trademark';
  static const unlawful = 'Other unlawful content';
  static const appeal = 'Appeal a removal or ban';
  static const account = 'Account or app problem';
  static const categories = [nudity, child, impersonation, privacy, harassment, fakeDeal, ip, unlawful, appeal, account];

  /// Deadline to act, per IT Rules (2026 amendment).
  static Duration deadline(String c) => (c == nudity || c == child)
      ? const Duration(hours: 2)
      : (c == impersonation || c == privacy || c == unlawful || c == harassment || c == fakeDeal || c == ip)
          ? const Duration(hours: 36)
          : const Duration(days: 7);

  static String deadlineText(String c) {
    final d = deadline(c);
    return d.inHours <= 2 ? 'within 2 hours' : d.inHours <= 36 ? 'within 36 hours' : 'within 7 days';
  }
}

const _targets = {'deal': 'A deal', 'video': 'A video', 'user': 'A person / account', 'message': 'A message', 'other': 'Something else'};

class ComplaintScreen extends StatefulWidget {
  final String? category, targetType, targetId, targetOwner, targetLabel;
  const ComplaintScreen({super.key, this.category, this.targetType, this.targetId, this.targetOwner, this.targetLabel});
  @override
  State<ComplaintScreen> createState() => _ComplaintScreenState();
}

class _ComplaintScreenState extends State<ComplaintScreen> {
  late String? _cat = widget.category;
  late String _target = widget.targetType ?? 'user';
  final _ref = TextEditingController();
  final _details = TextEditingController();
  final _name = TextEditingController();
  bool _busy = false, _true = false;
  String? _err;

  bool get _fixedTarget => widget.targetId != null;

  Future<void> _submit() async {
    final details = _details.text.trim();
    String? err;
    if (_cat == null) err = 'Choose what the complaint is about';
    else if (details.length < 10) err = 'Please describe the problem (at least 10 characters)';
    else if (!_true) err = 'Please confirm the information is true';
    if (err != null) { setState(() => _err = err); return; }
    setState(() { _busy = true; _err = null; });
    try {
      final urgent = Complaint.deadline(_cat!).inHours <= 2;
      final ref = await db.collection('complaints').add({
        'by': myUid,
        'byEmail': auth.currentUser?.email ?? '',
        'name': _name.text.trim(),
        'category': _cat,
        'targetType': _target,
        'targetId': widget.targetId ?? _ref.text.trim(),
        'targetOwner': widget.targetOwner ?? '',
        'details': details,
        'urgent': urgent,
        'status': 'received',
        'createdAt': FieldValue.serverTimestamp(),
        'expireAt': Timestamp.fromDate(DateTime.now().add(Audit.keep)),
      });
      // Urgent (nudity / child safety): also hide the post at once as a report, while staff review it.
      if (urgent && widget.targetId != null) {
        if (_target == 'deal') await DealRepo.flag(widget.targetId!).catchError((_) {});
        if (_target == 'video') await VideoRepo.flag(widget.targetId!).catchError((_) {});
      }
      await Audit.log('complaint_filed', ref: ref.id, info: _cat!);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ComplaintAckScreen(id: ref.id, category: _cat!, details: details, target: '${_targets[_target]} ${widget.targetLabel ?? _ref.text.trim()}')));
    } catch (e) {
      if (mounted) setState(() { _busy = false; _err = 'Could not send: $e'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('File a complaint')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text('Your complaint goes to our Grievance Officer. You will get a ticket number straight away.', style: TextStyle(color: cs.onSurfaceVariant)),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          value: _cat,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'What is it about?', border: OutlineInputBorder()),
          items: [for (final c in Complaint.categories) DropdownMenuItem(value: c, child: Text(c, overflow: TextOverflow.ellipsis))],
          onChanged: (v) => setState(() => _cat = v),
        ),
        const SizedBox(height: 12),
        if (_fixedTarget)
          ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.flag_outlined), title: Text(_targets[_target] ?? ''), subtitle: Text(widget.targetLabel ?? ''))
        else ...[
          DropdownButtonFormField<String>(
            value: _target,
            decoration: const InputDecoration(labelText: 'Complaint about', border: OutlineInputBorder()),
            items: [for (final e in _targets.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
            onChanged: (v) => setState(() => _target = v ?? 'other'),
          ),
          const SizedBox(height: 12),
          TextField(controller: _ref, maxLength: 120, decoration: InputDecoration(
            labelText: _target == 'deal' ? 'Shop name / deal title' : _target == 'video' ? 'Video title and uploader' : 'Username (e.g. @name)',
            border: const OutlineInputBorder())),
        ],
        if (_target == 'message')
          Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('Messages are end-to-end encrypted and deleted after reading, so we cannot see them. '
              'Describe what was sent and give the sender\'s username. You can also block them from the chat.', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13))),
        TextField(controller: _details, maxLength: 2000, minLines: 4, maxLines: 10,
            decoration: const InputDecoration(labelText: 'Describe the problem', border: OutlineInputBorder(), alignLabelWithHint: true)),
        const SizedBox(height: 8),
        TextField(controller: _name, maxLength: 60, decoration: const InputDecoration(labelText: 'Your name (optional)', border: OutlineInputBorder())),
        CheckboxListTile(contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, value: _true,
            onChanged: (v) => setState(() => _true = v ?? false), title: const Text('The information I have given is true')),
        if (_cat != null) Text('We will act on this ${Complaint.deadlineText(_cat!)}.', style: TextStyle(color: cs.primary, fontWeight: FontWeight.w600)),
        if (_err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_err!, style: TextStyle(color: cs.error))),
        const SizedBox(height: 16),
        FilledButton(onPressed: _busy ? null : _submit, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
            child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Send complaint')),
      ]),
    );
  }
}

String ticketOf(String id) => id.substring(0, id.length < 8 ? id.length : 8).toUpperCase();

class ComplaintAckScreen extends StatelessWidget {
  final String id, category, details, target;
  const ComplaintAckScreen({super.key, required this.id, required this.category, required this.details, required this.target});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final ticket = ticketOf(id);
    final now = DateTime.now().toLocal().toString().substring(0, 16);
    return Scaffold(
      appBar: AppBar(title: const Text('Complaint received')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        Icon(Icons.verified_outlined, size: 72, color: cs.primary),
        const SizedBox(height: 12),
        const Text('We have received your complaint', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text('Ticket #$ticket', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            IconButton(icon: const Icon(Icons.copy, size: 18), onPressed: () => Clipboard.setData(ClipboardData(text: ticket))),
          ]),
          Text('Received: $now'),
          Text('About: $category'),
          const SizedBox(height: 8),
          Text('Our Grievance Officer will act ${Complaint.deadlineText(category)} and resolve it within 7 days at most. '
              'You can follow it and read our reply in Help → My complaints.'),
        ]))),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          icon: const Icon(Icons.mail_outline),
          label: const Text('Also email a copy to the Grievance Officer'),
          onPressed: () => launchUrl(Uri(scheme: 'mailto', path: grievanceEmail, query:
              'subject=${Uri.encodeComponent('Complaint #$ticket - $category')}&body=${Uri.encodeComponent('Ticket: #$ticket\nAbout: $target\n\n$details')}')),
        ),
        const SizedBox(height: 8),
        FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
      ]),
    );
  }
}

class MyComplaintsScreen extends StatelessWidget {
  const MyComplaintsScreen({super.key});

  static const _status = {
    'received': 'Received',
    'review': 'Being reviewed',
    'actioned': 'Action taken',
    'rejected': 'No action needed',
    'closed': 'Closed',
  };

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('My complaints')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: db.collection('complaints').where('by', isEqualTo: myUid).snapshots(),
        builder: (context, snap) {
          final docs = [...?snap.data?.docs];
          docs.sort((a, b) {
            final x = a.data()['createdAt'], y = b.data()['createdAt'];
            return (y is Timestamp ? y.millisecondsSinceEpoch : 0).compareTo(x is Timestamp ? x.millisecondsSinceEpoch : 0);
          });
          if (docs.isEmpty) return Center(child: Text(snap.hasData ? 'No complaints yet.' : '', style: TextStyle(color: cs.onSurfaceVariant)));
          return ListView(padding: const EdgeInsets.all(12), children: [
            for (final d in docs)
              Card(child: ListTile(
                title: Text('#${ticketOf(d.id)} · ${_status[d.data()['status']] ?? d.data()['status']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text([
                  (d.data()['category'] ?? '') as String,
                  if ((d.data()['reply'] ?? '').toString().isNotEmpty) 'Reply: ${d.data()['reply']}',
                ].join('\n')),
                isThreeLine: true,
              )),
          ]);
        },
      ),
    );
  }
}
