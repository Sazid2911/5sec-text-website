import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'audit.dart';
import 'compliance.dart';
import 'crypto.dart';
import 'data.dart';
import 'home_screen.dart';
import 'main.dart';
import 'notifier.dart';
import 'videos.dart';

/// Free sign-in with email + password (no phone number, no paid service).
/// New accounts confirm their email once with a verification link (free plan:
/// 1,000 verification emails a day). After that, users just sign in with their password.
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _pass2 = TextEditingController();
  bool _create = false, _busy = false, _hide = true;
  String? _error, _info;

  String _msg(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'That email address doesn\'t look right.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'Email or password is wrong. Try again or tap "Forgot password?".';
      case 'email-already-in-use':
        return 'An account with this email already exists. Sign in instead.';
      case 'weak-password':
        return 'Choose a stronger password (at least 8 characters).';
      case 'too-many-requests':
        return 'Too many attempts. Wait a few minutes and try again.';
      case 'network-request-failed':
        return 'No internet connection.';
      default:
        return e.message ?? e.code;
    }
  }

  Future<void> _submit() async {
    final email = _email.text.trim();
    final pass = _pass.text;
    String? err;
    if (!email.contains('@')) err = 'Enter a valid email address';
    else if (pass.length < 8) err = 'Password must be at least 8 characters';
    else if (_create && pass != _pass2.text) err = 'Passwords don\'t match';
    if (err != null) { setState(() { _error = err; _info = null; }); return; }
    setState(() { _busy = true; _error = null; _info = null; });
    try {
      if (_create) {
        final cred = await auth.createUserWithEmailAndPassword(email: email, password: pass);
        await cred.user?.sendEmailVerification();
      } else {
        await auth.signInWithEmailAndPassword(email: email, password: pass);
        await Audit.log('sign_in', info: 'email + password');
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) setState(() => _error = _msg(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _forgot() async {
    final email = _email.text.trim();
    if (!email.contains('@')) { setState(() { _error = 'Type your email above first, then tap "Forgot password?"'; _info = null; }); return; }
    setState(() { _busy = true; _error = null; });
    try {
      await auth.sendPasswordResetEmail(email: email);
      setState(() => _info = 'If an account exists for $email, we\'ve emailed a link to reset your password. Check your spam folder too.');
    } on FirebaseAuthException catch (e) {
      setState(() => _error = _msg(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              CircleAvatar(radius: 44, backgroundColor: cs.primary, child: Text('5s', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: cs.onPrimary))),
              const SizedBox(height: 16),
              Text(appName, textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text('Read it. Then it\'s gone.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
              const SizedBox(height: 24),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: false, label: Text('Sign in')),
                  ButtonSegment(value: true, label: Text('Create account')),
                ],
                selected: {_create},
                onSelectionChanged: (v) => setState(() { _create = v.first; _error = null; _info = null; }),
              ),
              const SizedBox(height: 16),
              TextField(controller: _email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email],
                  decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(
                controller: _pass,
                obscureText: _hide,
                autofillHints: [_create ? AutofillHints.newPassword : AutofillHints.password],
                decoration: InputDecoration(
                  labelText: 'Password',
                  border: const OutlineInputBorder(),
                  helperText: _create ? 'At least 8 characters' : null,
                  suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _hide = !_hide)),
                ),
              ),
              if (_create) ...[
                const SizedBox(height: 12),
                TextField(controller: _pass2, obscureText: _hide, decoration: const InputDecoration(labelText: 'Confirm password', border: OutlineInputBorder())),
                const SizedBox(height: 8),
                Text('We\'ll email you a link once to confirm your address. No phone number needed.', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
              ],
              Align(alignment: Alignment.centerLeft, child: TextButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DataNoticeScreen())),
                  child: const Text('What data we collect and why'))),
              if (_error != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text(_error!, style: TextStyle(color: cs.error))),
              if (_info != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text(_info!, style: TextStyle(color: cs.primary))),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: _busy ? null : _submit,
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : Text(_create ? 'Create account' : 'Sign in'),
              ),
              if (!_create) TextButton(onPressed: _busy ? null : _forgot, child: const Text('Forgot password?')),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Email is the only way to sign in. New accounts must confirm their email
/// address (link sent by email) before they can use the app.
class VerifyEmailScreen extends StatefulWidget {
  const VerifyEmailScreen({super.key});
  @override
  State<VerifyEmailScreen> createState() => _VerifyEmailScreenState();
}

class _VerifyEmailScreenState extends State<VerifyEmailScreen> {
  String? _msg;
  Future<void> _check() async {
    await auth.currentUser?.reload();
    if (auth.currentUser?.emailVerified == true) {
      // The old sign-in token still says "not verified"; get a fresh one so the database lets us in.
      await auth.currentUser?.getIdToken(true);
      if (mounted) Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => ProfileGate(uid: auth.currentUser!.uid)), (_) => false);
    } else {
      setState(() => _msg = 'Not verified yet. Open the link in the email we sent you.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final email = auth.currentUser?.email ?? '';
    return Scaffold(
      appBar: AppBar(title: const Text('Verify your email'), actions: [TextButton(onPressed: () => auth.signOut(), child: const Text('Sign out'))]),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        const Icon(Icons.mark_email_unread_outlined, size: 72),
        const SizedBox(height: 16),
        Text('We sent a verification link to\n$email\n\nOpen it (check your spam folder too), then tap the button below.', textAlign: TextAlign.center),
        if (_msg != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_msg!, textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        const SizedBox(height: 24),
        FilledButton(onPressed: _check, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)), child: const Text("I've verified my email")),
        TextButton(
          onPressed: () async {
            await auth.currentUser?.sendEmailVerification();
            setState(() => _msg = 'Verification email sent again.');
          },
          child: const Text('Resend email'),
        ),
      ]),
    );
  }
}

/// Shows the profile setup screen until the user has a name + username.
class ProfileGate extends StatelessWidget {
  final String uid;
  const ProfileGate({super.key, required this.uid});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AppUser?>(
      stream: Repo.watchUser(uid),
      builder: (context, snap) {
        if (!snap.hasData && snap.connectionState == ConnectionState.waiting) return const Splash();
        final me = snap.data;
        if (me == null) return const CreateProfileScreen();
        // 18+ confirmation, current Terms, 3-monthly rules reminder, bans and staff notices.
        if (needsConsent(me)) return ConsentScreen(me: me);
        E2E.init();
        VideoServer.start();
        Notifier.start(me.uid);
        Audit.appOpened();
        return BanGate(me: me, child: HomeScreen(me: me));
      },
    );
  }
}

class CreateProfileScreen extends StatefulWidget {
  const CreateProfileScreen({super.key});
  @override
  State<CreateProfileScreen> createState() => _CreateProfileScreenState();
}

class _CreateProfileScreenState extends State<CreateProfileScreen> {
  final _name = TextEditingController();
  final _user = TextEditingController();
  bool _busy = false, _adult = false, _terms = false, _data = false;
  String? _error;

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      setState(() => _error = 'Please enter your name');
      return;
    }
    if (!_adult) { setState(() => _error = '5 Sec Text is only for people aged 18 and over.'); return; }
    if (!_terms) { setState(() => _error = 'Please accept the Terms of Use and Privacy Policy'); return; }
    if (!_data) { setState(() => _error = 'Please give consent for the data use explained above'); return; }
    setState(() { _busy = true; _error = null; });
    try {
      await Repo.createProfile(_name.text, _user.text, adult: _adult, termsVersion: termsVersion);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Your profile'), actions: [TextButton(onPressed: () => auth.signOut(), child: const Text('Sign out'))]),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        const Text('Friends find you by your username, so pick one that is easy to share.'),
        const SizedBox(height: 20),
        TextField(controller: _name, maxLength: 40, decoration: const InputDecoration(labelText: 'Your name', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        TextField(controller: _user, maxLength: 20, decoration: const InputDecoration(labelText: 'Username', prefixText: '@', border: OutlineInputBorder(), helperText: 'letters, numbers, _ and . only')),
        const SizedBox(height: 8),
        const DataNotice(),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          value: _data,
          onChanged: (v) => setState(() => _data = v ?? false),
          title: const Text('I consent to 5 Sec Text using my data as explained above'),
          subtitle: const Text('You can withdraw it any time in Settings.'),
        ),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          value: _adult,
          onChanged: (v) => setState(() => _adult = v ?? false),
          title: const Text('I confirm I am 18 years of age or older'),
          subtitle: const Text('5 Sec Text is only for adults.'),
        ),
        CheckboxListTile(
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          value: _terms,
          onChanged: (v) => setState(() => _terms = v ?? false),
          title: const Text('I agree to the Terms of Use and Privacy Policy'),
          subtitle: Wrap(spacing: 12, children: [
            TextButton(onPressed: () => launchUrl(Uri.parse(termsUrl), mode: LaunchMode.externalApplication), child: const Text('Terms of Use')),
            TextButton(onPressed: () => launchUrl(Uri.parse(privacyUrl), mode: LaunchMode.externalApplication), child: const Text('Privacy Policy')),
          ]),
        ),
        if (_error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        const SizedBox(height: 20),
        FilledButton(onPressed: _busy ? null : _save, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)), child: const Text('Continue')),
      ]),
    );
  }
}
