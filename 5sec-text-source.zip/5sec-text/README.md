# 5 Sec Text

**Read it. Then it's gone.** A private Android messenger where every message disappears after it is read.

| Feature | How it works |
|---|---|
| Text | Shown with a countdown, deleted 5 s after it is seen (each user can choose 5–30 s in Settings) |
| Photo | Hidden until tapped, shown full screen for 5 s, then deleted. No save/download option |
| Home screen | Blank when everything is read; unread chats show only as anonymous "New message" rows (no names) |
| Groups | Not listed; members reopen a group with its 6-letter group code |
| Voice note | Plays once, then deleted |
| Groups | Message deleted after **every** member has read it |
| Unread | Auto-deleted after 7 days (Firestore TTL) |
| Screenshots | Screenshots, screen recording and recent-apps preview blocked (Android FLAG_SECURE) |
| Encryption | End-to-end: X25519 + AES-256-GCM, per-message keys wrapped for each member; server stores only ciphertext |
| Camera or gallery | Photos and videos (≤30 s) from the in-app camera or gallery, nudity-checked on the phone; the receiver cannot save them |
| Video | Encrypted, stored in <1 MiB chunks, plays once then deleted |
| SIM | App opens only when an active SIM card is in the phone |
| 5 Sec Videos | Separate tab. Uploaders manage their own videos (edit title, audience, days, replace video, end now) - no admin. **No nudity:** frames are checked on the phone before posting and again on the viewer's phone before playing; 3+ reports hide a video. Each user posts up to 2 videos (≤3 min), audience Everyone or Friends only, visible 1–30 days. The file stays ONLY on the uploader's phone and streams peer-to-peer (WebRTC, encrypted) to viewers while the uploader's phone is online with the app open. Likes, comments and views are sent to the uploader as encrypted direct messages (server only relays, then deletes); on the uploader's phone each video appears as a thread named after the video with live 👁 views and ❤ likes totals, and each like/comment/view message vanishes 5 s after it's seen. Report, block. |
| Deals & Coupons | Separate public tab: anyone (suppliers, vendors, shops) posts discount coupons, promo codes or sale offers only, with one optional picture (camera or phone) and no video. Copy-code button, search, category + sub-category (e.g. Fashion → Shoes), sort (biggest discount, ending soon, newest, most trusted), Online / In store and city filters, "code worked 👍 / didn't work 👎" votes with % shown, report/hide. **No nudity:** every picture is checked on the phone by a built-in nudity classifier (assets/models/nsfw.tflite, MIT, from NSFWJS) before posting and again before display; adult words are blocked; deals reported by 3 people are hidden automatically. Up to 10 active deals per user; vendors manage their own deals (edit/update details, picture and end date, or end a deal early) - no admin needed; vendors must tick "I confirm this offer is genuine and lawful" on every post and update, and each deal shows that the vendor is responsible for it; each disappears automatically at its end date (max 30 days). |
| Offline chat | No internet? Text-only chat with a nearby user over Bluetooth / Wi-Fi Direct (Google Nearby Connections). Phone-to-phone, no server, both confirm a 4-character code; messages vanish 5 s after seen. |
| Signature tone | "Vanish": bright two-note rising chime dissolving into a soft whoosh (assets/sounds/five_sec_tone.ogg). Plays in-app for new messages/video activity; background notifications use the same tone and show only "New message" (no names/text). Alerts while the app is running (no paid push server). |
| Calls | No voice or video calls in the app (WebRTC is used only to transfer posted videos) |
| Find friends | Search by @username, or by the name saved in phone contacts (optional number stored only as a hash; contacts never uploaded), or link a username to a saved contact (stored only on the phone) |
| Safety | Block, report, leave group, delete account (Play Store requirements) |
| India compliance | **18+ confirmation** and Terms acceptance at sign-up (also enforced in `firestore.rules`); rules reminder every 3 months and re-accept when `termsVersion` changes. **Help & Grievance Officer** screen with in-app complaint form, instant ticket number and acknowledgement, "My complaints" with staff replies; complain from any deal or video menu. **Trust & Safety tool** (`docs/safety/index.html`) for staff only - complaints with 2 h / 3 h / 36 h / 7-day deadlines, legal orders, take down, notify, suspend/ban, look-up; used only on complaints and orders (vendors and uploaders still self-manage). **Minimal 1-year log** (`logs`, never message content). **Terms of Use** with IT Rules prohibited-content clauses (`docs/terms.html`). |

Built with Flutter + Firebase (Auth + Cloud Firestore) on the **free Spark plan** - photos and voice notes are stored inside the message document, so Cloud Storage (paid plan) is not needed.

---

## One-time setup

### 1. Firebase (free, ~5 minutes)
1. Go to <https://console.firebase.google.com> → **Create a project** → name it `5sec-text` (Google Analytics: off).
2. **Build → Authentication → Get started → Email/Password → Enable → Save.** Sign-in is email + password with a one-time email verification (free plan: 1,000 verification emails/day). Email-link sign-in is NOT used: the free plan allows only 5 link emails per day. Leave Phone disabled.
   - Authentication → Settings → **Authorized domains**: make sure `<project-id>.firebaseapp.com` is listed.
   - **Build → Hosting → Get started** (free) so the `<project-id>.firebaseapp.com` / `.web.app` domain is active.
   - Project settings → Your apps → Android app → **Add fingerprint**: add the SHA-1 and SHA-256 of the upload key (in the private signing kit), and later the Play "App signing key" SHA-256 from Play Console → Setup → App integrity.
   - One-time project setting so sign-in links use the Hosting domain (run in Google Cloud Shell):
     `curl -X PATCH -H "Authorization: Bearer $(gcloud auth print-access-token)" -H "Content-Type: application/json" "https://identitytoolkit.googleapis.com/admin/v2/projects/<project-id>/config?updateMask=mobileLinksConfig" -d '{"mobileLinksConfig":{"domain":"HOSTING_DOMAIN"}}'`
3. **Build → Firestore Database → Create database** → choose a location near your users (e.g. `asia-south1` Mumbai) → *Start in production mode*.
4. Firestore → **Rules** tab → replace everything with the contents of [`firestore.rules`](firestore.rules) → **Publish**.
5. Google Cloud console → Firestore → **Time-to-live** → *Create policy* (one per line, timestamp field `expireAt` each time): collection groups `messages`, `chunks`, `inbox`, `logs` (1-year activity log), `complaints` (1 year). This auto-deletes expired data.
6. Project settings (⚙) → **Your apps → Add app → Android** → package name `com.fivesectext.app` → Register. Skip the download steps.
7. In Project settings → Your apps, copy **API key, App ID, Project ID, Sender ID** into [`lib/firebase_options.dart`](lib/firebase_options.dart).

### 2. GitHub build (free)
1. Add three repository secrets (Settings → Secrets and variables → Actions):
   `KEYSTORE_B64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (values are in the private signing kit - never commit it).
2. Every push to `main` builds the app automatically (**Actions** tab). Download the artifact:
   - `…-test.apk` → install directly on an Android phone to try it.
   - `….aab` → upload to Google Play Console.

### 3. Privacy policy page (required by Play)
Settings → Pages → *Deploy from branch* → `main` / `/docs`. Your policy will be at
`https://<your-username>.github.io/<repo>/privacy.html` - put that URL in `lib/main.dart` (`privacyUrl`) and in Play Console.
Replace `SUPPORT_EMAIL` and `EFFECTIVE_DATE` in `docs/*.html`.

### 3b. Grievance Officer, Terms and Trust & Safety (India)
1. Fill in `grievanceName`, `grievanceEmail`, `grievanceAddress` and `siteUrl` in `lib/main.dart`, and replace `GRIEVANCE_OFFICER_NAME`, `GRIEVANCE_EMAIL`, `GRIEVANCE_POSTAL_ADDRESS`, `COMPANY_LEGAL_NAME`, `JURISDICTION_CITY` in `docs/*.html`.
2. Trust & Safety tool (staff only), served by GitHub Pages at `https://<your-username>.github.io/<repo>/safety/`:
   - Firebase console → Project settings → Your apps → **Add app → Web** → copy `apiKey`, `projectId`, `appId` into the `firebaseConfig` block at the top of `docs/safety/index.html`.
   - Authentication → Settings → Authorized domains → **Add** `<your-username>.github.io`.
   - Create a staff login in Firebase console → Authentication → Users → Add user (email + password), verify the email, then sign in on the page. It shows your user id. In Firestore → Data, create collection `staff` → document id = that user id → any field (e.g. `name`). Only people added here can use the tool.
   - Keep the page open during working hours and tap *Turn on alerts* - it beeps and notifies on every new complaint. Nudity / child-abuse complaints must be acted on within 2 hours, court or government orders within 3 hours (the free plan cannot send push or email alerts to staff; complainants can also email a copy to the Grievance Officer from the app).
   - For a full ban, also disable the user in Firebase console → Authentication.
3. When you change `docs/terms.html`, raise `termsVersion` in `lib/main.dart`; every user must accept the new version.

### 4. Google Play
1. Register at <https://play.google.com/console> ($25 one-time, identity verification).
2. Create app → *5 Sec Text* → App / Free.
3. Store listing: use `store/play_icon_512.png`, `store/feature_graphic_1024x500.png`, and phone screenshots.
4. App content: privacy policy URL, data safety (see below), content rating, **target audience 18+**, account-deletion URL `…/delete-account.html`.
5. **Testing → Closed testing** → upload the `.aab` → add **12+ testers** → keep it running **14 days** → then apply for **Production**.

### Data safety form answers
- Collects: *Email address*, *Name* (display name), *Messages* (in-app messages, photos, voice) - all **required**, for **app functionality**, **not shared**, **encrypted in transit**, users **can request deletion**.
- Also collects: *App interactions* (minimal activity log: sign-ins, posts) - required, for **fraud prevention, security and compliance**, not shared, kept 1 year.
- No location, contacts, ads ID, or analytics.
