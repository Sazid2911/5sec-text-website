"""Run after `flutter create` in CI: permissions, app name, minSdk, screenshot blocking, icons."""
import glob, os, re, shutil

APP_LABEL = '5 Sec Text'
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(root)

# AndroidManifest: label + permissions
mf = 'android/app/src/main/AndroidManifest.xml'
s = open(mf).read()
s = re.sub(r'android:label="[^"]*"', f'android:label="{APP_LABEL}"', s, count=1)
perms = ['android.permission.INTERNET', 'android.permission.RECORD_AUDIO', 'android.permission.CAMERA', 'android.permission.ACCESS_NETWORK_STATE', 'android.permission.CHANGE_NETWORK_STATE',
         # offline Bluetooth / Wi-Fi Direct text chat (Nearby Connections)
         'android.permission.BLUETOOTH', 'android.permission.BLUETOOTH_ADMIN', 'android.permission.BLUETOOTH_SCAN',
         'android.permission.BLUETOOTH_ADVERTISE', 'android.permission.BLUETOOTH_CONNECT', 'android.permission.ACCESS_WIFI_STATE',
         'android.permission.CHANGE_WIFI_STATE', 'android.permission.ACCESS_COARSE_LOCATION', 'android.permission.ACCESS_FINE_LOCATION',
         'android.permission.NEARBY_WIFI_DEVICES', 'android.permission.POST_NOTIFICATIONS',
         # find friends from phone contacts (read only, asked with a clear notice)
         'android.permission.READ_CONTACTS',
         # background service: new-message alerts while the app is closed
         'android.permission.FOREGROUND_SERVICE', 'android.permission.FOREGROUND_SERVICE_REMOTE_MESSAGING',
         'android.permission.RECEIVE_BOOT_COMPLETED', 'android.permission.WAKE_LOCK',
         'android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS']
for p in perms:
    if p not in s:
        s = s.replace('<application', f'<uses-permission android:name="{p}"/>\n    <application', 1)
# Email sign-in link -> opens the app (Android App Links on the free Firebase Hosting domain)
pid = re.search(r"projectId:\s*'([^']+)'", open('lib/firebase_options.dart').read()).group(1)
if 'auth/links' not in s:
    filt = f'''
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW"/>
                <category android:name="android.intent.category.DEFAULT"/>
                <category android:name="android.intent.category.BROWSABLE"/>
                <data android:scheme="https" android:host="{pid}.firebaseapp.com" android:pathPrefix="/__/auth/links"/>
                <data android:scheme="https" android:host="{pid}.web.app" android:pathPrefix="/__/auth/links"/>
            </intent-filter>'''
    s = s.replace('</activity>', filt + '\n        </activity>', 1)
# Background message service (flutter_background_service) as a "remote messaging" foreground service (Android 14+)
if 'flutter_background_service.BackgroundService' not in s:
    if 'xmlns:tools=' not in s:
        s = s.replace('<manifest ', '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)
    s = s.replace('</application>', '''
        <service android:name="id.flutter.flutter_background_service.BackgroundService"
            android:foregroundServiceType="remoteMessaging" android:exported="false"
            tools:replace="android:foregroundServiceType,android:exported"/>
    </application>''', 1)

# App icon follows the colour chosen in Settings: one launcher "alias" per colour,
# only one enabled at a time (Green is the default).
ICON_COLORS = ['purple', 'blue', 'teal', 'green', 'orange', 'pink', 'red', 'indigo', 'brown', 'graphite']
if 'activity-alias' not in s:
    s = re.sub(r'\s*<intent-filter>\s*<action android:name="android.intent.action.MAIN"\s*/>\s*<category android:name="android.intent.category.LAUNCHER"\s*/>\s*</intent-filter>', '', s, count=1)
    aliases = ''.join(f'''
        <activity-alias android:name=".Icon{c.capitalize()}" android:enabled="{'true' if c == 'green' else 'false'}" android:exported="true"
            android:icon="@mipmap/ic_launcher_{c}" android:roundIcon="@mipmap/ic_launcher_{c}" android:label="{APP_LABEL}" android:targetActivity=".MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity-alias>''' for c in ICON_COLORS)
    s = s.replace('</application>', aliases + '\n    </application>', 1)
open(mf, 'w').write(s)

# minSdk 26 (Firebase, record, tflite_flutter)
for g in glob.glob('android/app/build.gradle*'):
    t = open(g).read()
    t = re.sub(r'minSdk(Version)?\s*=?\s*flutter\.minSdkVersion', lambda m: 'minSdk = 26' if g.endswith('.kts') else 'minSdkVersion 26', t)
    open(g, 'w').write(t)

# MainActivity: block screenshots / screen recording (FLAG_SECURE)
for ma in glob.glob('android/app/src/main/kotlin/**/MainActivity.kt', recursive=True):
    pkg = re.search(r'^package\s+([\w.]+)', open(ma).read(), re.M).group(1)
    open(ma, 'w').write(f'''package {pkg}

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.TelephonyManager
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {{
    override fun onCreate(savedInstanceState: Bundle?) {{
        super.onCreate(savedInstanceState)
        // Blocks screenshots, screen recording and the recent-apps preview.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
    }}

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {{
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "fivesec/device").setMethodCallHandler {{ call, result ->
            if (call.method == "simReady") {{
                val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                result.success(tm.simState == TelephonyManager.SIM_STATE_READY)
            }} else if (call.method == "sdkInt") {{
                result.success(android.os.Build.VERSION.SDK_INT)
            }} else if (call.method == "setIcon") {{
                // Switch the home-screen icon to the chosen colour: enable that alias first, then disable the rest.
                val name = call.argument<String>("name") ?: "green"
                val all = listOf("purple", "blue", "teal", "green", "orange", "pink", "red", "indigo", "brown", "graphite")
                if (name !in all) {{ result.success(false); return@setMethodCallHandler }}
                val pm = packageManager
                fun cn(n: String) = ComponentName(this, "$packageName.Icon" + n.replaceFirstChar {{ it.uppercase() }})
                pm.setComponentEnabledSetting(cn(name), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
                for (n in all) if (n != name) pm.setComponentEnabledSetting(cn(n), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                result.success(true)
            }} else {{
                result.notImplemented()
            }}
        }}
    }}
}}
''')

# Coloured launcher icon variants (one per app colour)
for d in glob.glob('assets/icons/variants/mipmap-*'):
    dst = os.path.join('android/app/src/main/res', os.path.basename(d))
    os.makedirs(dst, exist_ok=True)
    for f in os.listdir(d):
        shutil.copy(os.path.join(d, f), os.path.join(dst, f))

# Launcher icons
for d in glob.glob('assets/icons/mipmap-*'):
    dst = os.path.join('android/app/src/main/res', os.path.basename(d))
    os.makedirs(dst, exist_ok=True)
    for f in os.listdir(d):
        shutil.copy(os.path.join(d, f), os.path.join(dst, f))

# Signature notification tone -> res/raw/five_sec_tone.ogg
os.makedirs('android/app/src/main/res/raw', exist_ok=True)
shutil.copy('assets/sounds/five_sec_tone.ogg', 'android/app/src/main/res/raw/five_sec_tone.ogg')
# keep the raw sound from being stripped in release builds
open('android/app/src/main/res/raw/keep.xml', 'w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources xmlns:tools="http://schemas.android.com/tools" tools:keep="@raw/five_sec_tone" />\n')

# Release shrinking (R8) must not strip the Bluetooth (Nearby), WebRTC and TFLite classes,
# otherwise offline messages and peer-to-peer status/videos silently fail in the release APK.
open('android/app/proguard-rules.pro', 'a').write('''
-keep class com.pkmnapps.nearby_connections.** { *; }
-keep class com.google.android.gms.nearby.** { *; }
-dontwarn com.google.android.gms.nearby.**
-keep class org.webrtc.** { *; }
-keep class com.cloudwebrtc.webrtc.** { *; }
-dontwarn org.webrtc.**
-keep class org.tensorflow.** { *; }
-dontwarn org.tensorflow.**
''')

# remove the template test (it references the template app)
if os.path.exists('test/widget_test.dart'):
    os.remove('test/widget_test.dart')
print('android patched')
